import "dotenv/config";
import pg from "pg";
import crypto from "node:crypto";

const client = new pg.Client({ connectionString: process.env.DATABASE_URL });
await client.connect();

function hash(pw) {
  const salt = crypto.randomBytes(16).toString("hex");
  const h = crypto.scryptSync(pw, salt, 64).toString("hex");
  return `${salt}:${h}`;
}

const P = (id, w, h) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=${w}&h=${h}`;
const poster = (id) => P(id, 600, 900);
const backdrop = (id) => P(id, 1600, 900);

const VB = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/";
const VID = {
  a: VB + "BigBuckBunny.mp4",
  b: VB + "ElephantsDream.mp4",
  c: VB + "Sintel.mp4",
  d: VB + "TearsOfSteel.mp4",
};
const TRAILER = {
  a: VB + "ForBiggerBlazes.mp4",
  b: VB + "ForBiggerEscapes.mp4",
  c: VB + "ForBiggerFun.mp4",
  d: VB + "ForBiggerJoyrides.mp4",
  e: VB + "ForBiggerMeltdowns.mp4",
};

const genres = [
  "Action", "Adventure", "Comedy", "Drama", "Horror",
  "Romance", "Sci-Fi", "Thriller", "Animation",
];

// [slug, type, title, year, rating, duration, region, genres[], cast[], poster, backdrop, trailer, video, featured, trending, popular, daysAgo, views, description]
const titles = [
  ["neon-requiem", "movie", "Neon Requiem", 2024, 8.4, 142, "Hollywood", ["Sci-Fi", "Thriller"],
    ["Ayesha Malik", "Daniel Cross", "Mei-Lin Zhao", "Viktor Petrov"], poster(35171240), "/images/hero-neon.jpg", TRAILER.a, VID.c, 1, 1, 1, 6, 48210,
    "In a rain-soaked megacity where memories can be bought and sold, a night courier steals the one recollection that could bring the syndicate down. To survive until sunrise she must outrun the city's entire underworld — and the version of herself she no longer recognizes."],
  ["the-last-monsoon", "movie", "The Last Monsoon", 2023, 7.9, 128, "Hollywood", ["Drama", "Romance"],
    ["Lena Brooks", "Omar Farooq", "Sofia Andersson"], poster(19480795), "/images/hero-monsoon.jpg", TRAILER.b, VID.b, 1, 0, 1, 30, 31050,
    "Two strangers meet each summer at the edge of a dying valley, returning to the same cliff as the rains grow weaker and the seasons shift. A sweeping meditation on love, loss and the landscapes that shape us."],
  ["steel-horizon", "movie", "Steel Horizon", 2025, 8.1, 135, "Hollywood", ["Action", "Adventure"],
    ["Marcus Steele", "Priya Nair", "Jonah Reyes"], poster(14189656), "/images/hero-steel.jpg", TRAILER.c, VID.d, 1, 1, 0, 2, 62110,
    "When a border convoy is ambushed in the deep desert, a disgraced mercenary captain is given one last job: drive the stolen armament across 800 miles of no-man's-land before both armies — and her own past — catch up."],
  ["midnight-caravan", "movie", "Midnight Caravan", 2022, 7.6, 119, "Hollywood", ["Thriller", "Drama"],
    ["Harper Quinn", "Felix Grant", "Nadia Osmani"], poster(14833446), backdrop(34657697), TRAILER.d, VID.d, 0, 0, 0, 300, 18740,
    "A freighter's night shift turns into a long game of cat and mouse when a stowaway claims the cargo isn't what the manifest says — and the fog rolling down the mountain road keeps the headlights from telling the truth."],
  ["paper-lanterns", "movie", "Paper Lanterns", 2024, 7.8, 112, "Hollywood", ["Romance", "Drama"],
    ["Ivy Chen", "Rafael Torres", "Grace Adeyemi"], poster(11320129), backdrop(332306), TRAILER.e, VID.a, 0, 0, 0, 20, 25980,
    "Every year her village releases paper lanterns for those it has lost. This year, a homecoming chef decides to write one letter she never sent — and follows the festival lights to the person it was addressed to."],
  ["hollow-creek", "movie", "Hollow Creek", 2023, 7.2, 104, "Hollywood", ["Horror", "Thriller"],
    ["Evelyn Marsh", "Cole Bennett", "Ruth Adler"], poster(35295844), backdrop(29546721), TRAILER.b, VID.d, 0, 1, 0, 90, 41230,
    "A search party for a missing hiker finds the town of Hollow Creek exactly as the 1974 photographs showed it — down to the empty house at the end of the road that the town insists never existed."],
  ["laugh-track", "movie", "Laugh Track", 2024, 7.0, 101, "Hollywood", ["Comedy"],
    ["Dario Fox", "Sam Whitfield", "June Okafor"], poster(7958715), backdrop(3689545), TRAILER.c, VID.a, 0, 0, 1, 15, 15320,
    "A bankrupt stand-up accidentally becomes the voice of a hit sitcom, and must keep an entire cast guessing which jokes are his while the real comedian hunts him down in the studio lot."],
  ["orbital", "movie", "Orbital", 2025, 8.6, 150, "Hollywood", ["Sci-Fi", "Adventure"],
    ["Kai Nakamura", "Elif Kaya", "Tomas Lindqvist"], poster(35171239), backdrop(31050108), TRAILER.a, VID.c, 0, 1, 1, 5, 55470,
    "The first permanent orbital city wakes up one day with its doors sealed and its founders' names erased from every record. An engineer and a historian have ninety days of oxygen to find out what the city decided to forget."],
  ["dawnbreakers", "movie", "Dawnbreakers", 2024, 8.2, 96, "Hollywood", ["Animation", "Adventure"],
    ["Milo Hart", "Zoe Park", "Ben Osei"], poster(383646), backdrop(38504176), TRAILER.d, VID.a, 0, 0, 1, 45, 29860,
    "Three misfit sky-whales' calves fall behind their migrating herd and must cross the Ember Coast before the long night. A hand-painted animated adventure about finding your flock."],
  ["iron-verdict", "movie", "Iron Verdict", 2021, 7.4, 126, "Hollywood", ["Action", "Thriller"],
    ["Victor Hale", "Dana Cole", "Idris Bello"], poster(18788611), backdrop(30186403), TRAILER.e, VID.d, 0, 0, 0, 500, 12980,
    "A jury foreman realizes the case he's helping to decide is a rehearsal for a real hit — and every juror in the room knows it except the one holding the final vote."],
  ["silk-route", "movie", "Silk Route", 2022, 7.7, 133, "Hollywood", ["Adventure", "Drama"],
    ["Nour El-Sayed", "Jonas Weber", "Tanvi Kapoor"], poster(32349722), backdrop(23322500), TRAILER.c, VID.b, 0, 0, 0, 400, 14560,
    "A translator for a modern trade delegation walks the old silk road to verify a family's legend, carrying her grandmother's compass and a debt that crosses four borders."],
  ["the-winter-heist", "movie", "The Winter Heist", 2023, 7.5, 118, "Hollywood", ["Thriller", "Comedy"],
    ["Claire Dubois", "Pete Malone", "Yara Haddad"], poster(35171242), backdrop(37084818), TRAILER.a, VID.d, 0, 0, 0, 150, 20110,
    "Five strangers with one shared grudge plan to rob the alpine hotel that ruined them — only to discover the owner is already in the lobby, and the blizzard has sealed the mountain."],
  ["dil-ki-ah", "movie", "Dil Ki Aah", 2024, 7.8, 155, "Bollywood", ["Romance", "Drama"],
    ["Arjun Rathore", "Sana Iqbal", "Meera Joshi"], poster(16339485), backdrop(9951122), TRAILER.b, VID.a, 0, 0, 1, 25, 38940,
    "A classical singer gives up her stage for a family business in Mumbai. Twenty years of unsung songs later, a chance radio broadcast gives her one night to sing the song that ended everything."],
  ["chandni-raatein", "movie", "Chandni Raatein", 2023, 7.3, 148, "Bollywood", ["Comedy", "Drama"],
    ["Rohit Verma", "Ananya Sharma", "Kabir Malhotra"], poster(10539414), backdrop(5629967), TRAILER.d, VID.a, 0, 0, 0, 200, 22370,
    "On a moonlit night in old Delhi, three brothers swap lives for 24 hours to win back the hearts they lost — one via love, one via law, one via a terrible bet."],
  ["rang-e-jam", "movie", "Rang-e-Jam", 2023, 8.0, 140, "Pakistani", ["Drama"],
    ["Mahnoor Fatima", "Adeel Khan", "Saba Ali"], poster(6720006), backdrop(32877821), TRAILER.e, VID.b, 0, 0, 0, 120, 19650,
    "A watercolour artist returns to her ancestral haveli in Multan to restore its famous Jam wall, and finds the murals hiding the story her grandfather erased from the family record."],
  ["aangan", "movie", "Aangan", 2024, 7.6, 132, "Pakistani", ["Drama", "Romance"],
    ["Hina Shah", "Bilal Raza", "Noor Jahan"], poster(16790135), backdrop(5490565), TRAILER.a, VID.b, 0, 1, 0, 10, 27480,
    "Under one courtyard in Lahore, four generations argue, cook and forgive their way through a year. When the house is offered for sale, the youngest daughter must decide what the courtyard actually holds."],

  // series
  ["blackwater-station", "series", "Blackwater Station", 2024, 8.7, 0, "Hollywood", ["Sci-Fi", "Thriller"],
    ["Mara Voss", "Elias Trent", "Kofi Mensah"], poster(35171243), backdrop(11336947), TRAILER.a, VID.c, 0, 1, 1, 12, 44120,
    "The last deep-water research station in the North Atlantic reports power from a grid that no longer exists. The crew sent to investigate has 12 episodes — and 3 seasons — to figure out what's living in the black water below."],
  ["the-verdict-room", "series", "The Verdict Room", 2023, 8.2, 0, "Hollywood", ["Drama", "Thriller"],
    ["Julian Marsh", "Priya Raman", "Theo Blake"], poster(32145235), backdrop(33591884), TRAILER.b, VID.b, 0, 0, 0, 180, 33210,
    "Inside a single courtroom, a new judge, a defence lawyer and a witness who changes her story every morning. Twelve jurors. Two seasons. Verdicts that echo far past the gallery."],
  ["laughing-house", "series", "Laughing House", 2024, 7.9, 0, "Hollywood", ["Comedy"],
    ["Bex Carter", "Imran Qureshi", "Dot Nguyen"], poster(14161818), backdrop(5629968), TRAILER.c, VID.a, 0, 0, 0, 18, 24890,
    "A failing family guesthouse in the coast hills is one bad review from closing — until a viral video of the staff's disastrous hospitality makes it the most booked room in the country."],
  ["monsoon-files", "series", "Monsoon Files", 2022, 8.0, 0, "Hollywood", ["Thriller", "Drama"],
    ["Amina Sheikh", "Ravi Menon", "Clara Voss"], poster(35457879), backdrop(12340956), TRAILER.d, VID.c, 0, 0, 0, 420, 28760,
    "An investigative reporter inherits a water-damaged box of 1987 case files during the worst monsoon in a century. Every file names a different person — and all of them were the same night."],
  ["paper-kingdoms", "series", "Paper Kingdoms", 2023, 8.5, 0, "Hollywood", ["Animation", "Adventure"],
    ["Finn O'Malley", "Aria Patel", "Gus Novak"], poster(332306), backdrop(5490565), TRAILER.e, VID.a, 0, 0, 1, 260, 36540,
    "Every child folds a paper empire on their desk. In the creases between folds, the kingdoms come alive — and when the desk is cleared for school, the kingdoms must cross the great wasteland to find a new roof."],
];

// [titleIndex, seasons, epsPerSeason, videoKey]
const seriesPlan = [
  [16, 3, 8, "c"],
  [17, 2, 8, "b"],
  [18, 1, 10, "a"],
  [19, 2, 9, "c"],
  [20, 2, 8, "a"],
];

const descLines = [
  "A quiet opening that hides the season's turning point.",
  "Tensions surface as the cast closes in on the truth.",
  "An old ally returns with a warning nobody asked for.",
  "The plan goes wrong at exactly the predicted minute.",
  "A confrontation nobody saw coming.",
  "Secrets trade hands before the lights go out.",
  "The search narrows to a single impossible door.",
  "Everything changes in the final corridor.",
  "A reunion that costs more than it gives.",
  "The clock starts, and this time there is no pause.",
];

await client.query(`TRUNCATE TABLE watch_history, favorites, episodes, seasons, titles, genres, sessions, users RESTART IDENTITY CASCADE`);

// genres
for (const g of genres) {
  const slug = g.toLowerCase().replace(/[^a-z0-9]+/g, "-");
  await client.query(
    `insert into genres (name, slug) values ($1, $2)`,
    [g, slug]
  );
}

// users
const adminId = (
  await client.query(
    `insert into users (name, email, password, is_admin) values ($1,$2,$3,true) returning id`,
    ["Fahad Admin", "admin@fahadmovies.com", hash("admin123")]
  )
).rows[0].id;
const demoId = (
  await client.query(
    `insert into users (name, email, password, is_admin) values ($1,$2,$3,false) returning id`,
    ["Demo Viewer", "demo@fahadmovies.com", hash("demo123")]
  )
).rows[0].id;

// titles
const titleIds = [];
for (const t of titles) {
  const [slug, type, title, year, rating, duration, region, gen, cast, posterUrl, backdropUrl, trailerUrl, videoUrl, feat, trend, pop, daysAgo, views, description] = t;
  const createdAt = new Date(Date.now() - daysAgo * 86400000).toISOString();
  const r = await client.query(
    `insert into titles (slug, type, title, year, rating, duration, description, poster, backdrop, trailer, video, region, "cast", genres, is_featured, is_trending, is_popular, views, created_at)
     values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19) returning id`,
    [slug, type, title, year, rating, duration, description, posterUrl, backdropUrl, trailerUrl, videoUrl, region, cast, gen, !!feat, !!trend, !!pop, views, createdAt]
  );
  titleIds.push(r.rows[0].id);
}

// seasons + episodes
for (const [ti, seasonCount, epsPer, vkey] of seriesPlan) {
  const titleId = titleIds[ti];
  for (let s = 1; s <= seasonCount; s++) {
    const sr = await client.query(
      `insert into seasons (title_id, season_number, name) values ($1,$2,$3) returning id`,
      [titleId, s, `Season ${s}`]
    );
    const seasonId = sr.rows[0].id;
    for (let e = 1; e <= epsPer; e++) {
      await client.query(
        `insert into episodes (season_id, title_id, number, name, description, video, duration)
         values ($1,$2,$3,$4,$5,$6,$7)`,
        [
          seasonId,
          titleId,
          e,
          `Episode ${e}`,
          descLines[(s + e) % descLines.length],
          VID[vkey],
          42 + ((e * 7 + s * 3) % 14),
        ]
      );
    }
  }
}

// a little history + favorites for the demo user
const demoViews = ["orbital", "dil-ki-ah", "blackwater-station", "steel-horizon", "aangan"];
for (const slug of demoViews) {
  const r = await client.query(`select id from titles where slug = $1`, [slug]);
  if (r.rows[0]) {
    await client.query(
      `insert into watch_history (user_id, title_id, watched_at) values ($1,$2, now() - ($3 || ' hours')::interval)`,
      [demoId, r.rows[0].id, String(demoViews.indexOf(slug) * 7 + 2)]
    );
    await client.query(
      `insert into favorites (user_id, title_id) values ($1,$2) on conflict do nothing`,
      [demoId, r.rows[0].id]
    );
  }
}

const count = await client.query(`select (select count(*) from titles) t, (select count(*) from seasons) s, (select count(*) from episodes) e, (select count(*) from genres) g, (select count(*) from users) u`);
console.log("Seeded:", count.rows[0]);
console.log("admin id:", adminId, "demo id:", demoId);
await client.end();
