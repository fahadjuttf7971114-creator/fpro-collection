import "dotenv/config";
import pg from "pg";
const c = new pg.Client({ connectionString: process.env.DATABASE_URL });
await c.connect();
try {
  const base = await c.query(`select "cast", genres, type, id from titles where slug = $1 limit 1`, ["neon-requiem"]);
  console.log("base:", base.rows[0]);
  const sim = await c.query(`select id, title from titles where id != $1 and (genres && $2) order by rating desc limit 8`, [base.rows[0].id, base.rows[0].genres]);
  console.log("similar ok:", sim.rows.length);
} catch (e) { console.log("ERR1:", e.message); }
try {
  const t = await c.query(`select * from titles where slug=$1 limit 1`, ["neon-requiem"]);
  console.log("title row keys:", Object.keys(t.rows[0]).join(","));
} catch (e) { console.log("ERR2:", e.message); }
await c.end();
