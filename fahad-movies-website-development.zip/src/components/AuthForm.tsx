"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { FormEvent, useState } from "react";
import { IconEye, IconEyeOff, IconPlay } from "./icons";

const inputCls =
  "w-full rounded-md border border-ink-700 bg-ink-900 px-3.5 py-2.5 text-sm text-cream placeholder-faint outline-none transition-colors focus:border-gold-500/60";

export default function AuthForm({ mode }: { mode: "login" | "signup" }) {
  const router = useRouter();
  const sp = useSearchParams();
  const next = sp.get("next") || "/";
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    if (mode === "signup" && password !== confirm) {
      setError("Passwords do not match.");
      return;
    }
    if (password.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }
    setBusy(true);
    try {
      const res = await fetch(`/api/auth/${mode}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name.trim(),
          email: email.trim().toLowerCase(),
          password,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setError(data.error || "Something went wrong. Please try again.");
        return;
      }
      router.push(next.startsWith("/") ? next : "/");
      router.refresh();
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      {mode === "signup" && (
        <div>
          <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-wider text-faint">
            Full name
          </label>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            minLength={2}
            placeholder="Fahad Ahmed"
            className={inputCls}
            autoComplete="name"
          />
        </div>
      )}
      <div>
        <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-wider text-faint">
          Email
        </label>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          placeholder="you@example.com"
          className={inputCls}
          autoComplete="email"
        />
      </div>
      <div>
        <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-wider text-faint">
          Password
        </label>
        <div className="relative">
          <input
            type={showPw ? "text" : "password"}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            minLength={6}
            placeholder="••••••••"
            className={`${inputCls} pr-10`}
            autoComplete={mode === "login" ? "current-password" : "new-password"}
          />
          <button
            type="button"
            onClick={() => setShowPw((v) => !v)}
            aria-label={showPw ? "Hide password" : "Show password"}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-faint hover:text-cream"
          >
            {showPw ? <IconEyeOff className="h-4.5 w-4.5" /> : <IconEye className="h-4.5 w-4.5" />}
          </button>
        </div>
      </div>
      {mode === "signup" && (
        <div>
          <label className="mb-1.5 block text-[11px] font-bold uppercase tracking-wider text-faint">
            Confirm password
          </label>
          <input
            type={showPw ? "text" : "password"}
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            required
            placeholder="••••••••"
            className={inputCls}
            autoComplete="new-password"
          />
        </div>
      )}

      {error && (
        <p className="rounded-md border border-bad/40 bg-bad/10 px-3.5 py-2.5 text-sm font-semibold text-bad anim-fade-in">
          {error}
        </p>
      )}

      <button
        type="submit"
        disabled={busy}
        className="inline-flex w-full items-center justify-center gap-2 rounded-md bg-gold-500 px-5 py-3 text-sm font-black uppercase tracking-wider text-ink-950 transition-all hover:bg-gold-400 active:scale-[0.98] disabled:opacity-60"
      >
        <IconPlay className="h-4 w-4" />
        {busy ? "Please wait…" : mode === "login" ? "Log In" : "Create Account"}
      </button>

      <p className="text-center text-sm text-mist">
        {mode === "login" ? (
          <>
            New to Fahad Movies?{" "}
            <Link href={`/signup${next !== "/" ? `?next=${encodeURIComponent(next)}` : ""}`} className="font-bold text-gold-400 hover:text-gold-300">
              Create an account
            </Link>
          </>
        ) : (
          <>
            Already have an account?{" "}
            <Link href={`/login${next !== "/" ? `?next=${encodeURIComponent(next)}` : ""}`} className="font-bold text-gold-400 hover:text-gold-300">
              Log in
            </Link>
          </>
        )}
      </p>
    </form>
  );
}
