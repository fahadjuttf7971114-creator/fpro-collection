import Link from "next/link";
import { IconPlay } from "./icons";

const socials = [
  {
    label: "X",
    href: "#",
    path: "M18.9 2H22l-6.8 7.8L23.3 22h-6.3l-4.9-6.4L6.4 22H3.3l7.3-8.3L2.7 2h6.4l4.4 5.9L18.9 2Zm-1.1 18h1.7L7.1 3.8H5.3L17.8 20Z",
  },
  {
    label: "Instagram",
    href: "#",
    path: "M12 2.2c2.7 0 3 0 4 .06 3 .14 4.6 1.6 4.7 4.7.06 1 .06 1.3.06 4s0 3-.06 4c-.14 3-1.7 4.6-4.7 4.7-1 .06-1.3.06-4 .06s-3 0-4-.06c-3-.14-4.6-1.7-4.7-4.7C3.2 15 3.2 14.7 3.2 12s0-3 .06-4c.14-3 1.7-4.6 4.7-4.7 1-.06 1.3-.06 4-.06Zm0 4.7a5.1 5.1 0 1 0 0 10.2 5.1 5.1 0 0 0 0-10.2Zm0 8.4a3.3 3.3 0 1 1 0-6.6 3.3 3.3 0 0 1 0 6.6Zm5.3-8.6a1.2 1.2 0 1 0 0-2.4 1.2 1.2 0 0 0 0 2.4Z",
  },
  {
    label: "YouTube",
    href: "#",
    path: "M23 7.2a3 3 0 0 0-2.1-2.2C19 4.5 12 4.5 12 4.5s-7 0-8.9.5A3 3 0 0 0 1 7.2 32 32 0 0 0 .5 12 32 32 0 0 0 1 16.8a3 3 0 0 0 2.1 2.1c1.9.6 8.9.6 8.9.6s7 0 8.9-.6a3 3 0 0 0 2.1-2.1A32 32 0 0 0 23.5 12 32 32 0 0 0 23 7.2ZM9.8 15.1V8.9L15.5 12l-5.7 3.1Z",
  },
  {
    label: "Facebook",
    href: "#",
    path: "M14 8.5V6.8c0-.8.2-1.3 1.4-1.3H17V2.5h-2.6C11.2 2.5 10 4 10 6.5v2H7.5v3H10v9.5h4V11.5h2.7l.4-3H14Z",
  },
];

export default function Footer() {
  return (
    <footer className="mt-16 border-t border-ink-700/50 bg-ink-900/60">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:grid-cols-2 sm:px-6 lg:grid-cols-4">
        <div>
          <Link href="/" className="flex items-center gap-2">
            <span className="grid h-8 w-8 place-items-center rounded-md bg-gold-500 text-ink-950">
              <IconPlay className="h-4 w-4" />
            </span>
            <span className="font-display text-xl tracking-[0.08em]">
              FAHAD <span className="text-gold-400">MOVIES</span>
            </span>
          </Link>
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-mist">
            A premium cinematic streaming experience. Discover movies and TV
            series, build your watchlist, and enjoy a fast, distraction-free
            player — all in a dark, theater-grade interface.
          </p>
          <div className="mt-5 flex gap-2">
            {socials.map((s) => (
              <a
                key={s.label}
                href={s.href}
                aria-label={s.label}
                className="grid h-9 w-9 place-items-center rounded-md border border-ink-700 bg-ink-900 text-mist transition-all hover:border-gold-500/40 hover:text-gold-400"
              >
                <svg viewBox="0 0 24 24" fill="currentColor" className="h-4 w-4">
                  <path d={s.path} />
                </svg>
              </a>
            ))}
          </div>
        </div>

        <div>
          <h4 className="font-display text-lg tracking-wider text-cream">Explore</h4>
          <ul className="mt-4 space-y-2.5 text-sm">
            {[
              ["/", "Home"],
              ["/movies", "Movies"],
              ["/series", "TV Series"],
              ["/genres", "Genres"],
              ["/search", "Search"],
            ].map(([href, label]) => (
              <li key={href}>
                <Link href={href} className="text-mist transition-colors hover:text-gold-400">
                  {label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-display text-lg tracking-wider text-cream">Account</h4>
          <ul className="mt-4 space-y-2.5 text-sm">
            {[
              ["/login", "Login"],
              ["/signup", "Sign Up"],
              ["/favorites", "Favorites / Watchlist"],
              ["/account", "My Profile"],
            ].map(([href, label]) => (
              <li key={href}>
                <Link href={href} className="text-mist transition-colors hover:text-gold-400">
                  {label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-display text-lg tracking-wider text-cream">Legal &amp; Support</h4>
          <ul className="mt-4 space-y-2.5 text-sm">
            {[
              ["/about", "About Us"],
              ["/contact", "Contact"],
              ["/privacy", "Privacy Policy"],
              ["/terms", "Terms of Service"],
            ].map(([href, label]) => (
              <li key={href}>
                <Link href={href} className="text-mist transition-colors hover:text-gold-400">
                  {label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="border-t border-ink-700/40">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-2 px-4 py-5 text-xs text-faint sm:flex-row sm:px-6">
          <p>© {new Date().getFullYear()} Fahad Movies. All rights reserved.</p>
          <p>
            Only content the platform is legally authorized to host or embed.
            Demo data for showcase purposes.
          </p>
        </div>
      </div>
    </footer>
  );
}
