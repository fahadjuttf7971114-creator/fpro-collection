"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { IconCheck, IconEdit } from "./icons";

export default function NameEditor({
  name,
  email,
}: {
  name: string;
  email: string;
}) {
  const router = useRouter();
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState(name);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  async function save() {
    if (!value.trim() || value.trim().length < 2) {
      setMsg("Name must be at least 2 characters.");
      return;
    }
    setBusy(true);
    setMsg(null);
    try {
      const res = await fetch("/api/profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: value.trim() }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setMsg(data.error || "Could not update profile.");
        return;
      }
      setEditing(false);
      router.refresh();
    } finally {
      setBusy(false);
    }
  }

  if (!editing) {
    return (
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          <p className="truncate text-lg font-bold">{name}</p>
          <p className="truncate text-sm text-faint">{email}</p>
        </div>
        <button
          onClick={() => {
            setValue(name);
            setEditing(true);
          }}
          aria-label="Edit name"
          className="grid h-9 w-9 shrink-0 place-items-center rounded-md border border-ink-700 text-mist hover:border-gold-500/50 hover:text-gold-400"
        >
          <IconEdit className="h-4 w-4" />
        </button>
      </div>
    );
  }

  return (
    <div>
      <div className="flex gap-2">
        <input
          value={value}
          onChange={(e) => setValue(e.target.value)}
          className="w-full rounded-md border border-ink-700 bg-ink-900 px-3 py-2 text-sm outline-none focus:border-gold-500/60"
          aria-label="Display name"
        />
        <button
          onClick={save}
          disabled={busy}
          className="inline-flex shrink-0 items-center gap-1.5 rounded-md bg-gold-500 px-4 py-2 text-sm font-bold text-ink-950 hover:bg-gold-400 disabled:opacity-60"
        >
          <IconCheck className="h-4 w-4" /> {busy ? "…" : "Save"}
        </button>
      </div>
      {msg && <p className="mt-1.5 text-xs font-semibold text-bad">{msg}</p>}
    </div>
  );
}
