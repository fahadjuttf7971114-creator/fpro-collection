import type { TitleData, SeasonWithEpisodes } from "@/lib/queries";

export type { SeasonWithEpisodes };

export type AdminTitle = TitleData & { seasons: SeasonWithEpisodes[] };

export type AdminGenre = {
  id: number;
  name: string;
  slug: string;
  active: boolean;
  count: number;
};

export type AdminStats = {
  totals: {
    titles: number;
    movies: number;
    series: number;
    genres: number;
    users: number;
    views: number;
    favorites: number;
    featured: number;
  };
  top: { id: number; slug: string; title: string; views: number; type: string }[];
  recentUsers: { name: string; email: string; createdAt: Date | string }[];
};

export const SAMPLE_MOVIES = [
  { label: "Open Movie A", url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4" },
  { label: "Open Movie B", url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4" },
  { label: "Open Movie C", url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4" },
  { label: "Open Movie D", url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4" },
];

export const SAMPLE_TRAILERS = [
  { label: "Trailer A", url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4" },
  { label: "Trailer B", url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4" },
  { label: "Trailer C", url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4" },
  { label: "Trailer D", url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4" },
];

export async function api<T = unknown>(
  path: string,
  opts?: RequestInit
): Promise<T> {
  const res = await fetch(path, {
    ...opts,
    headers: opts?.body ? { "Content-Type": "application/json", ...(opts.headers || {}) } : opts?.headers,
  });
  const data = (await res.json().catch(() => ({}))) as T & { error?: string };
  if (!res.ok) throw new Error(data?.error || `Request failed (${res.status})`);
  return data;
}
