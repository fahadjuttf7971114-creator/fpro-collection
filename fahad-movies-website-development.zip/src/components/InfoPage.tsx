import type { ReactNode } from "react";

export default function InfoPage({
  kicker,
  title,
  children,
}: {
  kicker: string;
  title: string;
  children: ReactNode;
}) {
  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <p className="text-[11px] font-black uppercase tracking-[0.25em] text-gold-400">{kicker}</p>
      <h1 className="mt-1 font-display text-5xl tracking-wide">{title}</h1>
      <div className="mt-8 space-y-5 text-[15px] leading-relaxed text-cream/85 [&_a]:font-semibold [&_a]:text-gold-400 [&_h2]:font-display [&_h2]:mt-8 [&_h2]:text-3xl [&_h2]:tracking-wide [&_h2]:text-cream [&_p]:text-mist [&_li]:text-mist [&_strong]:text-cream">
        {children}
      </div>
    </div>
  );
}
