"use client";

import Link from "next/link";
import { useState } from "react";
import PosterImg from "./PosterImg";
import { IconHeart, IconPlay, IconStar, IconTv } from "./icons";
import type { TitleData } from "@/lib/queries";

export default function TitleCard({
  t,
  seasonCount,
  episodeCount,
  isFav = false,
}: {
  t: TitleData;
  seasonCount?: number;
  episodeCount?: number;
  isFav?: boolean;
}) {
  const [fav, setFav] = useState(isFav);
  const [popped, setPopped] = useState(false);

  async function toggleFav(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    if (!fav) setFav(true);
    else setFav(false);
    setPopped(true);
    setTimeout(() => setPopped(false), 400);
    try {
      const res = await fetch("/api/favorites", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ titleId: t.id }),
      });
      const data = await res.json();
      if (!res.ok) {
        setFav(isFav);
        window.location.href = "/login?next=" + encodeURIComponent(window.location.pathname);
        return;
      }
      setFav(!!data.fav);
    } catch {
      setFav(isFav);
    }
  }

  const isNew = new Date(t.createdAt).getTime() > Date.now() - 120 * 24 * 3600 * 1000;

  return (
    <Link
      href={`/title/${t.slug}`}
      className="group relative block w-36 shrink-0 snap-start sm:w-40 md:w-44"
    >
      <div className="relative overflow-hidden rounded-lg border border-ink-700/60 bg-ink-900 shadow-lg shadow-black/30 transition-all duration-300 group-hover:-translate-y-1 group-hover:border-gold-500/40 group-hover:shadow-black/60">
        <PosterImg
          src={t.poster}
          alt={t.title}
          className="aspect-[2/3] w-full"
          imgClassName="transition-transform duration-500 group-hover:scale-105"
        />
        {/* badges */}
        <div className="absolute left-2 top-2 flex flex-col items-start gap-1">
          {t.isTrending && (
            <span className="rounded bg-live/90 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white/95">
              Trending
            </span>
          )}
          {isNew && !t.isTrending && (
            <span className="rounded bg-gold-500/90 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-ink-950">
              New
            </span>
          )}
        </div>
        <button
          onClick={toggleFav}
          aria-label={fav ? "Remove from favorites" : "Add to favorites"}
          className={`absolute right-2 top-2 grid h-8 w-8 place-items-center rounded-full bg-ink-950/70 backdrop-blur transition-all hover:scale-110 ${
            fav
              ? "text-live"
              : "text-cream/80 sm:opacity-0 sm:group-hover:opacity-100"
          } ${popped ? "anim-pop" : ""}`}
        >
          <IconHeart className="h-4 w-4" filled={fav} />
        </button>
        {/* hover overlay */}
        <div className="pointer-events-none absolute inset-x-0 bottom-0 translate-y-2 bg-gradient-to-t from-ink-950 via-ink-950/80 to-transparent px-3 pb-3 pt-10 opacity-0 transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100">
          <div className="flex items-center gap-2 text-[11px] text-mist">
            <span className="inline-flex items-center gap-1 font-semibold text-gold-400">
              <IconStar className="h-3 w-3" />
              {Number(t.rating).toFixed(1)}
            </span>
            <span>·</span>
            <span>{t.year}</span>
            <span>·</span>
            <span className="truncate">{t.region}</span>
          </div>
          <div className="mt-1 flex items-center justify-between">
            <span className="truncate text-[11px] text-faint">
              {t.type === "series"
                ? `${seasonCount ?? "—"} Season${(seasonCount ?? 0) > 1 ? "s" : ""} · ${episodeCount ?? "—"} Episodes`
                : `${t.duration} min`}
            </span>
            <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-gold-500 text-ink-950">
              <IconPlay className="h-3.5 w-3.5" />
            </span>
          </div>
        </div>
      </div>
      <p className="mt-2 truncate text-sm font-semibold text-cream/90 group-hover:text-cream">
        {t.title}
      </p>
      <p className="flex items-center gap-1.5 text-xs text-faint">
        {t.type === "series" && <IconTv className="h-3 w-3" />}
        {t.genres.slice(0, 2).join(" · ")}
      </p>
    </Link>
  );
}
