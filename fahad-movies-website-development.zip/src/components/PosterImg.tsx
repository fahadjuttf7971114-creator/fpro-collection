"use client";

import { useState } from "react";

const FALLBACKS = [
  "from-[#2a3447] via-[#1e2634] to-[#10141d]",
  "from-[#4a2f3e] via-[#2a2033] to-[#10141d]",
  "from-[#2f4a44] via-[#1f2e2c] to-[#10141d]",
  "from-[#4a3d2f] via-[#2e271f] to-[#10141d]",
  "from-[#2f3a4a] via-[#1f242e] to-[#10141d]",
  "from-[#4a2f45] via-[#2a1f2e] to-[#10141d]",
];

function hash(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return h;
}

export default function PosterImg({
  src,
  alt,
  className = "",
  imgClassName = "",
  eager = false,
}: {
  src?: string;
  alt: string;
  className?: string;
  imgClassName?: string;
  eager?: boolean;
}) {
  const [failed, setFailed] = useState(false);
  const [loaded, setLoaded] = useState(false);

  if (!src || failed) {
    const grad = FALLBACKS[hash(alt) % FALLBACKS.length];
    const initials = alt
      .split(/\s+/)
      .slice(0, 3)
      .map((w) => w[0]?.toUpperCase())
      .join("");
    return (
      <div
        className={`relative flex items-end justify-start overflow-hidden bg-gradient-to-br ${grad} ${className}`}
        aria-label={alt}
      >
        <div
          className="pointer-events-none absolute inset-0 opacity-40"
          style={{
            backgroundImage:
              "radial-gradient(ellipse at 70% 20%, rgba(234,181,86,0.18), transparent 55%)",
          }}
        />
        <span className="relative m-3 font-display text-2xl tracking-wider text-cream/70">
          {initials || "FM"}
        </span>
      </div>
    );
  }

  return (
    <div className={`relative overflow-hidden bg-ink-800 ${className}`}>
      <img
        src={src}
        alt={alt}
        loading={eager ? "eager" : "lazy"}
        decoding="async"
        onLoad={() => setLoaded(true)}
        onError={() => setFailed(true)}
        className={`h-full w-full object-cover transition-opacity duration-500 ${
          loaded ? "opacity-100" : "opacity-0"
        } ${imgClassName}`}
      />
      {!loaded && <div className="absolute inset-0 skeleton" />}
    </div>
  );
}
