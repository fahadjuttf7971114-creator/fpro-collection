"use client";

import Link from "next/link";
import { useState } from "react";
import { IconChevronDown, IconPlay } from "./icons";
import type { SeasonWithEpisodes } from "@/lib/queries";

export default function SeriesEpisodes({
  slug,
  seasons,
  compact = false,
}: {
  slug: string;
  seasons: SeasonWithEpisodes[];
  compact?: boolean;
}) {
  const [active, setActive] = useState(seasons[0]?.id ?? 0);
  const season = seasons.find((s) => s.id === active) ?? seasons[0];

  if (!season || season.episodes.length === 0) {
    return (
      <p className="rounded-lg border border-ink-700 bg-ink-900/60 p-4 text-sm text-faint">
        Episodes for this series are being added. Check back soon.
      </p>
    );
  }

  return (
    <div>
      <div className="mb-3 flex items-center gap-3">
        <span className="text-[11px] font-bold uppercase tracking-wider text-faint">
          Season
        </span>
        <div className="relative">
          <select
            value={season.id}
            onChange={(e) => setActive(Number(e.target.value))}
            className="appearance-none rounded-md border border-ink-700 bg-ink-900 py-2 pl-3 pr-9 text-sm font-semibold text-cream outline-none focus:border-gold-500/60"
            aria-label="Select season"
          >
            {seasons.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name || `Season ${s.seasonNumber}`}
              </option>
            ))}
          </select>
          <IconChevronDown className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-faint" />
        </div>
        <span className="text-xs text-faint">
          {season.episodes.length} episode{season.episodes.length === 1 ? "" : "s"}
        </span>
      </div>

      <ul className="divide-y divide-ink-700/50 overflow-hidden rounded-lg border border-ink-700 bg-ink-900/60">
        {season.episodes.map((e) => (
          <li key={e.id}>
            <Link
              href={`/watch/${slug}?season=${season.seasonNumber}&ep=${e.number}`}
              className="group flex items-center gap-3 px-3 py-2.5 transition-colors hover:bg-ink-800/70 sm:px-4"
            >
              <span className="w-7 shrink-0 text-center font-mono text-sm text-faint">
                {String(e.number).padStart(2, "0")}
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold text-cream/90 group-hover:text-gold-300">
                  {e.name || `Episode ${e.number}`}
                </p>
                {!compact && e.description && (
                  <p className="mt-0.5 line-clamp-1 text-xs text-faint">{e.description}</p>
                )}
              </div>
              {e.duration > 0 && (
                <span className="shrink-0 font-mono text-xs text-faint">{e.duration}m</span>
              )}
              <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full border border-ink-600 text-mist transition-all group-hover:border-gold-500 group-hover:bg-gold-500 group-hover:text-ink-950">
                <IconPlay className="h-3.5 w-3.5" />
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
