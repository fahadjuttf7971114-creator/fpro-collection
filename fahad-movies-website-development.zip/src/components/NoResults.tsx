"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { IconSearch } from "./icons";

export default function NoResults({
  message = "No results found",
  hint = "Try adjusting your filters or search for something else.",
  popular = ["Action", "Drama", "Sci-Fi", "Thriller", "Comedy"],
  basePath = "/movies",
}: {
  message?: string;
  hint?: string;
  popular?: string[];
  basePath?: string;
}) {
  const sp = useSearchParams();
  return (
    <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-ink-600 bg-ink-900/40 px-6 py-20 text-center anim-fade-up">
      <span className="grid h-16 w-16 place-items-center rounded-full bg-ink-800 text-faint">
        <IconSearch className="h-7 w-7" />
      </span>
      <h3 className="mt-5 font-display text-3xl tracking-wide text-cream">{message}</h3>
      <p className="mt-2 max-w-sm text-sm text-mist">{hint}</p>
      {popular.length > 0 && (
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          {popular.map((g) => (
            <Link
              key={g}
              href={`${basePath}?${
                sp.toString().replace(/(genre|year|region|sort)=&?/, "")
              }genre=${encodeURIComponent(g)}`}
              className="rounded-full border border-ink-600 bg-ink-800 px-4 py-1.5 text-xs font-bold text-mist transition-all hover:border-gold-500/50 hover:text-gold-400"
            >
              {g}
            </Link>
          ))}
        </div>
      )}
      <Link
        href={basePath}
        className="mt-6 rounded-md bg-gold-500 px-5 py-2.5 text-sm font-bold text-ink-950 transition-all hover:bg-gold-400"
      >
        Browse everything
      </Link>
    </div>
  );
}
