"use client";

import { useState } from "react";
import { api, SAMPLE_MOVIES, type SeasonWithEpisodes } from "./adminTypes";
import { IconChevronDown, IconPlus, IconTrash } from "./icons";

const inputCls =
  "rounded-md border border-ink-700 bg-ink-900 px-3 py-2 text-sm text-cream placeholder-faint outline-none transition-colors focus:border-gold-500/60";

type Notice = { kind: "ok" | "err"; msg: string } | null;

export default function SeasonManager({
  titleId,
  seasons,
  onChanged,
}: {
  titleId: number;
  seasons: SeasonWithEpisodes[];
  onChanged: () => void;
}) {
  const [notice, setNotice] = useState<Notice>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [newSeason, setNewSeason] = useState(
    seasons.length ? seasons[seasons.length - 1].seasonNumber + 1 : 1
  );
  const [newSeasonName, setNewSeasonName] = useState("");
  const [open, setOpen] = useState<Record<number, boolean>>(
    Object.fromEntries(seasons.map((s) => [s.id, true]))
  );
  const [epForm, setEpForm] = useState<Record<number, { number: number; name: string; video: string; duration: number; editingId: number | null }>>(
    Object.fromEntries(
      seasons.map((s) => [
        s.id,
        {
          number: (s.episodes[s.episodes.length - 1]?.number ?? 0) + 1,
          name: "",
          video: "",
          duration: 45,
          editingId: null,
        },
      ])
    )
  );

  function flash(kind: "ok" | "err", msg: string) {
    setNotice({ kind, msg });
    setTimeout(() => setNotice(null), 3500);
  }

  async function addSeason() {
    setBusy(`season-${titleId}`);
    try {
      await api(`/api/titles/${titleId}/seasons`, {
        method: "POST",
        body: JSON.stringify({
          seasonNumber: Number(newSeason),
          name: newSeasonName.trim() || `Season ${newSeason}`,
        }),
      });
      flash("ok", `Season ${newSeason} added.`);
      setNewSeason((n) => n + 1);
      setNewSeasonName("");
      onChanged();
    } catch (e) {
      flash("err", e instanceof Error ? e.message : "Failed.");
    } finally {
      setBusy(null);
    }
  }

  async function deleteSeason(seasonId: number) {
    setBusy(`del-season-${seasonId}`);
    try {
      await api(`/api/seasons/${seasonId}`, { method: "DELETE" });
      flash("ok", "Season deleted (with its episodes).");
      onChanged();
    } catch (e) {
      flash("err", e instanceof Error ? e.message : "Failed.");
    } finally {
      setBusy(null);
    }
  }

  async function addEpisode(season: SeasonWithEpisodes) {
    const f = epForm[season.id];
    if (!f) return;
    setBusy(`ep-${season.id}`);
    try {
      const body = {
        titleId,
        seasonId: season.id,
        number: f.editingId ? undefined : Number(f.number),
        name: f.name,
        video: f.video,
        duration: Number(f.duration) || 0,
      };
      if (f.editingId) {
        await api(`/api/episodes/${f.editingId}`, { method: "PATCH", body: JSON.stringify(body) });
        flash("ok", "Episode updated.");
      } else {
        await api("/api/episodes", { method: "POST", body: JSON.stringify(body) });
        flash("ok", `Episode ${f.number} added to season ${season.seasonNumber}.`);
        setEpForm((prev) => ({
          ...prev,
          [season.id]: { ...f, number: f.number + 1, name: "", video: "", editingId: null },
        }));
      }
      if (f.editingId) {
        setEpForm((prev) => ({
          ...prev,
          [season.id]: { ...f, name: "", video: "", editingId: null },
        }));
      }
      onChanged();
    } catch (e) {
      flash("err", e instanceof Error ? e.message : "Failed.");
    } finally {
      setBusy(null);
    }
  }

  function startEdit(season: SeasonWithEpisodes, ep: { id: number; number: number; name: string; video: string; duration: number }) {
    setEpForm((prev) => ({
      ...prev,
      [season.id]: {
        number: ep.number,
        name: ep.name,
        video: ep.video,
        duration: ep.duration,
        editingId: ep.id,
      },
    }));
  }

  async function deleteEpisode(epId: number) {
    setBusy(`del-ep-${epId}`);
    try {
      await api(`/api/episodes/${epId}`, { method: "DELETE" });
      flash("ok", "Episode deleted.");
      onChanged();
    } catch (e) {
      flash("err", e instanceof Error ? e.message : "Failed.");
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="space-y-4">
      {notice && (
        <p
          className={`rounded-md border px-3.5 py-2 text-sm font-semibold anim-fade-in ${
            notice.kind === "ok"
              ? "border-good/40 bg-good/10 text-good"
              : "border-bad/40 bg-bad/10 text-bad"
          }`}
        >
          {notice.msg}
        </p>
      )}

      {seasons.length === 0 && (
        <p className="rounded-lg border border-dashed border-ink-600 bg-ink-900/40 p-4 text-sm text-faint">
          No seasons yet — add the first one below.
        </p>
      )}

      {seasons.map((s) => {
        const f = epForm[s.id];
        const editing = f?.editingId
          ? s.episodes.find((e) => e.id === f.editingId)
          : null;
        return (
          <div key={s.id} className="overflow-hidden rounded-lg border border-ink-700 bg-ink-800/40">
            <div className="flex items-center gap-3 border-b border-ink-700/60 bg-ink-900/60 px-4 py-2.5">
              <button
                onClick={() => setOpen((o) => ({ ...o, [s.id]: !o[s.id] }))}
                className="flex items-center gap-2 text-sm font-bold text-cream"
                aria-label={`Toggle season ${s.seasonNumber}`}
              >
                <IconChevronDown className={`h-4 w-4 text-faint transition-transform ${open[s.id] ? "rotate-0" : "-rotate-90"}`} />
                {s.name || `Season ${s.seasonNumber}`}
              </button>
              <span className="text-xs text-faint">
                {s.episodes.length} ep{s.episodes.length === 1 ? "" : "s"}
              </span>
              <button
                onClick={() => deleteSeason(s.id)}
                disabled={busy === `del-season-${s.id}`}
                className="ml-auto inline-flex items-center gap-1.5 rounded-md border border-ink-600 px-2.5 py-1 text-xs font-bold text-mist hover:border-bad/50 hover:text-bad disabled:opacity-50"
              >
                <IconTrash className="h-3.5 w-3.5" />
                {busy === `del-season-${s.id}` ? "Deleting…" : "Delete season"}
              </button>
            </div>

            {open[s.id] && (
              <div className="p-4">
                <ul className="space-y-1.5">
                  {s.episodes.map((e) => (
                    <li key={e.id} className="flex items-center gap-3 rounded-md bg-ink-900/60 px-3 py-2">
                      <span className="w-8 shrink-0 text-center font-mono text-xs text-faint">
                        E{String(e.number).padStart(2, "0")}
                      </span>
                      <span className="min-w-0 flex-1 truncate text-sm font-semibold text-cream/90">
                        {e.name || `Episode ${e.number}`}
                      </span>
                      <span className="hidden font-mono text-xs text-faint sm:block">{e.duration}m</span>
                      <button
                        onClick={() => startEdit(s, e)}
                        className="rounded px-2 py-1 text-xs font-bold text-mist hover:text-gold-400"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => deleteEpisode(e.id)}
                        disabled={busy === `del-ep-${e.id}`}
                        aria-label={`Delete episode ${e.number}`}
                        className="grid h-7 w-7 place-items-center rounded text-mist hover:bg-ink-800 hover:text-bad disabled:opacity-50"
                      >
                        <IconTrash className="h-3.5 w-3.5" />
                      </button>
                    </li>
                  ))}
                  {s.episodes.length === 0 && (
                    <li className="rounded-md bg-ink-900/40 px-3 py-2 text-xs text-faint">
                      No episodes in this season yet.
                    </li>
                  )}
                </ul>

                <div className="mt-3 rounded-md border border-ink-700/70 bg-ink-900/50 p-3">
                  <p className="mb-2 text-[11px] font-bold uppercase tracking-wider text-faint">
                    {editing ? `Edit episode ${editing.number}` : "Add episode"}
                  </p>
                  <div className="grid gap-2 sm:grid-cols-4">
                    <input
                      type="number"
                      min={1}
                      max={100}
                      value={f?.number ?? 1}
                      onChange={(e) => setEpForm((p) => ({ ...p, [s.id]: { ...(p[s.id] ?? { number: 1, name: "", video: "", duration: 45, editingId: null }), number: Number(e.target.value), editingId: null } }))}
                      disabled={!!editing}
                      className={inputCls}
                      aria-label="Episode number"
                    />
                    <input
                      value={f?.name ?? ""}
                      onChange={(e) => setEpForm((p) => ({ ...p, [s.id]: { ...(p[s.id] ?? { number: 1, name: "", video: "", duration: 45, editingId: null }), name: e.target.value } }))}
                      placeholder="Episode title"
                      className={inputCls}
                      aria-label="Episode title"
                    />
                    <div className="relative">
                      <input
                        value={f?.video ?? ""}
                        onChange={(e) => setEpForm((p) => ({ ...p, [s.id]: { ...(p[s.id] ?? { number: 1, name: "", video: "", duration: 45, editingId: null }), video: e.target.value } }))}
                        placeholder="Video URL"
                        className={`${inputCls} pr-8`}
                        aria-label="Episode video URL"
                      />
                      <select
                        value=""
                        onChange={(e) => {
                          if (!e.target.value) return;
                          setEpForm((p) => ({ ...p, [s.id]: { ...(p[s.id] ?? { number: 1, name: "", video: "", duration: 45, editingId: null }), video: e.target.value } }));
                        }}
                        className="absolute right-1 top-1/2 h-7 -translate-y-1/2 rounded bg-ink-800 pl-1 pr-1 text-[10px] font-bold text-faint outline-none"
                        aria-label="Pick sample video"
                      >
                        <option value="">Sample</option>
                        {SAMPLE_MOVIES.map((smp) => (
                          <option key={smp.url} value={smp.url}>
                            {smp.label}
                          </option>
                        ))}
                      </select>
                    </div>
                    <input
                      type="number"
                      min={0}
                      max={300}
                      value={f?.duration ?? 45}
                      onChange={(e) => setEpForm((p) => ({ ...p, [s.id]: { ...(p[s.id] ?? { number: 1, name: "", video: "", duration: 45, editingId: null }), duration: Number(e.target.value) } }))}
                      placeholder="Min"
                      className={inputCls}
                      aria-label="Duration minutes"
                    />
                  </div>
                  <div className="mt-2 flex gap-2">
                    <button
                      onClick={() => addEpisode(s)}
                      disabled={busy === `ep-${s.id}`}
                      className="inline-flex items-center gap-1.5 rounded-md bg-gold-500 px-4 py-1.5 text-xs font-black uppercase tracking-wider text-ink-950 hover:bg-gold-400 disabled:opacity-60"
                    >
                      <IconPlus className="h-3.5 w-3.5" />
                      {busy === `ep-${s.id}` ? "Saving…" : editing ? "Update episode" : "Add episode"}
                    </button>
                    {editing && (
                      <button
                        onClick={() => setEpForm((p) => ({ ...p, [s.id]: { ...(p[s.id] ?? { number: 1, name: "", video: "", duration: 45, editingId: null }), editingId: null, name: "", video: "" } }))}
                        className="rounded-md border border-ink-600 px-3 py-1.5 text-xs font-bold text-mist hover:text-cream"
                      >
                        Cancel
                      </button>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        );
      })}

      <div className="flex flex-wrap items-end gap-2 rounded-lg border border-dashed border-ink-600 bg-ink-900/40 p-4">
        <div>
          <span className="mb-1 block text-[11px] font-bold uppercase tracking-wider text-faint">New season #</span>
          <input
            type="number"
            min={1}
            max={50}
            value={newSeason}
            onChange={(e) => setNewSeason(Number(e.target.value))}
            className={`${inputCls} w-24`}
          />
        </div>
        <div className="min-w-40 flex-1">
          <span className="mb-1 block text-[11px] font-bold uppercase tracking-wider text-faint">Name (optional)</span>
          <input
            value={newSeasonName}
            onChange={(e) => setNewSeasonName(e.target.value)}
            placeholder={`Season ${newSeason}`}
            className={inputCls}
          />
        </div>
        <button
          onClick={addSeason}
          disabled={busy === `season-${titleId}`}
          className="inline-flex items-center gap-1.5 rounded-md bg-gold-500 px-4 py-2 text-xs font-black uppercase tracking-wider text-ink-950 hover:bg-gold-400 disabled:opacity-60"
        >
          <IconPlus className="h-3.5 w-3.5" />
          {busy === `season-${titleId}` ? "Adding…" : "Add season"}
        </button>
      </div>
    </div>
  );
}
