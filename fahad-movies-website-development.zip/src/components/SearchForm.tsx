"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { IconSearch, IconX } from "./icons";

const selectCls =
  "w-full rounded-md border border-ink-700 bg-ink-900 px-3 py-2.5 text-sm text-cream outline-none transition-colors focus:border-gold-500/60";

export default function SearchForm({
  genres,
  years,
  initial,
}: {
  genres: string[];
  years: number[];
  initial: { q: string; actor: string; genre: string; year: string; type: string };
}) {
  const router = useRouter();
  const sp = useSearchParams();

  function go(next: Record<string, string>) {
    const merged = {
      q: initial.q,
      actor: initial.actor,
      genre: initial.genre,
      year: initial.year,
      type: initial.type,
      ...next,
    };
    const sp2 = new URLSearchParams();
    for (const [k, v] of Object.entries(merged)) if (v) sp2.set(k, v);
    const qs = sp2.toString();
    router.push(qs ? `/search?${qs}` : "/search");
  }

  function onGenreYearType(key: "genre" | "year" | "type", value: string) {
    go({ [key]: value });
  }

  const hasAny = !!(initial.q || initial.actor || initial.genre || initial.year);

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        const fd = new FormData(e.currentTarget);
        go({ q: String(fd.get("q") ?? ""), actor: String(fd.get("actor") ?? "") });
      }}
      className="rounded-xl border border-ink-700/60 bg-ink-900/60 p-4"
      role="search"
    >
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <label className="block">
          <span className="mb-1.5 block text-[11px] font-bold uppercase tracking-wider text-faint">
            Movie / Series name
          </span>
          <div className="relative">
            <IconSearch className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-faint" />
            <input
              name="q"
              defaultValue={initial.q}
              placeholder="e.g. Neon Requiem"
              className={`${selectCls} pl-9`}
            />
          </div>
        </label>
        <label className="block">
          <span className="mb-1.5 block text-[11px] font-bold uppercase tracking-wider text-faint">
            Actor
          </span>
          <input
            name="actor"
            defaultValue={initial.actor}
            placeholder="e.g. Ayesha Malik"
            className={selectCls}
          />
        </label>
        <label className="block">
          <span className="mb-1.5 block text-[11px] font-bold uppercase tracking-wider text-faint">
            Genre
          </span>
          <select
            value={initial.genre}
            onChange={(e) => onGenreYearType("genre", e.target.value)}
            className={selectCls}
          >
            <option value="">All genres</option>
            {genres.map((g) => (
              <option key={g} value={g}>
                {g}
              </option>
            ))}
          </select>
        </label>
        <label className="block">
          <span className="mb-1.5 block text-[11px] font-bold uppercase tracking-wider text-faint">
            Year
          </span>
          <select
            value={initial.year}
            onChange={(e) => onGenreYearType("year", e.target.value)}
            className={selectCls}
          >
            <option value="">Any year</option>
            {years.map((y) => (
              <option key={y} value={y}>
                {y}
              </option>
            ))}
          </select>
        </label>
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-3">
        <label className="flex items-center gap-2 text-sm text-mist">
          <span className="text-[11px] font-bold uppercase tracking-wider text-faint">
            Type
          </span>
          <select
            value={initial.type}
            onChange={(e) => onGenreYearType("type", e.target.value)}
            className="rounded-md border border-ink-700 bg-ink-900 px-3 py-1.5 text-xs font-semibold text-cream outline-none focus:border-gold-500/50"
          >
            <option value="">Movies &amp; Series</option>
            <option value="movie">Movies only</option>
            <option value="series">TV Series only</option>
          </select>
        </label>
        <button
          type="submit"
          className="ml-auto inline-flex items-center gap-2 rounded-md bg-gold-500 px-5 py-2.5 text-sm font-bold text-ink-950 transition-all hover:bg-gold-400 active:scale-95"
        >
          <IconSearch className="h-4 w-4" /> Search
        </button>
        {hasAny && (
          <button
            type="button"
            onClick={() => go({ q: "", actor: "", genre: "", year: "", type: "" })}
            className="inline-flex items-center gap-1.5 rounded-md border border-ink-600 px-4 py-2.5 text-xs font-bold text-mist transition-colors hover:border-bad/50 hover:text-bad"
          >
            <IconX className="h-3.5 w-3.5" /> Clear
          </button>
        )}
      </div>
    </form>
  );
}
