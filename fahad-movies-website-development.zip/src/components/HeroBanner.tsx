"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { IconClock, IconFilm, IconPlay, IconStar, IconTv } from "./icons";
import TrailerModal from "./TrailerModal";
import type { TitleData } from "@/lib/queries";

export default function HeroBanner({
  items,
  seasonMeta,
}: {
  items: TitleData[];
  seasonMeta: Record<number, { seasons: number; episodes: number }>;
}) {
  const [idx, setIdx] = useState(0);
  const [trailer, setTrailer] = useState<TitleData | null>(null);

  useEffect(() => {
    if (items.length < 2) return;
    const t = setInterval(() => setIdx((i) => (i + 1) % items.length), 8000);
    return () => clearInterval(t);
  }, [items.length]);

  if (items.length === 0) return null;
  const cur = items[Math.min(idx, items.length - 1)];

  return (
    <section className="relative h-[78vh] min-h-[520px] w-full overflow-hidden sm:h-[70vh]" aria-label="Featured">
      {items.map((t, i) => (
        <div
          key={t.id}
          className={`absolute inset-0 transition-opacity duration-1000 ${
            i === idx ? "opacity-100" : "opacity-0"
          }`}
          aria-hidden={i !== idx}
        >
          <img
            src={t.backdrop || t.poster}
            alt=""
            loading={i === 0 ? "eager" : "lazy"}
            className={`h-full w-full object-cover ${i === idx ? "scale-105 transition-transform duration-[9000ms]" : ""}`}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-ink-950 via-ink-950/70 to-ink-950/20" />
          <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-transparent to-ink-950/40" />
        </div>
      ))}

      {/* content */}
      <div className="relative z-10 mx-auto flex h-full max-w-7xl flex-col justify-end px-4 pb-16 sm:px-6 sm:pb-20 lg:px-8">
        <div key={cur.id} className="max-w-2xl anim-fade-up">
          <div className="mb-3 flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded bg-gold-500 px-2 py-0.5 text-[11px] font-black uppercase tracking-widest text-ink-950">
              {cur.type === "series" ? <IconTv className="h-3 w-3" /> : <IconFilm className="h-3 w-3" />}
              Featured {cur.type === "series" ? "Series" : "Movie"}
            </span>
            <span className="rounded border border-ink-600 bg-ink-900/70 px-2 py-0.5 text-[11px] font-bold text-mist">
              {cur.region}
            </span>
          </div>

          <h1 className="hero-title-shadow font-display text-5xl leading-[0.95] tracking-wide text-cream sm:text-7xl">
            {cur.title}
          </h1>

          <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 text-sm">
            <span className="inline-flex items-center gap-1.5 font-bold text-gold-400">
              <IconStar className="h-4 w-4" /> {Number(cur.rating).toFixed(1)}
              <span className="font-semibold text-mist">/ 10</span>
            </span>
            <span className="inline-flex items-center gap-1.5 text-mist">
              <IconClock className="h-4 w-4" />
              {cur.type === "series"
                ? `${seasonMeta[cur.id]?.seasons ?? 1} Season${(seasonMeta[cur.id]?.seasons ?? 0) > 1 ? "s" : ""} · ${seasonMeta[cur.id]?.episodes ?? 0} Episodes`
                : `${cur.duration} min`}
            </span>
            <span className="text-mist">{cur.year}</span>
            <span className="text-xs font-semibold text-faint">
              {cur.genres.slice(0, 3).join(" · ")}
            </span>
          </div>

          <p className="mt-4 line-clamp-3 max-w-xl text-sm leading-relaxed text-cream/80 sm:text-base">
            {cur.description}
          </p>

          <div className="mt-6 flex flex-wrap items-center gap-3">
            <Link
              href={`/watch/${cur.slug}`}
              className="inline-flex items-center gap-2 rounded-md bg-gold-500 px-6 py-3 text-sm font-black uppercase tracking-wider text-ink-950 shadow-xl shadow-gold-500/25 transition-all hover:bg-gold-400 active:scale-95"
            >
              <IconPlay className="h-4 w-4" />
              {cur.type === "series" ? "Watch S1 E1" : "Watch Now"}
            </Link>
            <button
              onClick={() => setTrailer(cur)}
              className="inline-flex items-center gap-2 rounded-md border border-cream/25 bg-ink-950/50 px-6 py-3 text-sm font-bold uppercase tracking-wider text-cream backdrop-blur transition-all hover:border-gold-400/60 hover:text-gold-300 active:scale-95"
            >
              Watch Trailer
            </button>
            <Link
              href={`/title/${cur.slug}`}
              className="inline-flex items-center gap-2 rounded-md px-4 py-3 text-sm font-bold uppercase tracking-wider text-mist transition-colors hover:text-cream"
            >
              {cur.type === "series" ? "Series Details" : "Movie Details"}
            </Link>
          </div>
        </div>

        {/* dots */}
        <div className="mt-8 flex gap-2">
          {items.map((t, i) => (
            <button
              key={t.id}
              onClick={() => setIdx(i)}
              aria-label={`Show featured: ${t.title}`}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                i === idx ? "w-8 bg-gold-400" : "w-3 bg-cream/30 hover:bg-cream/50"
              }`}
            />
          ))}
        </div>
      </div>

      <TrailerModal
        open={!!trailer}
        src={trailer?.trailer}
        title={trailer?.title ?? ""}
        onClose={() => setTrailer(null)}
      />
    </section>
  );
}
