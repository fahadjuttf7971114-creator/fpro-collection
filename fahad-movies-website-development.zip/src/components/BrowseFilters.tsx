"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useCallback } from "react";

type Chip = { key: string; label: string };

function ChipRow({
  label,
  chips,
  activeKey,
  onPick,
}: {
  label: string;
  chips: Chip[];
  activeKey: string;
  onPick: (key: string) => void;
}) {
  return (
    <div className="flex flex-wrap items-center gap-1.5">
      <span className="mr-1 w-14 shrink-0 text-[11px] font-bold uppercase tracking-wider text-faint">
        {label}
      </span>
      <button
        onClick={() => onPick("all")}
        className={`rounded-full px-3 py-1 text-xs font-semibold transition-all ${
          activeKey === "all"
            ? "bg-gold-500 text-ink-950"
            : "border border-ink-700 bg-ink-900 text-mist hover:border-gold-500/40 hover:text-cream"
        }`}
      >
        All
      </button>
      {chips.map((c) => (
        <button
          key={c.key}
          onClick={() => onPick(c.key)}
          className={`rounded-full px-3 py-1 text-xs font-semibold transition-all ${
            activeKey === c.key
              ? "bg-gold-500 text-ink-950"
              : "border border-ink-700 bg-ink-900 text-mist hover:border-gold-500/40 hover:text-cream"
          }`}
        >
          {c.label}
        </button>
      ))}
    </div>
  );
}

export default function BrowseFilters({
  params,
  genres,
  regions,
  years,
  withSort = true,
}: {
  params: { genre?: string; region?: string; year?: string; sort?: string };
  genres: string[];
  regions: string[];
  years: number[];
  withSort?: boolean;
}) {
  const router = useRouter();
  const searchParams = useSearchParams();

  const setParam = useCallback(
    (key: string, value?: string) => {
      const sp = new URLSearchParams(searchParams.toString());
      if (value === undefined || value === "all" || value === "") sp.delete(key);
      else sp.set(key, value);
      const qs = sp.toString();
      router.push(qs ? `?${qs}` : window.location.pathname.split("?")[0]);
    },
    [router, searchParams]
  );

  const setSort = (value: string) => {
    const sp = new URLSearchParams(searchParams.toString());
    if (!value || value === "latest") sp.delete("sort");
    else sp.set("sort", value);
    const qs = sp.toString();
    router.push(qs ? `?${qs}` : window.location.pathname);
  };

  return (
    <div className="mb-8 space-y-3 rounded-xl border border-ink-700/60 bg-ink-900/50 p-4">
      <ChipRow
        label="Genre"
        chips={genres.map((g) => ({ key: g, label: g }))}
        activeKey={params.genre ?? "all"}
        onPick={(k) => setParam("genre", k)}
      />
      <ChipRow
        label="Region"
        chips={regions.map((r) => ({ key: r, label: r }))}
        activeKey={params.region ?? "all"}
        onPick={(k) => setParam("region", k)}
      />
      <ChipRow
        label="Year"
        chips={years.map((y) => ({ key: String(y), label: String(y) }))}
        activeKey={params.year ?? "all"}
        onPick={(k) => setParam("year", k)}
      />
      {withSort && (
        <div className="flex items-center gap-2 pt-1">
          <span className="text-[11px] font-bold uppercase tracking-wider text-faint">
            Sort
          </span>
          <select
            value={params.sort ?? "latest"}
            onChange={(e) => setSort(e.target.value)}
            className="rounded-md border border-ink-700 bg-ink-900 px-3 py-1.5 text-xs font-semibold text-cream outline-none focus:border-gold-500/50"
          >
            <option value="latest">Latest releases</option>
            <option value="popular">Most popular</option>
            <option value="trending">Trending</option>
            <option value="rating">Top rated</option>
          </select>
        </div>
      )}
    </div>
  );
}
