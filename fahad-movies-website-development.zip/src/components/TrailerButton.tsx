"use client";

import { useState } from "react";
import TrailerModal from "./TrailerModal";
import { IconPlay } from "./icons";

export default function TrailerButton({
  trailer,
  title,
}: {
  trailer: string;
  title: string;
}) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button
        onClick={() => setOpen(true)}
        disabled={!trailer}
        className="inline-flex items-center gap-2 rounded-md border border-ink-600 bg-ink-900/60 px-5 py-3 text-sm font-bold uppercase tracking-wider text-cream transition-all hover:border-gold-400/60 hover:text-gold-300 active:scale-95 disabled:cursor-not-allowed disabled:opacity-50"
      >
        <IconPlay className="h-4 w-4" /> Watch Trailer
      </button>
      <TrailerModal open={open} src={trailer} title={title} onClose={() => setOpen(false)} />
    </>
  );
}
