import Link from "next/link";
import { IconChevronRight } from "./icons";

export default function CategoryStrip({
  genres,
  regions,
}: {
  genres: { name: string; count: number }[];
  regions: { name: string; count: number }[];
}) {
  return (
    <section className="rounded-xl border border-ink-700/60 bg-ink-900/50 p-4 sm:p-5">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="font-display text-xl tracking-wide text-cream sm:text-2xl">
          Browse Categories
        </h2>
        <Link
          href="/genres"
          className="inline-flex items-center gap-1 text-xs font-bold uppercase tracking-wider text-mist transition-colors hover:text-gold-400"
        >
          All categories <IconChevronRight className="h-3.5 w-3.5" />
        </Link>
      </div>
      <div className="flex flex-wrap gap-2">
        {genres.map((g) => (
          <Link
            key={g.name}
            href={`/movies?genre=${encodeURIComponent(g.name)}`}
            className="group inline-flex items-center gap-2 rounded-full border border-ink-600 bg-ink-800/70 px-4 py-2 text-sm font-semibold text-mist transition-all hover:-translate-y-0.5 hover:border-gold-500/50 hover:text-gold-300"
          >
            {g.name}
            <span className="rounded-full bg-ink-950/60 px-1.5 py-0.5 text-[10px] font-bold text-faint group-hover:text-gold-400">
              {g.count}
            </span>
          </Link>
        ))}
        {regions.map((r) => (
          <Link
            key={r.name}
            href={`/movies?region=${encodeURIComponent(r.name)}`}
            className="inline-flex items-center gap-2 rounded-full border border-gold-500/30 bg-gold-500/10 px-4 py-2 text-sm font-bold text-gold-300 transition-all hover:-translate-y-0.5 hover:border-gold-400/60 hover:bg-gold-500/20"
          >
            {r.name}
            <span className="rounded-full bg-ink-950/40 px-1.5 py-0.5 text-[10px] font-bold text-gold-400/80">
              {r.count}
            </span>
          </Link>
        ))}
      </div>
    </section>
  );
}
