"use client";

import { useCallback, useRef, useState } from "react";
import Link from "next/link";
import TitleForm from "./TitleForm";
import PosterImg from "./PosterImg";
import { api, type AdminGenre, type AdminStats, type AdminTitle } from "./adminTypes";
import {
  IconCheck,
  IconEdit,
  IconEye,
  IconFilm,
  IconGauge,
  IconLayers,
  IconPlus,
  IconSparkle,
  IconTrash,
  IconTv,
  IconUser,
  IconX,
} from "./icons";

type Tab = "overview" | "content" | "genres";
type Notice = { kind: "ok" | "err"; msg: string } | null;

export default function AdminPanel({
  stats: initialStats,
  titles: initialTitles,
  genres: initialGenres,
}: {
  stats: AdminStats;
  titles: AdminTitle[];
  genres: AdminGenre[];
}) {
  const [tab, setTab] = useState<Tab>("overview");
  const [stats, setStats] = useState(initialStats);
  const [titles, setTitles] = useState(initialTitles);
  const [genres, setGenres] = useState(initialGenres);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<AdminTitle | null>(null);
  const [confirmId, setConfirmId] = useState<number | null>(null);
  const [notice, setNotice] = useState<Notice>(null);
  const noticeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // genre tab state
  const [newGenre, setNewGenre] = useState("");
  const [rename, setRename] = useState<Record<number, string>>({});
  const [busyKey, setBusyKey] = useState<string | null>(null);

  const flash = useCallback((kind: "ok" | "err", msg: string) => {
    setNotice({ kind, msg });
    if (noticeTimer.current) clearTimeout(noticeTimer.current);
    noticeTimer.current = setTimeout(() => setNotice(null), 4000);
  }, []);

  const refresh = useCallback(async () => {
    try {
      const [t, s, g] = await Promise.all([
        api<{ items: AdminTitle[] }>("/api/titles?withSeasons=1&limit=300"),
        api<{ stats: AdminStats }>("/api/stats"),
        api<{ items: AdminGenre[] }>("/api/genres"),
      ]);
      setTitles(t.items);
      setStats(s.stats);
      setGenres(g.items);
    } catch {
      /* keep previous data */
    }
  }, []);

  function openAdd() {
    setEditing(null);
    setFormOpen(true);
  }

  function openEdit(t: AdminTitle) {
    setEditing(t);
    setFormOpen(true);
  }

  async function deleteTitle(t: AdminTitle) {
    if (confirmId !== t.id) {
      setConfirmId(t.id);
      setTimeout(() => setConfirmId((c) => (c === t.id ? null : c)), 3000);
      return;
    }
    try {
      await api(`/api/titles/${t.id}`, { method: "DELETE" });
      flash("ok", `“${t.title}” deleted.`);
      await refresh();
    } catch (e) {
      flash("err", e instanceof Error ? e.message : "Delete failed.");
    }
    setConfirmId(null);
  }

  async function addGenre() {
    if (newGenre.trim().length < 2) return;
    setBusyKey("new-genre");
    try {
      await api("/api/genres", { method: "POST", body: JSON.stringify({ name: newGenre.trim() }) });
      flash("ok", `Genre “${newGenre.trim()}” added.`);
      setNewGenre("");
      await refresh();
    } catch (e) {
      flash("err", e instanceof Error ? e.message : "Failed.");
    } finally {
      setBusyKey(null);
    }
  }

  async function toggleGenre(g: AdminGenre) {
    setBusyKey(`g-${g.id}`);
    try {
      await api(`/api/genres/${g.id}`, { method: "PATCH", body: JSON.stringify({ active: !g.active }) });
      flash("ok", `“${g.name}” ${g.active ? "hidden from" : "added to"} site categories.`);
      await refresh();
    } catch (e) {
      flash("err", e instanceof Error ? e.message : "Failed.");
    } finally {
      setBusyKey(null);
    }
  }

  async function saveRename(g: AdminGenre) {
    const name = (rename[g.id] ?? g.name).trim();
    if (name === g.name || name.length < 2) return;
    setBusyKey(`r-${g.id}`);
    try {
      await api(`/api/genres/${g.id}`, { method: "PATCH", body: JSON.stringify({ name }) });
      flash("ok", `Genre renamed to “${name}”. Titles were updated.`);
      await refresh();
    } catch (e) {
      flash("err", e instanceof Error ? e.message : "Failed.");
    } finally {
      setBusyKey(null);
    }
  }

  async function deleteGenre(g: AdminGenre) {
    if (g.count > 0) {
      flash("err", `“${g.name}” is used by ${g.count} title(s). Remove it from those titles first.`);
      return;
    }
    setBusyKey(`d-${g.id}`);
    try {
      await api(`/api/genres/${g.id}`, { method: "DELETE" });
      flash("ok", `Genre “${g.name}” deleted.`);
      await refresh();
    } catch (e) {
      flash("err", e instanceof Error ? e.message : "Failed.");
    } finally {
      setBusyKey(null);
    }
  }

  const maxViews = Math.max(1, ...stats.top.map((t) => t.views));

  const tabBtn = (id: Tab, label: string, icon: React.ReactNode) => (
    <button
      key={id}
      onClick={() => setTab(id)}
      className={`inline-flex items-center gap-2 rounded-md px-4 py-2.5 text-sm font-bold transition-colors ${
        tab === id ? "bg-gold-500 text-ink-950" : "text-mist hover:bg-ink-800 hover:text-cream"
      }`}
    >
      {icon}
      {label}
    </button>
  );

  return (
    <div>
      {notice && (
        <div
          className={`mb-5 flex items-center justify-between rounded-lg border px-4 py-3 text-sm font-semibold anim-fade-in ${
            notice.kind === "ok"
              ? "border-good/40 bg-good/10 text-good"
              : "border-bad/40 bg-bad/10 text-bad"
          }`}
        >
          <span>{notice.msg}</span>
          <button onClick={() => setNotice(null)} aria-label="Dismiss">
            <IconX className="h-4 w-4" />
          </button>
        </div>
      )}

      {/* tabs */}
      <div className="mb-6 flex flex-wrap gap-1.5 rounded-xl border border-ink-700/60 bg-ink-900/50 p-1.5">
        {tabBtn("overview", "Overview", <IconGauge className="h-4 w-4" />)}
        {tabBtn("content", "Content", <IconFilm className="h-4 w-4" />)}
        {tabBtn("genres", "Genres", <IconLayers className="h-4 w-4" />)}
      </div>

      {/* OVERVIEW */}
      {tab === "overview" && (
        <div className="space-y-6 anim-fade-in">
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            {[
              { label: "Total titles", value: stats.totals.titles, icon: <IconFilm className="h-5 w-5" />, sub: `${stats.totals.movies} movies · ${stats.totals.series} series` },
              { label: "Total views", value: stats.totals.views, icon: <IconEye className="h-5 w-5" />, sub: "across the whole catalog" },
              { label: "Registered users", value: stats.totals.users, icon: <IconUser className="h-5 w-5" />, sub: `${stats.totals.favorites} favorite entries` },
              { label: "Featured on home", value: stats.totals.featured, icon: <IconSparkle className="h-5 w-5" />, sub: "shown in the hero banner" },
            ].map((c) => (
              <div key={c.label} className="rounded-xl border border-ink-700 bg-ink-900/60 p-4">
                <div className="flex items-center justify-between">
                  <p className="text-[11px] font-bold uppercase tracking-wider text-faint">{c.label}</p>
                  <span className="text-gold-400">{c.icon}</span>
                </div>
                <p className="mt-2 font-display text-4xl text-cream">
                  {c.value.toLocaleString()}
                </p>
                <p className="mt-1 text-xs text-faint">{c.sub}</p>
              </div>
            ))}
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            <div className="rounded-xl border border-ink-700 bg-ink-900/60 p-5">
              <h3 className="font-display text-2xl tracking-wide">Most watched</h3>
              <div className="mt-4 space-y-3">
                {stats.top.length === 0 && (
                  <p className="text-sm text-faint">No views recorded yet.</p>
                )}
                {stats.top.map((t) => (
                  <Link key={t.id} href={`/title/${t.slug}`} className="group block">
                    <div className="flex items-center justify-between text-sm">
                      <span className="flex min-w-0 items-center gap-2">
                        {t.type === "series" ? (
                          <IconTv className="h-3.5 w-3.5 shrink-0 text-faint" />
                        ) : (
                          <IconFilm className="h-3.5 w-3.5 shrink-0 text-faint" />
                        )}
                        <span className="truncate font-semibold text-cream/90 group-hover:text-gold-300">
                          {t.title}
                        </span>
                      </span>
                      <span className="ml-3 shrink-0 font-mono text-xs text-faint">
                        {t.views.toLocaleString()}
                      </span>
                    </div>
                    <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-ink-800">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-gold-600 to-gold-400 transition-all"
                        style={{ width: `${Math.max(4, (t.views / maxViews) * 100)}%` }}
                      />
                    </div>
                  </Link>
                ))}
              </div>
            </div>

            <div className="rounded-xl border border-ink-700 bg-ink-900/60 p-5">
              <h3 className="font-display text-2xl tracking-wide">Newest members</h3>
              <ul className="mt-4 space-y-2.5">
                {stats.recentUsers.length === 0 && (
                  <li className="text-sm text-faint">No users yet.</li>
                )}
                {stats.recentUsers.map((u) => (
                  <li
                    key={u.email}
                    className="flex items-center gap-3 rounded-lg border border-ink-700/60 bg-ink-800/40 px-3 py-2.5"
                  >
                    <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-gold-500/15 text-sm font-bold text-gold-400">
                      {u.name[0]?.toUpperCase()}
                    </span>
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold">{u.name}</p>
                      <p className="truncate text-xs text-faint">{u.email}</p>
                    </div>
                    <span className="ml-auto shrink-0 text-[11px] text-faint">
                      {new Date(u.createdAt).toLocaleDateString("en-US", {
                        month: "short",
                        day: "numeric",
                        year: "numeric",
                      })}
                    </span>
                  </li>
                ))}
              </ul>
              <div className="mt-5 grid grid-cols-2 gap-2">
                <button
                  onClick={openAdd}
                  className="inline-flex items-center justify-center gap-1.5 rounded-md bg-gold-500 px-4 py-2.5 text-xs font-black uppercase tracking-wider text-ink-950 hover:bg-gold-400"
                >
                  <IconPlus className="h-4 w-4" /> Add title
                </button>
                <button
                  onClick={() => setTab("genres")}
                  className="rounded-md border border-ink-600 px-4 py-2.5 text-xs font-bold uppercase tracking-wider text-mist hover:border-gold-500/50 hover:text-gold-300"
                >
                  Manage genres
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CONTENT */}
      {tab === "content" && (
        <div className="anim-fade-in">
          <div className="mb-4 flex items-center justify-between">
            <p className="text-sm text-mist">
              {titles.length} title{titles.length === 1 ? "" : "s"} in the catalog.
            </p>
            <button
              onClick={() => (formOpen ? setFormOpen(false) : openAdd())}
              className="inline-flex items-center gap-2 rounded-md bg-gold-500 px-4 py-2.5 text-xs font-black uppercase tracking-wider text-ink-950 hover:bg-gold-400"
            >
              <IconPlus className="h-4 w-4" /> {formOpen ? "Close form" : "Add movie / series"}
            </button>
          </div>

          {formOpen && (
            <div className="mb-6">
              <TitleForm
                genres={genres.filter((g) => g.active || (editing?.genres ?? []).includes(g.name)).map((g) => g.name)}
                initial={editing}
                onCancel={() => setFormOpen(false)}
                onDone={() => {
                  setFormOpen(false);
                  setEditing(null);
                  flash("ok", editing ? "Title updated." : "Title created.");
                  refresh();
                }}
                onSeasonsChanged={() => refresh()}
              />
            </div>
          )}

          <div className="overflow-x-auto rounded-xl border border-ink-700 bg-ink-900/50">
            <table className="w-full min-w-[760px] text-left text-sm">
              <thead>
                <tr className="border-b border-ink-700/70 text-[11px] uppercase tracking-wider text-faint">
                  <th className="px-4 py-3 font-bold">Title</th>
                  <th className="px-3 py-3 font-bold">Type</th>
                  <th className="px-3 py-3 font-bold">Year</th>
                  <th className="px-3 py-3 font-bold">Rating</th>
                  <th className="px-3 py-3 font-bold">Views</th>
                  <th className="px-3 py-3 font-bold">Flags</th>
                  <th className="px-3 py-3 text-right font-bold">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ink-700/40">
                {titles.map((t) => (
                  <tr key={t.id} className="transition-colors hover:bg-ink-800/40">
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-3">
                        <div className="h-14 w-9 shrink-0 overflow-hidden rounded border border-ink-700">
                          <PosterImg src={t.poster} alt={t.title} className="h-full w-full" />
                        </div>
                        <div className="min-w-0">
                          <Link href={`/title/${t.slug}`} className="block truncate font-bold text-cream hover:text-gold-300">
                            {t.title}
                          </Link>
                          <p className="truncate text-xs text-faint">
                            {t.genres.slice(0, 3).join(" · ") || "—"} · {t.region}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-3 py-2.5">
                      <span
                        className={`inline-flex items-center gap-1 rounded px-2 py-0.5 text-[11px] font-bold ${
                          t.type === "series"
                            ? "bg-[#164e63]/50 text-[#7dd3fc]"
                            : "bg-ink-700/60 text-mist"
                        }`}
                      >
                        {t.type === "series" ? <IconTv className="h-3 w-3" /> : <IconFilm className="h-3 w-3" />}
                        {t.type === "series" ? "Series" : "Movie"}
                      </span>
                    </td>
                    <td className="px-3 py-2.5 text-mist">{t.year}</td>
                    <td className="px-3 py-2.5 font-semibold text-gold-400">
                      {Number(t.rating).toFixed(1)}
                    </td>
                    <td className="px-3 py-2.5 font-mono text-xs text-mist">
                      {t.views.toLocaleString()}
                    </td>
                    <td className="px-3 py-2.5">
                      <div className="flex gap-1">
                        {t.isFeatured && (
                          <span title="Featured" className="grid h-5 w-5 place-items-center rounded bg-gold-500/20 text-gold-400">
                            <IconSparkle className="h-3 w-3" />
                          </span>
                        )}
                        {t.isTrending && (
                          <span title="Trending" className="grid h-5 w-5 place-items-center rounded bg-live/20 text-live">
                            <IconGauge className="h-3 w-3" />
                          </span>
                        )}
                        {t.isPopular && (
                          <span title="Popular" className="grid h-5 w-5 place-items-center rounded bg-good/20 text-good">
                            <IconEye className="h-3 w-3" />
                          </span>
                        )}
                        {!t.isFeatured && !t.isTrending && !t.isPopular && (
                          <span className="text-xs text-faint">—</span>
                        )}
                      </div>
                    </td>
                    <td className="px-3 py-2.5">
                      <div className="flex justify-end gap-1.5">
                        <button
                          onClick={() => openEdit(t)}
                          aria-label={`Edit ${t.title}`}
                          className="grid h-8 w-8 place-items-center rounded-md border border-ink-600 text-mist hover:border-gold-500/50 hover:text-gold-400"
                        >
                          <IconEdit className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => deleteTitle(t)}
                          aria-label={`Delete ${t.title}`}
                          className={`inline-flex h-8 items-center gap-1 rounded-md border px-2 text-xs font-bold transition-all ${
                            confirmId === t.id
                              ? "border-bad bg-bad/20 text-bad"
                              : "border-ink-600 text-mist hover:border-bad/50 hover:text-bad"
                          }`}
                        >
                          {confirmId === t.id ? (
                            <>
                              <IconCheck className="h-3.5 w-3.5" /> Sure?
                            </>
                          ) : (
                            <IconTrash className="h-4 w-4" />
                          )}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {titles.length === 0 && (
                  <tr>
                    <td colSpan={7} className="px-4 py-10 text-center text-sm text-faint">
                      The catalog is empty. Add your first title.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* GENRES */}
      {tab === "genres" && (
        <div className="anim-fade-in">
          <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
            <p className="text-sm text-mist">
              Categories shown on the Genres page, filter bars and in search.
            </p>
            <div className="flex gap-2">
              <input
                value={newGenre}
                onChange={(e) => setNewGenre(e.target.value)}
                placeholder="New genre, e.g. Documentary"
                className="rounded-md border border-ink-700 bg-ink-900 px-3 py-2 text-sm text-cream placeholder-faint outline-none focus:border-gold-500/60"
                onKeyDown={(e) => e.key === "Enter" && addGenre()}
              />
              <button
                onClick={addGenre}
                disabled={busyKey === "new-genre" || newGenre.trim().length < 2}
                className="rounded-md bg-gold-500 px-4 py-2 text-xs font-black uppercase tracking-wider text-ink-950 hover:bg-gold-400 disabled:opacity-50"
              >
                {busyKey === "new-genre" ? "Adding…" : "Add genre"}
              </button>
            </div>
          </div>

          <div className="overflow-hidden rounded-xl border border-ink-700 bg-ink-900/50">
            <ul className="divide-y divide-ink-700/40">
              {genres.map((g) => (
                <li key={g.id} className="flex flex-wrap items-center gap-3 px-4 py-3">
                  <span
                    className={`h-2.5 w-2.5 shrink-0 rounded-full ${g.active ? "bg-good" : "bg-ink-600"}`}
                    aria-hidden
                  />
                  <div className="min-w-0 flex-1">
                    {rename[g.id] !== undefined && rename[g.id] !== g.name ? (
                      <div className="flex items-center gap-2">
                        <input
                          value={rename[g.id]}
                          onChange={(e) => setRename((r) => ({ ...r, [g.id]: e.target.value }))}
                          className="w-44 rounded-md border border-gold-500/50 bg-ink-900 px-3 py-1.5 text-sm outline-none"
                          aria-label={`Rename ${g.name}`}
                        />
                        <button
                          onClick={() => saveRename(g)}
                          disabled={busyKey === `r-${g.id}`}
                          className="grid h-8 w-8 place-items-center rounded-md bg-gold-500 text-ink-950 hover:bg-gold-400"
                          aria-label="Save rename"
                        >
                          <IconCheck className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => setRename((r) => {
                            const n = { ...r };
                            delete n[g.id];
                            return n;
                          })}
                          className="text-xs font-bold text-faint hover:text-cream"
                        >
                          Cancel
                        </button>
                      </div>
                    ) : (
                      <>
                        <p className="font-bold text-cream">{g.name}</p>
                        <p className="text-xs text-faint">
                          {g.count} title{g.count === 1 ? "" : "s"} ·{" "}
                          {g.active ? "active" : "hidden"}
                        </p>
                      </>
                    )}
                  </div>
                  {rename[g.id] === undefined && (
                    <>
                      <button
                        onClick={() => setRename((r) => ({ ...r, [g.id]: g.name }))}
                        aria-label={`Rename ${g.name}`}
                        className="grid h-8 w-8 place-items-center rounded-md border border-ink-600 text-mist hover:border-gold-500/50 hover:text-gold-400"
                      >
                        <IconEdit className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => toggleGenre(g)}
                        disabled={busyKey === `g-${g.id}`}
                        aria-label={g.active ? `Hide ${g.name}` : `Show ${g.name}`}
                        className={`relative h-6 w-11 rounded-full transition-colors ${g.active ? "bg-gold-500" : "bg-ink-600"}`}
                      >
                        <span
                          className={`absolute top-0.5 h-5 w-5 rounded-full bg-ink-950 transition-all ${g.active ? "left-[22px]" : "left-0.5"}`}
                        />
                      </button>
                      <button
                        onClick={() => deleteGenre(g)}
                        disabled={busyKey === `d-${g.id}`}
                        aria-label={`Delete ${g.name}`}
                        className={`grid h-8 w-8 place-items-center rounded-md border ${
                          g.count > 0
                            ? "cursor-not-allowed border-ink-700 text-faint/50"
                            : "border-ink-600 text-mist hover:border-bad/50 hover:text-bad"
                        }`}
                      >
                        <IconTrash className="h-4 w-4" />
                      </button>
                    </>
                  )}
                </li>
              ))}
            </ul>
          </div>
          <p className="mt-3 text-xs text-faint">
            Renaming a genre updates every title that uses it. Genres still attached to
            titles cannot be deleted.
          </p>
        </div>
      )}
    </div>
  );
}
