"use client";

import Link from "next/link";
import { useRef } from "react";
import TitleCard from "./TitleCard";
import { IconChevronLeft, IconChevronRight } from "./icons";
import type { TitleData } from "@/lib/queries";

export default function TitleRow({
  title,
  href,
  items,
  seasonMeta,
}: {
  title: string;
  href?: string;
  items: TitleData[];
  seasonMeta?: Record<number, { seasons: number; episodes: number }>;
}) {
  const ref = useRef<HTMLDivElement>(null);

  if (items.length === 0) return null;

  const scroll = (dir: 1 | -1) =>
    ref.current?.scrollBy({ left: dir * ref.current.clientWidth * 0.8, behavior: "smooth" });

  return (
    <section className="group/row relative">
      <div className="mb-4 flex items-end justify-between px-4 sm:px-6 lg:px-8">
        <h2 className="font-display text-2xl tracking-wide text-cream sm:text-3xl">
          {title}
        </h2>
        <div className="flex items-center gap-2">
          {href && (
            <Link
              href={href}
              className="text-xs font-bold uppercase tracking-wider text-mist transition-colors hover:text-gold-400"
            >
              See all
            </Link>
          )}
          <div className="hidden gap-1 md:flex">
            <button
              onClick={() => scroll(-1)}
              aria-label="Scroll left"
              className="grid h-8 w-8 place-items-center rounded-md border border-ink-700 bg-ink-900 text-mist opacity-0 transition-all hover:border-gold-500/40 hover:text-gold-400 group-hover/row:opacity-100"
            >
              <IconChevronLeft className="h-4 w-4" />
            </button>
            <button
              onClick={() => scroll(1)}
              aria-label="Scroll right"
              className="grid h-8 w-8 place-items-center rounded-md border border-ink-700 bg-ink-900 text-mist opacity-0 transition-all hover:border-gold-500/40 hover:text-gold-400 group-hover/row:opacity-100"
            >
              <IconChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
      <div
        ref={ref}
        className="no-scrollbar flex snap-x gap-3 overflow-x-auto px-4 pb-2 sm:px-6 lg:px-8"
      >
        {items.map((t) => (
          <TitleCard
            key={t.id}
            t={t}
            seasonCount={seasonMeta?.[t.id]?.seasons}
            episodeCount={seasonMeta?.[t.id]?.episodes}
          />
        ))}
      </div>
    </section>
  );
}
