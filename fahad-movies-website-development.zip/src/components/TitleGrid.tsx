import TitleCard from "./TitleCard";
import type { TitleData } from "@/lib/queries";

export default function TitleGrid({
  items,
  cols = "grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6",
}: {
  items: TitleData[];
  cols?: string;
}) {
  if (items.length === 0) return null;
  return (
    <div className={`grid gap-x-3 gap-y-6 ${cols}`}>
      {items.map((t) => (
        <TitleCard key={t.id} t={t} />
      ))}
    </div>
  );
}
