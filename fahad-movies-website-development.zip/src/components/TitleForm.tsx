"use client";

import { useState } from "react";
import ImageField from "./ImageField";
import SeasonManager from "./SeasonManager";
import { api, SAMPLE_MOVIES, SAMPLE_TRAILERS, type AdminTitle } from "./adminTypes";
import { IconX } from "./icons";

const inputCls =
  "w-full rounded-md border border-ink-700 bg-ink-900 px-3 py-2 text-sm text-cream placeholder-faint outline-none transition-colors focus:border-gold-500/60";
const labelCls = "mb-1.5 block text-[11px] font-bold uppercase tracking-wider text-faint";

export default function TitleForm({
  genres,
  initial,
  onDone,
  onCancel,
  onSeasonsChanged,
}: {
  genres: string[];
  initial: AdminTitle | null;
  onDone: () => void;
  onCancel: () => void;
  onSeasonsChanged: () => void;
}) {
  const t = initial;
  const [title, setTitle] = useState(t?.title ?? "");
  const [type, setType] = useState<"movie" | "series">(t?.type ?? "movie");
  const [year, setYear] = useState(t?.year ?? new Date().getFullYear());
  const [rating, setRating] = useState(t?.rating ?? 7);
  const [duration, setDuration] = useState(t?.duration ?? 0);
  const [region, setRegion] = useState(t?.region ?? "Hollywood");
  const [description, setDescription] = useState(t?.description ?? "");
  const [poster, setPoster] = useState(t?.poster ?? "");
  const [backdrop, setBackdrop] = useState(t?.backdrop ?? "");
  const [trailer, setTrailer] = useState(t?.trailer ?? "");
  const [video, setVideo] = useState(t?.video ?? "");
  const [cast, setCast] = useState((t?.cast ?? []).join(", "));
  const [genreSet, setGenreSet] = useState<Set<string>>(new Set(t?.genres ?? []));
  const [isFeatured, setIsFeatured] = useState(t?.isFeatured ?? false);
  const [isTrending, setIsTrending] = useState(t?.isTrending ?? false);
  const [isPopular, setIsPopular] = useState(t?.isPopular ?? false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  function toggleGenre(g: string) {
    const next = new Set(genreSet);
    if (next.has(g)) next.delete(g);
    else next.add(g);
    setGenreSet(next);
  }

  const flag = (
    label: string,
    value: boolean,
    set: (v: boolean) => void
  ) => (
    <label className="flex cursor-pointer items-center gap-2 rounded-md border border-ink-700 bg-ink-900/70 px-3 py-2 text-sm font-semibold text-mist hover:border-gold-500/40">
      <input
        type="checkbox"
        checked={value}
        onChange={(e) => set(e.target.checked)}
        className="h-4 w-4 accent-[#eab556]"
      />
      {label}
    </label>
  );

  async function save() {
    setError(null);
    if (title.trim().length < 2) return setError("Title is required.");
    setBusy(true);
    try {
      const body = {
        title: title.trim(),
        type,
        year: Number(year),
        rating: Number(rating),
        duration: Number(duration),
        region,
        description,
        poster,
        backdrop,
        trailer,
        video,
        cast: cast.split(",").map((s) => s.trim()).filter(Boolean),
        genres: [...genreSet],
        isFeatured,
        isTrending,
        isPopular,
      };
      if (t) {
        await api(`/api/titles/${t.id}`, {
          method: "PATCH",
          body: JSON.stringify(body),
        });
      } else {
        await api("/api/titles", { method: "POST", body: JSON.stringify(body) });
      }
      onDone();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Save failed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="rounded-xl border border-gold-500/30 bg-ink-900/70 p-5 anim-fade-up">
      <div className="mb-5 flex items-center justify-between">
        <h3 className="font-display text-3xl tracking-wide">
          {t ? `Edit: ${t.title}` : "Add New Title"}
        </h3>
        <button
          onClick={onCancel}
          aria-label="Close form"
          className="grid h-9 w-9 place-items-center rounded-md text-mist hover:bg-ink-800 hover:text-cream"
        >
          <IconX className="h-5 w-5" />
        </button>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <div className="sm:col-span-2">
          <span className={labelCls}>Title *</span>
          <input value={title} onChange={(e) => setTitle(e.target.value)} className={inputCls} placeholder="e.g. Neon Requiem" />
        </div>
        <div>
          <span className={labelCls}>Type</span>
          <select value={type} onChange={(e) => setType(e.target.value as "movie" | "series")} className={inputCls}>
            <option value="movie">Movie</option>
            <option value="series">TV Series</option>
          </select>
        </div>
        <div>
          <span className={labelCls}>Year</span>
          <input type="number" min={1900} max={2100} value={year} onChange={(e) => setYear(Number(e.target.value))} className={inputCls} />
        </div>
        <div>
          <span className={labelCls}>Rating (0–10)</span>
          <input type="number" step={0.1} min={0} max={10} value={rating} onChange={(e) => setRating(Number(e.target.value))} className={inputCls} />
        </div>
        {type === "movie" ? (
          <div>
            <span className={labelCls}>Duration (minutes)</span>
            <input type="number" min={0} max={900} value={duration} onChange={(e) => setDuration(Number(e.target.value))} className={inputCls} />
          </div>
        ) : (
          <div className="hidden sm:block" />
        )}
        <div>
          <span className={labelCls}>Region</span>
          <select value={region} onChange={(e) => setRegion(e.target.value)} className={inputCls}>
            <option>Hollywood</option>
            <option>Bollywood</option>
            <option>Pakistani</option>
          </select>
        </div>
        <div className="sm:col-span-2 lg:col-span-3">
          <span className={labelCls}>Description</span>
          <textarea
            rows={4}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className={`${inputCls} resize-y`}
            placeholder="What is this story about?"
          />
        </div>
        <div className="sm:col-span-2 lg:col-span-3">
          <span className={labelCls}>Cast (comma separated)</span>
          <input value={cast} onChange={(e) => setCast(e.target.value)} className={inputCls} placeholder="Ayesha Malik, Daniel Cruz, …" />
        </div>
        <div className="sm:col-span-2">
          <span className={labelCls}>Genres</span>
          <div className="flex flex-wrap gap-1.5">
            {genres.map((g) => (
              <button
                key={g}
                type="button"
                onClick={() => toggleGenre(g)}
                className={`rounded-full px-3 py-1 text-xs font-semibold transition-all ${
                  genreSet.has(g)
                    ? "bg-gold-500 text-ink-950"
                    : "border border-ink-700 bg-ink-900 text-mist hover:border-gold-500/40"
                }`}
              >
                {g}
              </button>
            ))}
          </div>
        </div>
        <div>
          <span className={labelCls}>Placement</span>
          <div className="flex flex-col gap-1.5">
            {flag("Featured (home hero)", isFeatured, setIsFeatured)}
            {flag("Trending", isTrending, setIsTrending)}
            {flag("Popular", isPopular, setIsPopular)}
          </div>
        </div>
        <div className="sm:col-span-2">
          <ImageField label="Poster" value={poster} onChange={setPoster} alt={title || "Poster"} />
        </div>
        <div className="sm:col-span-2 lg:col-span-1">
          <ImageField label="Backdrop / Banner" value={backdrop} onChange={setBackdrop} alt={title || "Backdrop"} wide />
        </div>
        <div className="sm:col-span-2">
          <span className={labelCls}>Video URL (watch source)</span>
          <input value={video} onChange={(e) => setVideo(e.target.value)} className={inputCls} placeholder="https://…mp4 — must be content you're authorized to host" />
          <div className="mt-1.5 flex flex-wrap gap-1.5">
            {SAMPLE_MOVIES.map((s) => (
              <button key={s.url} type="button" onClick={() => setVideo(s.url)} className="rounded border border-ink-700 px-2 py-0.5 text-[11px] font-semibold text-faint hover:border-gold-500/40 hover:text-gold-400">
                {s.label}
              </button>
            ))}
          </div>
        </div>
        <div className="sm:col-span-2">
          <span className={labelCls}>Trailer URL</span>
          <input value={trailer} onChange={(e) => setTrailer(e.target.value)} className={inputCls} placeholder="https://…mp4" />
          <div className="mt-1.5 flex flex-wrap gap-1.5">
            {SAMPLE_TRAILERS.map((s) => (
              <button key={s.url} type="button" onClick={() => setTrailer(s.url)} className="rounded border border-ink-700 px-2 py-0.5 text-[11px] font-semibold text-faint hover:border-gold-500/40 hover:text-gold-400">
                {s.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {error && (
        <p className="mt-4 rounded-md border border-bad/40 bg-bad/10 px-3.5 py-2.5 text-sm font-semibold text-bad">
          {error}
        </p>
      )}

      <div className="mt-5 flex gap-3">
        <button
          onClick={save}
          disabled={busy}
          className="rounded-md bg-gold-500 px-6 py-2.5 text-sm font-black uppercase tracking-wider text-ink-950 transition-all hover:bg-gold-400 disabled:opacity-60"
        >
          {busy ? "Saving…" : t ? "Save changes" : "Create title"}
        </button>
        <button
          onClick={onCancel}
          className="rounded-md border border-ink-600 px-5 py-2.5 text-sm font-bold text-mist hover:border-ink-500 hover:text-cream"
        >
          Cancel
        </button>
      </div>

      {t && t.type === "series" && (
        <div className="mt-8 border-t border-ink-700/60 pt-6">
          <p className="mb-1 text-[11px] font-black uppercase tracking-[0.2em] text-gold-400">
            Series line-up
          </p>
          <p className="mb-4 text-xs text-faint">
            Seasons and episodes are saved live — each action updates the site immediately.
          </p>
          <SeasonManager titleId={t.id} seasons={t.seasons} onChanged={onSeasonsChanged} />
        </div>
      )}
    </div>
  );
}
