"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { IconLogout } from "./icons";

export default function LogoutButton() {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function logout() {
    setBusy(true);
    try {
      await fetch("/api/auth/logout", { method: "POST" });
    } finally {
      router.push("/");
      router.refresh();
    }
  }

  return (
    <button
      onClick={logout}
      disabled={busy}
      className="inline-flex items-center justify-center gap-2 rounded-md border border-ink-600 px-4 py-2.5 text-sm font-bold text-mist transition-colors hover:border-bad/50 hover:text-bad disabled:opacity-60"
    >
      <IconLogout className="h-4 w-4" />
      {busy ? "Signing out…" : "Sign Out"}
    </button>
  );
}
