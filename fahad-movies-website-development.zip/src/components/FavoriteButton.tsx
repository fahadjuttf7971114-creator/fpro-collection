"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { IconHeart } from "./icons";

export default function FavoriteButton({
  titleId,
  active,
  label = "Add to Favorites",
  className = "",
}: {
  titleId: number;
  active: boolean;
  label?: string;
  className?: string;
}) {
  const router = useRouter();
  const [fav, setFav] = useState(active);
  const [popped, setPopped] = useState(false);
  const [busy, setBusy] = useState(false);

  async function toggle() {
    if (busy) return;
    setBusy(true);
    setFav((f) => !f);
    setPopped(true);
    setTimeout(() => setPopped(false), 400);
    try {
      const res = await fetch("/api/favorites", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ titleId }),
      });
      if (!res.ok) {
        setFav(active);
        router.push(`/login?next=${encodeURIComponent(window.location.pathname)}`);
        return;
      }
      const data = await res.json();
      setFav(!!data.fav);
    } catch {
      setFav(active);
    } finally {
      setBusy(false);
    }
  }

  return (
    <button
      onClick={toggle}
      className={`inline-flex items-center gap-2 rounded-md border px-5 py-3 text-sm font-bold transition-all active:scale-95 ${
        fav
          ? "border-live/50 bg-live/10 text-live"
          : "border-ink-600 bg-ink-900/60 text-cream hover:border-live/50 hover:text-live"
      } ${popped ? "anim-pop" : ""} ${className}`}
    >
      <IconHeart className="h-4 w-4" filled={fav} />
      {fav ? "In Favorites" : label}
    </button>
  );
}
