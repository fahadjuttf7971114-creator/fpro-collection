"use client";

import { FormEvent, useState } from "react";
import { IconMail } from "./icons";

const inputCls =
  "w-full rounded-md border border-ink-700 bg-ink-900 px-3.5 py-2.5 text-sm text-cream placeholder-faint outline-none transition-colors focus:border-gold-500/60";

export default function ContactForm() {
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    await new Promise((r) => setTimeout(r, 500));
    setBusy(false);
    setSent(true);
  }

  if (sent) {
    return (
      <div className="flex flex-col items-center py-8 text-center anim-fade-up">
        <span className="grid h-14 w-14 place-items-center rounded-full bg-good/15 text-good">
          <IconMail className="h-6 w-6" />
        </span>
        <h3 className="mt-4 font-display text-3xl tracking-wide">Message sent</h3>
        <p className="mt-2 max-w-xs text-sm text-mist">
          Thanks for reaching out. Our team typically replies within two
          business days.
        </p>
        <button
          onClick={() => setSent(false)}
          className="mt-5 text-sm font-bold text-gold-400 hover:text-gold-300"
        >
          Send another message
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <input required placeholder="Your name" className={inputCls} aria-label="Name" />
        <input
          type="email"
          required
          placeholder="Your email"
          className={inputCls}
          aria-label="Email"
        />
      </div>
      <input placeholder="Subject" className={inputCls} aria-label="Subject" />
      <textarea
        required
        rows={5}
        placeholder="How can we help?"
        className={`${inputCls} resize-none`}
        aria-label="Message"
      />
      <button
        type="submit"
        disabled={busy}
        className="rounded-md bg-gold-500 px-6 py-3 text-sm font-black uppercase tracking-wider text-ink-950 transition-all hover:bg-gold-400 active:scale-95 disabled:opacity-60"
      >
        {busy ? "Sending…" : "Send message"}
      </button>
    </form>
  );
}
