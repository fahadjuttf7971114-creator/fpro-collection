"use client";

import { useRef, useState } from "react";
import PosterImg from "./PosterImg";
import { IconUpload } from "./icons";
import { api } from "./adminTypes";

export default function ImageField({
  label,
  value,
  onChange,
  alt,
  wide = false,
}: {
  label: string;
  value: string;
  onChange: (url: string) => void;
  alt: string;
  wide?: boolean;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function onFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    setUploading(true);
    setErr(null);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const data = await api<{ url: string }>("/api/upload", {
        method: "POST",
        body: fd,
        headers: undefined,
      });
      onChange(data.url);
    } catch (ex) {
      setErr(ex instanceof Error ? ex.message : "Upload failed.");
    } finally {
      setUploading(false);
    }
  }

  return (
    <div>
      <span className="mb-1.5 block text-[11px] font-bold uppercase tracking-wider text-faint">
        {label}
      </span>
      <div className="flex items-start gap-3">
        <div className={`shrink-0 overflow-hidden rounded-md border border-ink-700 ${wide ? "h-24 w-44" : "h-32 w-20"}`}>
          <PosterImg src={value} alt={alt || label} className={wide ? "h-full w-full" : "h-full w-full"} />
        </div>
        <div className="min-w-0 flex-1 space-y-2">
          <input
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder="https://… or upload below"
            className="w-full rounded-md border border-ink-700 bg-ink-900 px-3 py-2 text-xs text-cream placeholder-faint outline-none focus:border-gold-500/60"
            aria-label={`${label} URL`}
          />
          <div className="flex items-center gap-2">
            <input
              ref={fileRef}
              type="file"
              accept="image/jpeg,image/png,image/webp,image/gif"
              className="hidden"
              onChange={onFile}
            />
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              disabled={uploading}
              className="inline-flex items-center gap-1.5 rounded-md border border-ink-600 px-3 py-1.5 text-xs font-bold text-mist transition-colors hover:border-gold-500/50 hover:text-gold-400 disabled:opacity-50"
            >
              <IconUpload className="h-3.5 w-3.5" />
              {uploading ? "Uploading…" : "Upload image"}
            </button>
            {value && (
              <button
                type="button"
                onClick={() => onChange("")}
                className="text-xs font-semibold text-faint hover:text-bad"
              >
                Clear
              </button>
            )}
          </div>
          {err && <p className="text-xs font-semibold text-bad">{err}</p>}
        </div>
      </div>
    </div>
  );
}
