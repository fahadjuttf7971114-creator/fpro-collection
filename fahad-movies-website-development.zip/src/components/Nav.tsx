"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { FormEvent, useRef, useState } from "react";
import {
  IconHeart,
  IconLogout,
  IconMenu,
  IconPlay,
  IconSearch,
  IconUser,
  IconX,
  IconChevronDown,
} from "./icons";

const LINKS = [
  { href: "/", label: "Home" },
  { href: "/movies", label: "Movies" },
  { href: "/series", label: "TV Series" },
  { href: "/genres", label: "Genres" },
];

export default function Nav({
  user,
}: {
  user: { name: string; email: string; isAdmin: boolean } | null;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [menu, setMenu] = useState(false);
  const [q, setQ] = useState("");
  const [loggingOut, setLoggingOut] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  function isActive(href: string) {
    if (href === "/") return pathname === "/";
    return pathname === href || pathname.startsWith(href + "/");
  }

  function submitSearch(e: FormEvent, initial?: string) {
    e.preventDefault();
    const term = (initial ?? q).trim();
    setOpen(false);
    router.push(term ? `/search?q=${encodeURIComponent(term)}` : "/search");
  }

  async function logout() {
    setLoggingOut(true);
    try {
      await fetch("/api/auth/logout", { method: "POST" });
    } finally {
      setMenu(false);
      setLoggingOut(false);
      router.refresh();
      router.push("/");
    }
  }

  const linkCls = (href: string) =>
    `rounded-md px-3 py-2 text-sm font-semibold transition-colors ${
      isActive(href)
        ? "bg-ink-800 text-gold-400"
        : "text-mist hover:bg-ink-800/70 hover:text-cream"
    }`;

  return (
    <header className="sticky top-0 z-50 border-b border-ink-700/50 bg-ink-950/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4 sm:px-6">
        {/* logo */}
        <Link href="/" className="flex items-center gap-2" onClick={() => setOpen(false)}>
          <span className="grid h-9 w-9 place-items-center rounded-md bg-gold-500 text-ink-950 shadow-lg shadow-gold-500/20">
            <IconPlay className="h-4.5 w-4.5" />
          </span>
          <span className="font-display text-2xl tracking-[0.08em] text-cream">
            FAHAD <span className="text-gold-400">MOVIES</span>
          </span>
        </Link>

        {/* desktop links */}
        <nav className="ml-4 hidden items-center gap-1 lg:flex">
          {LINKS.map((l) => (
            <Link key={l.href} href={l.href} className={linkCls(l.href)}>
              {l.label}
            </Link>
          ))}
          <Link href="/search" className={linkCls("/search")}>
            Search
          </Link>
        </nav>

        <div className="ml-auto flex items-center gap-2">
          {/* desktop search */}
          <form
            onSubmit={(e) => submitSearch(e)}
            className="hidden items-center md:flex"
            role="search"
          >
            <div className="flex items-center gap-2 rounded-md border border-ink-700 bg-ink-900/80 px-3 py-1.5 transition-colors focus-within:border-gold-500/50">
              <IconSearch className="h-4 w-4 text-faint" />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search titles, actors…"
                className="w-40 bg-transparent text-sm text-cream placeholder-faint outline-none xl:w-52"
                aria-label="Search"
              />
            </div>
          </form>

          <Link
            href="/favorites"
            aria-label="Favorites"
            className="grid h-9 w-9 place-items-center rounded-md text-mist transition-colors hover:bg-ink-800 hover:text-live"
          >
            <IconHeart className="h-5 w-5" />
          </Link>

          {user ? (
            <div className="relative" ref={menuRef}>
              <button
                onClick={() => setMenu((v) => !v)}
                className="flex items-center gap-2 rounded-md border border-ink-700 bg-ink-900/80 py-1.5 pl-2 pr-3 transition-colors hover:border-ink-600"
              >
                <span className="grid h-6 w-6 place-items-center rounded bg-gold-500/15 text-xs font-bold text-gold-400">
                  {user.name[0]?.toUpperCase()}
                </span>
                <span className="hidden max-w-28 truncate text-sm font-semibold sm:block">
                  {user.name.split(" ")[0]}
                </span>
                <IconChevronDown className="h-3.5 w-3.5 text-faint" />
              </button>
              {menu && (
                <>
                  <div className="fixed inset-0 z-10" onClick={() => setMenu(false)} />
                  <div className="absolute right-0 z-20 mt-2 w-56 overflow-hidden rounded-lg border border-ink-700 bg-ink-900 shadow-2xl shadow-black/60 anim-scale-in">
                    <div className="border-b border-ink-700/70 px-4 py-3">
                      <p className="truncate text-sm font-bold">{user.name}</p>
                      <p className="truncate text-xs text-faint">{user.email}</p>
                    </div>
                    <div className="p-1.5 text-sm">
                      <Link
                        href="/account"
                        onClick={() => setMenu(false)}
                        className="flex items-center gap-2.5 rounded-md px-3 py-2 text-mist hover:bg-ink-800 hover:text-cream"
                      >
                        <IconUser className="h-4 w-4" /> My Account
                      </Link>
                      <Link
                        href="/favorites"
                        onClick={() => setMenu(false)}
                        className="flex items-center gap-2.5 rounded-md px-3 py-2 text-mist hover:bg-ink-800 hover:text-cream"
                      >
                        <IconHeart className="h-4 w-4" /> Favorites
                      </Link>
                      {user.isAdmin && (
                        <Link
                          href="/admin"
                          onClick={() => setMenu(false)}
                          className="flex items-center gap-2.5 rounded-md px-3 py-2 font-semibold text-gold-400 hover:bg-ink-800"
                        >
                          <IconPlay className="h-4 w-4" /> Admin Dashboard
                        </Link>
                      )}
                      <button
                        onClick={logout}
                        disabled={loggingOut}
                        className="flex w-full items-center gap-2.5 rounded-md px-3 py-2 text-mist hover:bg-ink-800 hover:text-bad disabled:opacity-50"
                      >
                        <IconLogout className="h-4 w-4" />
                        {loggingOut ? "Signing out…" : "Sign Out"}
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          ) : (
            <Link
              href="/login"
              className="rounded-md bg-gold-500 px-4 py-2 text-sm font-bold text-ink-950 shadow-lg shadow-gold-500/20 transition-all hover:bg-gold-400 active:scale-95"
            >
              Login
            </Link>
          )}

          {/* mobile toggle */}
          <button
            onClick={() => setOpen((v) => !v)}
            aria-label="Menu"
            className="grid h-9 w-9 place-items-center rounded-md text-mist hover:bg-ink-800 lg:hidden"
          >
            {open ? <IconX className="h-5 w-5" /> : <IconMenu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* mobile panel */}
      {open && (
        <div className="border-t border-ink-700/50 bg-ink-950/95 px-4 pb-5 pt-3 backdrop-blur-md lg:hidden anim-fade-in">
          <form onSubmit={(e) => submitSearch(e)} className="mb-3 md:hidden">
            <div className="flex items-center gap-2 rounded-md border border-ink-700 bg-ink-900 px-3 py-2">
              <IconSearch className="h-4 w-4 text-faint" />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search titles, actors, genres…"
                className="w-full bg-transparent text-sm outline-none placeholder-faint"
              />
            </div>
          </form>
          <nav className="grid gap-1">
            {LINKS.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                onClick={() => setOpen(false)}
                className={linkCls(l.href)}
              >
                {l.label}
              </Link>
            ))}
            <Link
              href="/search"
              onClick={() => setOpen(false)}
              className={linkCls("/search")}
            >
              Search
            </Link>
            <Link
              href="/favorites"
              onClick={() => setOpen(false)}
              className={linkCls("/favorites")}
            >
              Favorites
            </Link>
            {!user && (
              <Link
                href="/login"
                onClick={() => setOpen(false)}
                className="mt-1 rounded-md bg-gold-500 px-4 py-2.5 text-center text-sm font-bold text-ink-950"
              >
                Login / Sign Up
              </Link>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}
