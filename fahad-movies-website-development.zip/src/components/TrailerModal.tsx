"use client";

import { useEffect, useRef } from "react";
import { IconX } from "./icons";

export default function TrailerModal({
  open,
  src,
  title,
  onClose,
}: {
  open: boolean;
  src?: string;
  title: string;
  onClose: () => void;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
      videoRef.current?.pause();
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[100] grid place-items-center bg-ink-950/85 p-4 backdrop-blur-sm anim-fade-in"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label={`Trailer: ${title}`}
    >
      <div
        className="w-full max-w-4xl overflow-hidden rounded-xl border border-ink-600 bg-ink-900 shadow-2xl shadow-black/70 anim-scale-in"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-ink-700/60 px-4 py-3">
          <div>
            <p className="text-[11px] font-bold uppercase tracking-widest text-gold-400">
              Official Trailer
            </p>
            <p className="text-sm font-semibold">{title}</p>
          </div>
          <button
            onClick={onClose}
            aria-label="Close trailer"
            className="grid h-9 w-9 place-items-center rounded-md text-mist hover:bg-ink-800 hover:text-cream"
          >
            <IconX className="h-5 w-5" />
          </button>
        </div>
        <div className="bg-black">
          {src ? (
            <video
              ref={videoRef}
              src={src}
              controls
              autoPlay
              playsInline
              className="aspect-video w-full"
            />
          ) : (
            <div className="grid aspect-video w-full place-items-center text-sm text-faint">
              Trailer is not available for this title yet.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
