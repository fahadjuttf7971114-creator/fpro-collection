"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  IconChevronLeft,
  IconChevronRight,
  IconExitFullscreen,
  IconFullscreen,
  IconPause,
  IconPlay,
  IconVolume,
} from "./icons";

export type Quality = { label: string; url: string };

function fmt(t: number) {
  if (!isFinite(t) || t < 0) t = 0;
  const h = Math.floor(t / 3600);
  const m = Math.floor((t % 3600) / 60);
  const s = Math.floor(t % 60);
  return h > 0
    ? `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`
    : `${m}:${String(s).padStart(2, "0")}`;
}

export default function VideoPlayer({
  src,
  title,
  poster,
  qualities,
  autoPlay = false,
  prev,
  next,
}: {
  src: string;
  title: string;
  poster?: string;
  qualities?: Quality[];
  autoPlay?: boolean;
  prev?: { href: string; label: string };
  next?: { href: string; label: string };
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const hideTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [playing, setPlaying] = useState(false);
  const [current, setCurrent] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [muted, setMuted] = useState(false);
  const [quality, setQuality] = useState(0);
  const [menuOpen, setMenuOpen] = useState(false);
  const [controls, setControls] = useState(true);
  const [buffering, setBuffering] = useState(true);
  const [fs, setFs] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const list =
    qualities && qualities.length > 0
      ? qualities
      : src
        ? [
            { label: "Auto", url: src },
            { label: "1080p", url: src },
            { label: "720p", url: src },
          ]
        : [];

  const activeUrl = list[quality]?.url ?? src;

  const showControls = useCallback(() => {
    setControls(true);
    if (hideTimer.current) clearTimeout(hideTimer.current);
    hideTimer.current = setTimeout(() => {
      const v = videoRef.current;
      if (v && !v.paused && !menuOpen) setControls(false);
    }, 2800);
  }, [menuOpen]);

  useEffect(() => {
    const onFs = () => setFs(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", onFs);
    return () => document.removeEventListener("fullscreenchange", onFs);
  }, []);

  const togglePlay = useCallback(() => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) v.play().catch(() => setError("Playback failed. Try a different quality."));
    else v.pause();
  }, []);

  const toggleMute = () => {
    const v = videoRef.current;
    if (!v) return;
    v.muted = !v.muted;
    setMuted(v.muted);
  };

  const toggleFs = () => {
    if (document.fullscreenElement) document.exitFullscreen().catch(() => undefined);
    else wrapRef.current?.requestFullscreen().catch(() => undefined);
  };

  const seekBy = (d: number) => {
    const v = videoRef.current;
    if (!v || !isFinite(v.duration)) return;
    v.currentTime = Math.min(Math.max(0, v.currentTime + d), v.duration);
  };

  const setVol = (val: number) => {
    const v = videoRef.current;
    if (!v) return;
    v.volume = val;
    v.muted = val === 0;
    setVolume(val);
    setMuted(val === 0);
  };

  const changeQuality = (i: number) => {
    if (i === quality) return;
    const v = videoRef.current;
    const t = v?.currentTime ?? 0;
    const wasPlaying = v ? !v.paused : false;
    setQuality(i);
    setMenuOpen(false);
    setBuffering(true);
    if (v) {
      v.load();
      const onMeta = () => {
        v.currentTime = t;
        if (wasPlaying) v.play().catch(() => undefined);
        v.removeEventListener("loadedmetadata", onMeta);
      };
      v.addEventListener("loadedmetadata", onMeta);
    }
  };

  const onKey = (e: React.KeyboardEvent) => {
    const v = videoRef.current;
    if (!v) return;
    switch (e.key) {
      case " ":
      case "k":
        e.preventDefault();
        togglePlay();
        break;
      case "m":
        toggleMute();
        break;
      case "f":
        toggleFs();
        break;
      case "ArrowRight":
        seekBy(10);
        break;
      case "ArrowLeft":
        seekBy(-10);
        break;
      case "ArrowUp":
        e.preventDefault();
        setVol(Math.min(1, volume + 0.1));
        break;
      case "ArrowDown":
        e.preventDefault();
        setVol(Math.max(0, volume - 0.1));
        break;
    }
    showControls();
  };

  const progress = duration ? (current / duration) * 100 : 0;

  return (
    <div
      ref={wrapRef}
      tabIndex={0}
      onKeyDown={onKey}
      onMouseMove={showControls}
      onMouseLeave={() => {
        const v = videoRef.current;
        if (v && !v.paused && !menuOpen) setControls(false);
      }}
      className="group relative w-full select-none overflow-hidden rounded-xl border border-ink-700/60 bg-black outline-none focus-visible:ring-2 focus-visible:ring-gold-500/60"
      aria-label={`Video player: ${title}`}
    >
      <video
        ref={videoRef}
        src={activeUrl}
        poster={poster || undefined}
        autoPlay={autoPlay}
        playsInline
        preload="metadata"
        onClick={togglePlay}
        onPlay={() => {
          setPlaying(true);
          setError(null);
          showControls();
        }}
        onPause={() => {
          setPlaying(false);
          setControls(true);
        }}
        onTimeUpdate={(e) => setCurrent(e.currentTarget.currentTime)}
        onDurationChange={(e) => setDuration(e.currentTarget.duration || 0)}
        onWaiting={() => setBuffering(true)}
        onPlaying={() => setBuffering(false)}
        onCanPlay={() => setBuffering(false)}
        onVolumeChange={(e) => {
          setVolume(e.currentTarget.volume);
          setMuted(e.currentTarget.muted);
        }}
        onError={() =>
          setError("This video could not be loaded. The source may be unavailable.")
        }
        className="aspect-video w-full bg-black"
      />

      {/* buffering spinner */}
      {buffering && !error && (
        <div className="pointer-events-none absolute inset-0 grid place-items-center">
          <div className="player-spinner h-12 w-12 rounded-full border-[3px] border-cream/20 border-t-gold-400" />
        </div>
      )}

      {/* error state */}
      {error && (
        <div className="absolute inset-0 grid place-items-center bg-ink-950/80 px-6 text-center">
          <div>
            <p className="text-sm font-semibold text-bad">{error}</p>
            <button
              onClick={() => {
                setError(null);
                videoRef.current?.load();
              }}
              className="mt-3 rounded-md border border-ink-600 bg-ink-800 px-4 py-1.5 text-sm font-semibold hover:border-gold-500/50"
            >
              Retry
            </button>
          </div>
        </div>
      )}

      {/* big center play */}
      {!playing && !buffering && !error && (
        <button
          onClick={togglePlay}
          aria-label="Play"
          className="absolute inset-0 grid place-items-center bg-ink-950/30 transition-opacity"
        >
          <span className="grid h-20 w-20 place-items-center rounded-full bg-gold-500 text-ink-950 shadow-2xl shadow-black/60 transition-transform hover:scale-110">
            <IconPlay className="h-9 w-9 translate-x-0.5" />
          </span>
        </button>
      )}

      {/* prev / next */}
      {prev && (
        <a
          href={prev.href}
          className="absolute left-3 top-1/2 z-10 hidden -translate-y-1/2 items-center gap-1.5 rounded-md bg-ink-950/70 px-3 py-2 text-xs font-bold text-cream/90 backdrop-blur transition-all hover:bg-gold-500 hover:text-ink-950 sm:flex"
        >
          <IconChevronLeft className="h-4 w-4" /> {prev.label}
        </a>
      )}
      {next && (
        <a
          href={next.href}
          className="absolute right-3 top-1/2 z-10 hidden -translate-y-1/2 items-center gap-1.5 rounded-md bg-ink-950/70 px-3 py-2 text-xs font-bold text-cream/90 backdrop-blur transition-all hover:bg-gold-500 hover:text-ink-950 sm:flex"
        >
          {next.label} <IconChevronRight className="h-4 w-4" />
        </a>
      )}

      {/* control bar */}
      <div
        className={`absolute inset-x-0 bottom-0 z-10 bg-gradient-to-t from-ink-950/95 via-ink-950/70 to-transparent px-3 pb-2.5 pt-10 transition-opacity duration-300 ${
          controls ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
      >
        {/* progress */}
        <input
          type="range"
          className="fm-range w-full"
          min={0}
          max={duration || 0}
          step={0.1}
          value={current}
          style={{ ["--fill" as string]: `${progress}%` }}
          aria-label="Seek"
          onChange={(e) => {
            const v = videoRef.current;
            if (v) v.currentTime = Number(e.target.value);
            setCurrent(Number(e.target.value));
          }}
        />
        <div className="mt-1.5 flex items-center gap-3">
          <button
            onClick={togglePlay}
            aria-label={playing ? "Pause" : "Play"}
            className="grid h-9 w-9 place-items-center rounded-md text-cream transition-colors hover:bg-ink-700/70 hover:text-gold-400"
          >
            {playing ? (
              <IconPause className="h-5 w-5" />
            ) : (
              <IconPlay className="h-5 w-5" />
            )}
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={toggleMute}
              aria-label={muted ? "Unmute" : "Mute"}
              className="grid h-8 w-8 place-items-center rounded-md text-cream/90 hover:bg-ink-700/70 hover:text-gold-400"
            >
              <IconVolume className="h-5 w-5" muted={muted} />
            </button>
            <input
              type="range"
              className="fm-range hidden w-20 sm:block"
              min={0}
              max={1}
              step={0.05}
              value={muted ? 0 : volume}
              style={{ ["--fill" as string]: `${(muted ? 0 : volume) * 100}%` }}
              aria-label="Volume"
              onChange={(e) => setVol(Number(e.target.value))}
            />
          </div>

          <span className="font-mono text-[11px] tabular-nums text-mist">
            {fmt(current)} <span className="text-faint">/ {fmt(duration)}</span>
          </span>

          <div className="ml-auto flex items-center gap-2">
            {/* quality */}
            <div className="relative">
              <button
                onClick={() => setMenuOpen((v) => !v)}
                className="flex items-center gap-1 rounded-md px-2.5 py-1.5 text-xs font-bold text-cream/90 hover:bg-ink-700/70 hover:text-gold-400"
                aria-label="Quality"
              >
                {list[quality]?.label ?? "Auto"}
              </button>
              {menuOpen && (
                <div className="absolute bottom-10 right-0 w-36 overflow-hidden rounded-lg border border-ink-600 bg-ink-900/95 py-1 shadow-xl backdrop-blur anim-scale-in">
                  <p className="px-3 pb-1 pt-1.5 text-[10px] font-bold uppercase tracking-wider text-faint">
                    Quality
                  </p>
                  {list.map((q, i) => (
                    <button
                      key={q.label + i}
                      onClick={() => changeQuality(i)}
                      className={`block w-full px-3 py-1.5 text-left text-sm hover:bg-ink-700 ${
                        i === quality ? "font-bold text-gold-400" : "text-cream/90"
                      }`}
                    >
                      {q.label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <button
              onClick={toggleFs}
              aria-label={fs ? "Exit fullscreen" : "Fullscreen"}
              className="grid h-8 w-8 place-items-center rounded-md text-cream/90 hover:bg-ink-700/70 hover:text-gold-400"
            >
              {fs ? (
                <IconExitFullscreen className="h-4.5 w-4.5" />
              ) : (
                <IconFullscreen className="h-4.5 w-4.5" />
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
