"use client";

import { useEffect } from "react";

export default function WatchTracker({ titleId }: { titleId: number }) {
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        await fetch("/api/history", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ titleId }),
        });
      } catch {
        if (!cancelled) window.location.reload();
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [titleId]);

  return null;
}
