import type { Metadata, Viewport } from "next";
import { Bebas_Neue, Manrope } from "next/font/google";
import "./globals.css";
import Nav from "@/components/Nav";
import Footer from "@/components/Footer";
import { getSessionUser } from "@/lib/auth";

const bebas = Bebas_Neue({
  weight: "400",
  subsets: ["latin"],
  variable: "--font-display",
  display: "swap",
});
const manrope = Manrope({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "Fahad Movies — Stream Movies & TV Series",
    template: "%s · Fahad Movies",
  },
  description:
    "Fahad Movies is a cinematic streaming destination for movies and TV series — browse by genre, search by actor or year, build your watchlist and watch in a premium player.",
  openGraph: {
    title: "Fahad Movies",
    description:
      "A premium dark cinematic streaming experience for movies and TV series.",
    type: "website",
  },
};

export const viewport: Viewport = {
  themeColor: "#0a0c11",
};

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await getSessionUser().catch(() => null);
  return (
    <html lang="en" className={`${bebas.variable} ${manrope.variable} font-sans`}>
      <body className="flex min-h-screen flex-col bg-ink-950 text-cream antialiased">
        <Nav
          user={
            user
              ? { name: user.name, email: user.email, isAdmin: user.isAdmin }
              : null
          }
        />
        <main className="flex-1">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
