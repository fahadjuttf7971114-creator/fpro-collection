import type { Metadata } from "next";
import InfoPage from "@/components/InfoPage";

export const metadata: Metadata = {
  title: "Terms of Service",
  description: "The rules of the theater at Fahad Movies.",
};

export default function TermsPage() {
  return (
    <InfoPage kicker="Legal" title="Terms of Service">
      <p>Last updated: January 2025</p>
      <h2>Acceptance</h2>
      <p>
        By using Fahad Movies you agree to these terms. If you don&apos;t agree,
        please leave the theater.
      </p>
      <h2>Content &amp; licensing</h2>
      <p>
        All movies and series on this platform are hosted or embedded with the
        legal authorization of their rights holders. Downloading, re-uploading
        or redistributing stream content without permission is strictly
        prohibited and may be illegal in your jurisdiction.
      </p>
      <h2>Your account</h2>
      <p>
        You are responsible for keeping your credentials safe. One account per
        person. Don&apos;t use your account to do anything these terms forbid.
      </p>
      <h2>Fair use</h2>
      <p>
        Don&apos;t scrape the catalog at abusive scale, attempt to breach our
        systems, or use the platform to distribute harmful material.
      </p>
      <h2>Disclaimer</h2>
      <p>
        The service is provided as-is. We work hard to keep it up and content
        accurate, but ratings, descriptions and availability can change.
      </p>
      <h2>Changes</h2>
      <p>
        We may update these terms from time to time. Material changes will be
        highlighted on this page with a new date.
      </p>
    </InfoPage>
  );
}
