import Link from "next/link";
import { IconPlay, IconSearch } from "@/components/icons";

export default function NotFound() {
  return (
    <div className="relative flex min-h-[60vh] flex-col items-center justify-center overflow-hidden px-4 text-center">
      <div
        className="pointer-events-none absolute inset-0 opacity-60"
        style={{
          background:
            "radial-gradient(ellipse at 50% 0%, rgba(234,181,86,0.08), transparent 60%)",
        }}
      />
      <p className="font-display text-[9rem] leading-none tracking-widest text-ink-600 sm:text-[12rem]">
        404
      </p>
      <h1 className="font-display text-4xl tracking-wide text-cream sm:text-5xl">
        This reel doesn&apos;t exist
      </h1>
      <p className="mt-3 max-w-md text-sm text-mist">
        The page you&apos;re looking for was cut in the editing room. Let&apos;s
        get you back to the good stuff.
      </p>
      <div className="mt-8 flex flex-wrap justify-center gap-3">
        <Link
          href="/"
          className="inline-flex items-center gap-2 rounded-md bg-gold-500 px-6 py-3 text-sm font-black uppercase tracking-wider text-ink-950 transition-all hover:bg-gold-400"
        >
          <IconPlay className="h-4 w-4" /> Back to Home
        </Link>
        <Link
          href="/search"
          className="inline-flex items-center gap-2 rounded-md border border-ink-600 px-6 py-3 text-sm font-bold uppercase tracking-wider text-cream transition-all hover:border-gold-400/60 hover:text-gold-300"
        >
          <IconSearch className="h-4 w-4" /> Search the catalog
        </Link>
      </div>
    </div>
  );
}
