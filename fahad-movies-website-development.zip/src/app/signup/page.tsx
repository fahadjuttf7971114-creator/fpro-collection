import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { Suspense } from "react";
import { getSessionUser } from "@/lib/auth";
import AuthForm from "@/components/AuthForm";

export const metadata: Metadata = {
  title: "Sign Up",
  description: "Create your free Fahad Movies account.",
};

export default async function SignupPage() {
  const user = await getSessionUser();
  if (user) redirect("/account");

  return (
    <div className="mx-auto flex max-w-md flex-col px-4 py-14">
      <div className="text-center">
        <p className="text-[11px] font-black uppercase tracking-[0.25em] text-gold-400">
          Join free
        </p>
        <h1 className="mt-1 font-display text-5xl tracking-wide">Create Account</h1>
        <p className="mt-2 text-sm text-mist">
          Save favorites, track what you watch and pick up right where you left off.
        </p>
      </div>

      <div className="mt-8 rounded-xl border border-ink-700/60 bg-ink-900/60 p-6">
        <Suspense>
          <AuthForm mode="signup" />
        </Suspense>
      </div>
    </div>
  );
}
