import type { Metadata } from "next";
import { redirect } from "next/navigation";
import Link from "next/link";
import { getSessionUser } from "@/lib/auth";
import { getFavorites } from "@/lib/queries";
import TitleGrid from "@/components/TitleGrid";
import { IconHeart } from "@/components/icons";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "Favorites",
  description: "Your personal watchlist on Fahad Movies.",
};

export default async function FavoritesPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login?next=/favorites");

  const items = await getFavorites(user.id);

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-8">
        <p className="text-[11px] font-black uppercase tracking-[0.2em] text-gold-400">
          Your list
        </p>
        <h1 className="mt-1 font-display text-4xl tracking-wide sm:text-5xl">
          Favorites &amp; Watchlist
        </h1>
        <p className="mt-2 text-sm text-mist">
          {items.length === 0
            ? "Nothing saved yet."
            : `${items.length} title${items.length === 1 ? "" : "s"} saved to your watchlist.`}
        </p>
      </div>

      {items.length > 0 ? (
        <TitleGrid items={items} />
      ) : (
        <div className="flex flex-col items-center rounded-xl border border-dashed border-ink-600 bg-ink-900/40 px-6 py-20 text-center anim-fade-up">
          <span className="grid h-16 w-16 place-items-center rounded-full bg-ink-800 text-live">
            <IconHeart className="h-7 w-7" />
          </span>
          <h3 className="mt-5 font-display text-3xl tracking-wide">Your list is empty</h3>
          <p className="mt-2 max-w-sm text-sm text-mist">
            Tap the heart on any movie or series to keep it here for later.
          </p>
          <div className="mt-6 flex gap-3">
            <Link
              href="/movies"
              className="rounded-md bg-gold-500 px-5 py-2.5 text-sm font-bold text-ink-950 hover:bg-gold-400"
            >
              Browse Movies
            </Link>
            <Link
              href="/series"
              className="rounded-md border border-ink-600 px-5 py-2.5 text-sm font-bold text-cream hover:border-gold-500/50"
            >
              Browse Series
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
