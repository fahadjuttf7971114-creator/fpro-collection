import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { seasons } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { revalidatePath } from "next/cache";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, ctx: Ctx) {
  const user = await getSessionUser();
  if (!user || !user.isAdmin) {
    return NextResponse.json({ error: "Admin access required." }, { status: 403 });
  }
  const { id } = await ctx.params;
  const n = Number(id);
  if (!Number.isInteger(n)) return NextResponse.json({ error: "Bad id" }, { status: 400 });

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }
  const patch: Partial<typeof seasons.$inferInsert> = {};
  if (body.name !== undefined) patch.name = String(body.name).trim().slice(0, 80);
  if (body.seasonNumber !== undefined) {
    const num = Number(body.seasonNumber);
    if (!Number.isInteger(num) || num < 1 || num > 50) {
      return NextResponse.json({ error: "Invalid season number." }, { status: 400 });
    }
    patch.seasonNumber = num;
  }
  if (Object.keys(patch).length === 0) {
    return NextResponse.json({ error: "Nothing to update." }, { status: 400 });
  }
  const updated = await db
    .update(seasons)
    .set(patch)
    .where(eq(seasons.id, n))
    .returning();
  if (updated.length === 0)
    return NextResponse.json({ error: "Season not found." }, { status: 404 });
  revalidatePath("/", "layout");
  return NextResponse.json({ ok: true, item: updated[0] });
}

export async function DELETE(_req: Request, ctx: Ctx) {
  const user = await getSessionUser();
  if (!user || !user.isAdmin) {
    return NextResponse.json({ error: "Admin access required." }, { status: 403 });
  }
  const { id } = await ctx.params;
  const n = Number(id);
  const deleted = await db.delete(seasons).where(eq(seasons.id, n)).returning({ id: seasons.id });
  if (deleted.length === 0)
    return NextResponse.json({ error: "Season not found." }, { status: 404 });
  revalidatePath("/", "layout");
  return NextResponse.json({ ok: true });
}
