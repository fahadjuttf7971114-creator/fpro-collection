import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, hashPassword, isEmail } from "@/lib/auth";

export async function POST(req: Request) {
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }
  const name = String(body.name ?? "").trim();
  const email = String(body.email ?? "").trim().toLowerCase();
  const password = String(body.password ?? "");

  if (name.length < 2)
    return NextResponse.json({ error: "Please enter your full name." }, { status: 400 });
  if (!isEmail(email))
    return NextResponse.json({ error: "Please enter a valid email address." }, { status: 400 });
  if (password.length < 6)
    return NextResponse.json(
      { error: "Password must be at least 6 characters." },
      { status: 400 }
    );

  const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
  if (existing.length > 0) {
    return NextResponse.json(
      { error: "An account with that email already exists. Try logging in." },
      { status: 409 }
    );
  }

  const inserted = await db
    .insert(users)
    .values({ name, email, password: hashPassword(password) })
    .returning();
  await createSession(inserted[0].id);
  return NextResponse.json({
    ok: true,
    user: {
      id: inserted[0].id,
      name: inserted[0].name,
      email: inserted[0].email,
      isAdmin: false,
    },
  });
}
