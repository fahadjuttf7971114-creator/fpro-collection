import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { favorites, titles } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { revalidatePath } from "next/cache";

export async function GET() {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Login required." }, { status: 401 });
  const rows = await db
    .select({ t: titles })
    .from(favorites)
    .innerJoin(titles, eq(favorites.titleId, titles.id))
    .where(eq(favorites.userId, user.id))
    .limit(200);
  return NextResponse.json({ items: rows.map((r) => r.t) });
}

export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Login required." }, { status: 401 });

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }
  const titleId = Number(body.titleId);
  if (!Number.isInteger(titleId)) {
    return NextResponse.json({ error: "titleId is required." }, { status: 400 });
  }
  const exists = await db
    .select({ userId: favorites.userId })
    .from(favorites)
    .where(and(eq(favorites.userId, user.id), eq(favorites.titleId, titleId)))
    .limit(1);

  let fav: boolean;
  if (exists.length > 0) {
    await db
      .delete(favorites)
      .where(and(eq(favorites.userId, user.id), eq(favorites.titleId, titleId)));
    fav = false;
  } else {
    await db
      .insert(favorites)
      .values({ userId: user.id, titleId })
      .onConflictDoNothing();
    fav = true;
  }
  revalidatePath("/", "layout");
  return NextResponse.json({ ok: true, fav });
}
