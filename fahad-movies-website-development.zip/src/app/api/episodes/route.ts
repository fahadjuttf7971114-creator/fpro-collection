import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { episodes, seasons } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { revalidatePath } from "next/cache";

export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user || !user.isAdmin) {
    return NextResponse.json({ error: "Admin access required." }, { status: 403 });
  }
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }
  const seasonId = Number(body.seasonId);
  const titleId = Number(body.titleId);
  const number = Number(body.number ?? 1);
  const name = String(body.name ?? "").trim().slice(0, 120);
  const description = String(body.description ?? "").slice(0, 1000);
  const video = String(body.video ?? "").trim().slice(0, 2000);
  const duration = Number(body.duration ?? 0);

  if (!Number.isInteger(seasonId) || !Number.isInteger(titleId)) {
    return NextResponse.json({ error: "seasonId and titleId are required." }, { status: 400 });
  }
  if (!Number.isInteger(number) || number < 1 || number > 100) {
    return NextResponse.json({ error: "Episode number must be 1–100." }, { status: 400 });
  }
  if (!Number.isInteger(duration) || duration < 0 || duration > 300) {
    return NextResponse.json({ error: "Duration must be 0–300 minutes." }, { status: 400 });
  }

  const seasonRows = await db
    .select()
    .from(seasons)
    .where(eq(seasons.id, seasonId))
    .limit(1);
  if (seasonRows.length === 0 || seasonRows[0].titleId !== titleId) {
    return NextResponse.json({ error: "Season not found for this title." }, { status: 404 });
  }

  const inserted = await db
    .insert(episodes)
    .values({
      seasonId,
      titleId,
      number,
      name: name || `Episode ${number}`,
      description,
      video,
      duration,
    })
    .returning();
  revalidatePath("/", "layout");
  return NextResponse.json({ ok: true, item: inserted[0] }, { status: 201 });
}
