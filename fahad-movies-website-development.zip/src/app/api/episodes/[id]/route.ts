import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { episodes } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { revalidatePath } from "next/cache";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, ctx: Ctx) {
  const user = await getSessionUser();
  if (!user || !user.isAdmin) {
    return NextResponse.json({ error: "Admin access required." }, { status: 403 });
  }
  const { id } = await ctx.params;
  const n = Number(id);
  if (!Number.isInteger(n)) return NextResponse.json({ error: "Bad id" }, { status: 400 });

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }
  const patch: Partial<typeof episodes.$inferInsert> = {};
  if (body.name !== undefined) patch.name = String(body.name).trim().slice(0, 120) || "Episode";
  if (body.description !== undefined) patch.description = String(body.description).slice(0, 1000);
  if (body.video !== undefined) patch.video = String(body.video).trim().slice(0, 2000);
  if (body.number !== undefined) {
    const num = Number(body.number);
    if (!Number.isInteger(num) || num < 1 || num > 100) {
      return NextResponse.json({ error: "Episode number must be 1–100." }, { status: 400 });
    }
    patch.number = num;
  }
  if (body.duration !== undefined) {
    const d = Number(body.duration);
    if (!Number.isInteger(d) || d < 0 || d > 300) {
      return NextResponse.json({ error: "Duration must be 0–300 minutes." }, { status: 400 });
    }
    patch.duration = d;
  }
  if (Object.keys(patch).length === 0) {
    return NextResponse.json({ error: "Nothing to update." }, { status: 400 });
  }
  const updated = await db
    .update(episodes)
    .set(patch)
    .where(eq(episodes.id, n))
    .returning();
  if (updated.length === 0)
    return NextResponse.json({ error: "Episode not found." }, { status: 404 });
  revalidatePath("/", "layout");
  return NextResponse.json({ ok: true, item: updated[0] });
}

export async function DELETE(_req: Request, ctx: Ctx) {
  const user = await getSessionUser();
  if (!user || !user.isAdmin) {
    return NextResponse.json({ error: "Admin access required." }, { status: 403 });
  }
  const { id } = await ctx.params;
  const n = Number(id);
  const deleted = await db
    .delete(episodes)
    .where(eq(episodes.id, n))
    .returning({ id: episodes.id });
  if (deleted.length === 0)
    return NextResponse.json({ error: "Episode not found." }, { status: 404 });
  revalidatePath("/", "layout");
  return NextResponse.json({ ok: true });
}
