import { NextResponse } from "next/server";
import { eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { titles, seasons, episodes } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { getTitleBySlug, slugify } from "@/lib/queries";
import { parseTitleInput } from "@/lib/title-input";
import { revalidatePath } from "next/cache";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: Request, ctx: Ctx) {
  const { id } = await ctx.params;
  const n = Number(id);
  if (!Number.isInteger(n)) return NextResponse.json({ error: "Bad id" }, { status: 400 });
  const rows = await db.select().from(titles).where(eq(titles.id, n)).limit(1);
  const title = rows[0];
  if (!title) return NextResponse.json({ error: "Not found" }, { status: 404 });
  let seasonList: unknown[] = [];
  if (title.type === "series") {
    const s = await db
      .select()
      .from(seasons)
      .where(eq(seasons.titleId, title.id))
      .orderBy(seasons.seasonNumber);
    const e = s.length
      ? await db
          .select()
          .from(episodes)
          .where(inArray(episodes.seasonId, s.map((x) => x.id)))
          .orderBy(episodes.number)
      : [];
    seasonList = s.map((sn) => ({
      ...sn,
      episodes: e.filter((ep) => ep.seasonId === sn.id),
    }));
  }
  return NextResponse.json({ item: { ...title, seasons: seasonList } });
}

export async function PATCH(req: Request, ctx: Ctx) {
  const user = await getSessionUser();
  if (!user || !user.isAdmin) {
    return NextResponse.json({ error: "Admin access required." }, { status: 403 });
  }
  const { id } = await ctx.params;
  const n = Number(id);
  if (!Number.isInteger(n)) return NextResponse.json({ error: "Bad id" }, { status: 400 });
  const existing = await db.select().from(titles).where(eq(titles.id, n)).limit(1);
  if (existing.length === 0)
    return NextResponse.json({ error: "Title not found." }, { status: 404 });

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }
  const { errors, value } = parseTitleInput(body, true);
  if (errors.length) return NextResponse.json({ error: errors[0] }, { status: 400 });
  if (Object.keys(value).length === 0) {
    return NextResponse.json({ error: "Nothing to update." }, { status: 400 });
  }

  // regenerate slug if the title changed
  if (value.title && value.title !== existing[0].title) {
    let slug = slugify(value.title);
    let i = 2;
    while (true) {
      const clash = await db
        .select({ id: titles.id })
        .from(titles)
        .where(eq(titles.slug, slug))
        .limit(1);
      if (clash.length === 0 || clash[0].id === n) break;
      slug = `${slugify(value.title)}-${i++}`;
    }
    value.slug = slug as string;
  }

  const updated = await db.update(titles).set(value).where(eq(titles.id, n)).returning();
  revalidatePath("/", "layout");
  return NextResponse.json({ ok: true, item: updated[0] });
}

export async function DELETE(_req: Request, ctx: Ctx) {
  const user = await getSessionUser();
  if (!user || !user.isAdmin) {
    return NextResponse.json({ error: "Admin access required." }, { status: 403 });
  }
  const { id } = await ctx.params;
  const n = Number(id);
  if (!Number.isInteger(n)) return NextResponse.json({ error: "Bad id" }, { status: 400 });
  const deleted = await db.delete(titles).where(eq(titles.id, n)).returning({ id: titles.id });
  if (deleted.length === 0)
    return NextResponse.json({ error: "Title not found." }, { status: 404 });
  revalidatePath("/", "layout");
  return NextResponse.json({ ok: true });
}
