import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { titles, seasons } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { revalidatePath } from "next/cache";

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await getSessionUser();
  if (!user || !user.isAdmin) {
    return NextResponse.json({ error: "Admin access required." }, { status: 403 });
  }
  const { id } = await ctx.params;
  const n = Number(id);
  if (!Number.isInteger(n)) return NextResponse.json({ error: "Bad id" }, { status: 400 });

  const titleRows = await db.select().from(titles).where(eq(titles.id, n)).limit(1);
  if (titleRows.length === 0)
    return NextResponse.json({ error: "Title not found." }, { status: 404 });
  if (titleRows[0].type !== "series") {
    return NextResponse.json({ error: "Seasons are only for TV series." }, { status: 400 });
  }

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }
  const seasonNumber = Number(body.seasonNumber ?? 1);
  const name = String(body.name ?? "").trim().slice(0, 80);
  if (!Number.isInteger(seasonNumber) || seasonNumber < 1 || seasonNumber > 50) {
    return NextResponse.json(
      { error: "Season number must be a whole number (1–50)." },
      { status: 400 }
    );
  }

  const dup = await db
    .select({ id: seasons.id, seasonNumber: seasons.seasonNumber })
    .from(seasons)
    .where(eq(seasons.titleId, n))
    .limit(50)
    .then((rows) => rows.some((r) => r.seasonNumber === seasonNumber));
  if (dup) {
    return NextResponse.json(
      { error: `Season ${seasonNumber} already exists for this series.` },
      { status: 409 }
    );
  }

  const inserted = await db
    .insert(seasons)
    .values({ titleId: n, seasonNumber, name: name || `Season ${seasonNumber}` })
    .returning();
  revalidatePath("/", "layout");
  return NextResponse.json({ ok: true, item: inserted[0] }, { status: 201 });
}
