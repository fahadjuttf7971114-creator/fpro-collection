import { NextResponse } from "next/server";
import { and, desc, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { titles, seasons, episodes } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { listTitles, slugify } from "@/lib/queries";
import { parseTitleInput, type TitleInputFull } from "@/lib/title-input";
import { revalidatePath } from "next/cache";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const sp = url.searchParams;
  const typeParam = sp.get("type");
  const items = await listTitles({
    type: typeParam === "movie" || typeParam === "series" ? typeParam : undefined,
    genre: sp.get("genre") ?? undefined,
    region: sp.get("region") ?? undefined,
    year: sp.get("year") ? Number(sp.get("year")) : null,
    q: sp.get("q") ?? undefined,
    actor: sp.get("actor") ?? undefined,
    sort: (sp.get("sort") as "latest" | "popular" | "trending" | "rating") ?? "latest",
    limit: Math.min(Number(sp.get("limit") ?? 100), 200),
    offset: Number(sp.get("offset") ?? 0),
  });

  if (sp.get("withSeasons") === "1" && items.length > 0) {
    const s = await db
      .select()
      .from(seasons)
      .where(inArray(seasons.titleId, items.map((t) => t.id)))
      .orderBy(seasons.seasonNumber);
    const e = s.length
      ? await db
          .select()
          .from(episodes)
          .where(inArray(episodes.seasonId, s.map((x) => x.id)))
          .orderBy(episodes.number)
      : [];
    return NextResponse.json({
      items: items.map((t) => ({
        ...t,
        seasons: s
          .filter((sn) => sn.titleId === t.id)
          .map((sn) => ({
            ...sn,
            episodes: e.filter((ep) => ep.seasonId === sn.id),
          })),
      })),
    });
  }
  return NextResponse.json({ items });
}

export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user || !user.isAdmin) {
    return NextResponse.json({ error: "Admin access required." }, { status: 403 });
  }
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }
  const { errors, value } = parseTitleInput(body, false);
  if (errors.length) return NextResponse.json({ error: errors[0] }, { status: 400 });

  // unique slug
  let slug = slugify(value.title!);
  let n = 2;
  while (true) {
    const clash = await db
      .select({ id: titles.id })
      .from(titles)
      .where(eq(titles.slug, slug))
      .limit(1);
    if (clash.length === 0) break;
    slug = `${slugify(value.title!)}-${n++}`;
  }

  const payload = value as TitleInputFull;
  const inserted = await db
    .insert(titles)
    .values({ ...payload, slug })
    .returning();
  revalidatePath("/", "layout");
  return NextResponse.json({ ok: true, item: inserted[0] }, { status: 201 });
}
