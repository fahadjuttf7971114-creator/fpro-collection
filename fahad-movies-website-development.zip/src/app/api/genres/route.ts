import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { genres } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { genresWithCounts, slugify } from "@/lib/queries";
import { revalidatePath } from "next/cache";

export async function GET() {
  const items = await genresWithCounts();
  return NextResponse.json({
    items: items.map((g) => ({ ...g, count: Number(g.count) })),
  });
}

export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user || !user.isAdmin) {
    return NextResponse.json({ error: "Admin access required." }, { status: 403 });
  }
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }
  const name = String(body.name ?? "").trim();
  if (name.length < 2 || name.length > 40) {
    return NextResponse.json(
      { error: "Genre name must be 2–40 characters." },
      { status: 400 }
    );
  }
  const clash = await db.select({ id: genres.id }).from(genres).where(eq(genres.name, name)).limit(1);
  if (clash.length > 0) {
    return NextResponse.json({ error: "That genre already exists." }, { status: 409 });
  }
  const inserted = await db
    .insert(genres)
    .values({ name, slug: slugify(name) })
    .returning();
  revalidatePath("/", "layout");
  return NextResponse.json({ ok: true, item: inserted[0] }, { status: 201 });
}
