import { NextResponse } from "next/server";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { genres, titles } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { slugify } from "@/lib/queries";
import { revalidatePath } from "next/cache";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, ctx: Ctx) {
  const user = await getSessionUser();
  if (!user || !user.isAdmin) {
    return NextResponse.json({ error: "Admin access required." }, { status: 403 });
  }
  const { id } = await ctx.params;
  const n = Number(id);
  if (!Number.isInteger(n)) return NextResponse.json({ error: "Bad id" }, { status: 400 });

  const existing = await db.select().from(genres).where(eq(genres.id, n)).limit(1);
  if (existing.length === 0)
    return NextResponse.json({ error: "Genre not found." }, { status: 404 });
  const before = existing[0];

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  const patch: Partial<typeof genres.$inferInsert> = {};
  if (body.name !== undefined) {
    const name = String(body.name).trim();
    if (name.length < 2 || name.length > 40) {
      return NextResponse.json({ error: "Genre name must be 2–40 characters." }, { status: 400 });
    }
    if (name !== before.name) {
      const clash = await db
        .select({ id: genres.id })
        .from(genres)
        .where(eq(genres.name, name))
        .limit(1);
      if (clash.length > 0) {
        return NextResponse.json({ error: "That genre name already exists." }, { status: 409 });
      }
    }
    patch.name = name;
    patch.slug = slugify(name);
  }
  if (body.active !== undefined) patch.active = !!body.active;
  if (Object.keys(patch).length === 0) {
    return NextResponse.json({ error: "Nothing to update." }, { status: 400 });
  }

  // if renamed, propagate the new name to every title that used the old one
  if (patch.name && patch.name !== before.name) {
    await db
      .update(titles)
      .set({ genres: sql`array_replace(${titles.genres}, ${before.name}, ${patch.name})` })
      .where(sql`${before.name} = any(${titles.genres})`)
      .catch(() => undefined);
  }

  const updated = await db.update(genres).set(patch).where(eq(genres.id, n)).returning();
  revalidatePath("/", "layout");
  return NextResponse.json({ ok: true, item: updated[0] });
}

export async function DELETE(_req: Request, ctx: Ctx) {
  const user = await getSessionUser();
  if (!user || !user.isAdmin) {
    return NextResponse.json({ error: "Admin access required." }, { status: 403 });
  }
  const { id } = await ctx.params;
  const n = Number(id);
  const existing = await db.select().from(genres).where(eq(genres.id, n)).limit(1);
  if (existing.length === 0)
    return NextResponse.json({ error: "Genre not found." }, { status: 404 });

  const usage = await db
    .select({ n: sql<number>`count(*)` })
    .from(titles)
    .where(sql`${existing[0].name} = any(${titles.genres})`);
  if (Number(usage[0].n) > 0) {
    return NextResponse.json(
      {
        error: `Cannot delete — ${usage[0].n} title(s) still use this genre. Remove it from those titles first.`,
      },
      { status: 409 }
    );
  }
  await db.delete(genres).where(eq(genres.id, n));
  revalidatePath("/", "layout");
  return NextResponse.json({ ok: true });
}
