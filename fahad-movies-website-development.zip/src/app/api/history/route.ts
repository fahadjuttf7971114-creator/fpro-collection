import { NextResponse } from "next/server";
import { db } from "@/db";
import { getSessionUser } from "@/lib/auth";
import { getHistory, recordView } from "@/lib/queries";

export async function GET() {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "Login required." }, { status: 401 });
  const items = await getHistory(user.id, 24);
  return NextResponse.json({ items });
}

export async function POST(req: Request) {
  const user = await getSessionUser().catch(() => null);
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body." }, { status: 400 });
  }
  const titleId = Number(body.titleId);
  if (!Number.isInteger(titleId)) {
    return NextResponse.json({ error: "titleId is required." }, { status: 400 });
  }
  await recordView(user?.id ?? null, titleId);
  return NextResponse.json({ ok: true });
}
