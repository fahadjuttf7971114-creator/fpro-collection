import { NextResponse } from "next/server";
import { getSessionUser } from "@/lib/auth";
import { adminStats } from "@/lib/queries";

export async function GET() {
  const user = await getSessionUser();
  if (!user || !user.isAdmin) {
    return NextResponse.json({ error: "Admin access required." }, { status: 403 });
  }
  const stats = await adminStats();
  return NextResponse.json({ stats });
}
