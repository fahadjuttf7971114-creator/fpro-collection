import type { Metadata } from "next";
import ContactForm from "@/components/ContactForm";
import { IconMail, IconPin } from "@/components/icons";

export const metadata: Metadata = {
  title: "Contact",
  description: "Get in touch with the Fahad Movies team.",
};

export default function ContactPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6">
      <p className="text-[11px] font-black uppercase tracking-[0.25em] text-gold-400">
        Contact
      </p>
      <h1 className="mt-1 font-display text-5xl tracking-wide">Get in touch</h1>
      <p className="mt-4 max-w-xl text-[15px] leading-relaxed text-mist">
        Questions, licensing, or a title you&apos;d love to see on the
        platform? Drop us a line — we read everything.
      </p>

      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        <div className="rounded-xl border border-ink-700 bg-ink-900/60 p-5">
          <IconMail className="h-5 w-5 text-gold-400" />
          <p className="mt-2 text-sm font-bold">Email</p>
          <a href="mailto:hello@fahadmovies.example" className="text-sm text-mist hover:text-gold-400">
            hello@fahadmovies.example
          </a>
        </div>
        <div className="rounded-xl border border-ink-700 bg-ink-900/60 p-5">
          <IconPin className="h-5 w-5 text-gold-400" />
          <p className="mt-2 text-sm font-bold">Studio</p>
          <p className="text-sm text-mist">Karachi · Lahore · Dubai</p>
        </div>
      </div>

      <div className="mt-6 rounded-xl border border-ink-700/60 bg-ink-900/50 p-6">
        <ContactForm />
      </div>
    </div>
  );
}
