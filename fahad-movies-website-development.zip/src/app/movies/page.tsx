import type { Metadata } from "next";
import { Suspense } from "react";
import { db } from "@/db";
import { genres } from "@/db/schema";
import { eq } from "drizzle-orm";
import BrowseFilters from "@/components/BrowseFilters";
import TitleGrid from "@/components/TitleGrid";
import NoResults from "@/components/NoResults";
import { countTitles, distinctYears, listTitles } from "@/lib/queries";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "Movies",
  description:
    "Browse the full Fahad Movies catalog — filter by genre, region, year and sort by popularity, rating or release date.",
};

type Params = {
  genre?: string;
  region?: string;
  year?: string;
  sort?: string;
};

export default async function MoviesPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const params = await searchParams;
  const p: Params = {
    genre: typeof params.genre === "string" ? params.genre : undefined,
    region: typeof params.region === "string" ? params.region : undefined,
    year: typeof params.year === "string" ? params.year : undefined,
    sort: typeof params.sort === "string" ? params.sort : undefined,
  };

  const [genreRows, years, total] = await Promise.all([
    db
      .select({ name: genres.name })
      .from(genres)
      .where(eq(genres.active, true))
      .orderBy(genres.name),
    distinctYears(),
    countTitles({
      type: "movie",
      genre: p.genre,
      region: p.region,
      year: p.year ? Number(p.year) : null,
      sort: p.sort as "latest" | "popular" | "trending" | "rating" | undefined,
    }),
  ]);
  const items = await listTitles({
    type: "movie",
    genre: p.genre,
    region: p.region,
    year: p.year ? Number(p.year) : null,
    sort: p.sort as "latest" | "popular" | "trending" | "rating" | undefined,
    limit: 60,
  });

  const activeGenres = genreRows.map((g) => g.name);
  const regions = ["Hollywood", "Bollywood", "Pakistani"];
  const heading = [p.genre, p.region, p.year]
    .filter(Boolean)
    .join(" · ") || "All Movies";

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-6">
        <p className="text-[11px] font-black uppercase tracking-[0.2em] text-gold-400">
          Catalog
        </p>
        <h1 className="mt-1 font-display text-4xl tracking-wide sm:text-5xl">
          {heading}
        </h1>
        <p className="mt-2 text-sm text-mist">
          {total} movie{total === 1 ? "" : "s"} available to stream.
        </p>
      </div>

      <Suspense>
        <BrowseFilters
          params={{ genre: p.genre, region: p.region, year: p.year, sort: p.sort }}
          genres={activeGenres}
          regions={regions}
          years={years}
        />
      </Suspense>

      {items.length > 0 ? (
        <TitleGrid items={items} />
      ) : (
        <NoResults
          message="No movies found"
          hint="Nothing matches that combination of genre, region and year. Try removing a filter."
        />
      )}
    </div>
  );
}
