import type { Metadata } from "next";
import InfoPage from "@/components/InfoPage";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: "How Fahad Movies handles your data.",
};

export default function PrivacyPage() {
  return (
    <InfoPage kicker="Legal" title="Privacy Policy">
      <p>Last updated: January 2025</p>
      <h2>What we collect</h2>
      <p>
        When you create an account we store your name, email address and a
        cryptographically hashed password. While you use the site we record
        which titles you watch so we can show you your recently-viewed list,
        and which titles you add to favorites.
      </p>
      <h2>How we use it</h2>
      <p>
        Your data powers your account: watchlists, viewing history, personalized
        recommendations and the admin statistics dashboard. We do not sell
        personal data to third parties, full stop.
      </p>
      <h2>Cookies</h2>
      <p>
        We use a single secure, HTTP-only session cookie to keep you signed in.
        Clearing your browser data or signing out ends the session.
      </p>
      <h2>Your choices</h2>
      <p>
        You can delete your favorites and history at any time, and you can
        request account deletion by contacting us. Deleting your account
        removes your personal data permanently.
      </p>
      <h2>Contact</h2>
      <p>
        Questions about privacy? Reach us through the{" "}
        <a href="/contact">contact page</a>.
      </p>
    </InfoPage>
  );
}
