import type { Metadata } from "next";
import { Suspense } from "react";
import { db } from "@/db";
import { genres } from "@/db/schema";
import { eq } from "drizzle-orm";
import SearchForm from "@/components/SearchForm";
import TitleGrid from "@/components/TitleGrid";
import NoResults from "@/components/NoResults";
import { distinctYears, listTitles } from "@/lib/queries";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "Search",
  description:
    "Search the Fahad Movies catalog by title, actor, genre and release year.",
};

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const params = await searchParams;
  const q = typeof params.q === "string" ? params.q.trim() : "";
  const actor = typeof params.actor === "string" ? params.actor.trim() : "";
  const genre = typeof params.genre === "string" ? params.genre : "";
  const year = typeof params.year === "string" ? params.year : "";
  const type = typeof params.type === "string" ? params.type : "";

  const [genreRows, years, items] = await Promise.all([
    db
      .select({ name: genres.name })
      .from(genres)
      .where(eq(genres.active, true))
      .orderBy(genres.name),
    distinctYears(),
    listTitles({
      q: q || undefined,
      actor: actor || undefined,
      genre: genre || undefined,
      year: year ? Number(year) : null,
      type: (type === "movie" || type === "series" ? type : undefined),
      sort: "rating",
      limit: 48,
    }),
  ]);

  const searched = !!(q || actor || genre || year);

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-8">
        <p className="text-[11px] font-black uppercase tracking-[0.2em] text-gold-400">
          Find anything
        </p>
        <h1 className="mt-1 font-display text-4xl tracking-wide sm:text-5xl">Search</h1>
        <p className="mt-2 max-w-xl text-sm text-mist">
          Search by movie name, actor, genre or release year — combine as many
          filters as you like.
        </p>
      </div>

      <Suspense>
        <SearchForm
          genres={genreRows.map((g) => g.name)}
          years={years}
          initial={{ q, actor, genre, year, type }}
        />
      </Suspense>

      <div className="mt-10">
        {items.length > 0 ? (
          <>
            <p className="mb-5 text-sm text-mist">
              <span className="font-bold text-cream">{items.length}</span> result
              {items.length === 1 ? "" : "s"}
              {q && (
                <>
                  {" "}for <span className="font-bold text-gold-400">“{q}”</span>
                </>
              )}
              {actor && (
                <>
                  {" "}starring{" "}
                  <span className="font-bold text-gold-400">{actor}</span>
                </>
              )}
            </p>
            <TitleGrid items={items} />
          </>
        ) : (
          <NoResults
            message={searched ? "No results found" : "Start your search"}
            hint={
              searched
                ? "We couldn't find anything matching those filters. Check the spelling or try a broader search."
                : "Type a title or actor name above, or pick a genre and year to explore the catalog."
            }
            popular={["Action", "Drama", "Sci-Fi", "Romance", "Thriller"]}
            basePath="/search"
          />
        )}
      </div>
    </div>
  );
}
