import type { Metadata } from "next";
import Link from "next/link";
import { genresWithCounts, regionCounts } from "@/lib/queries";
import { IconChevronRight } from "@/components/icons";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "Genres & Categories",
  description:
    "Browse Fahad Movies by category — Action, Adventure, Comedy, Drama, Horror, Romance, Sci-Fi, Thriller, Animation, Bollywood, Hollywood and Pakistani cinema.",
};

const GENRE_TILES: Record<string, string> = {
  Action: "from-[#7f1d1d] via-[#451a1a] to-ink-900",
  Adventure: "from-[#14532d] via-[#123422] to-ink-900",
  Comedy: "from-[#92400e] via-[#4a2c14] to-ink-900",
  Drama: "from-[#312e81] via-[#232140] to-ink-900",
  Horror: "from-[#3f1d38] via-[#24131f] to-ink-900",
  Romance: "from-[#831843] via-[#3f1226] to-ink-900",
  "Sci-Fi": "from-[#164e63] via-[#122a33] to-ink-900",
  Thriller: "from-[#374151] via-[#1f2430] to-ink-900",
  Animation: "from-[#5b21b6] via-[#2b1745] to-ink-900",
  Bollywood: "from-[#7c2d12] via-[#3d1a0e] to-ink-900",
  Hollywood: "from-[#0f3443] via-[#122129] to-ink-900",
  Pakistani: "from-[#14532d] via-[#102a2e] to-ink-900",
};

export default async function GenresPage() {
  const [genreRows, regionRows] = await Promise.all([
    genresWithCounts(),
    regionCounts(),
  ]);

  const genreItems = genreRows.filter((g) => !regionRows.some((r) => r.region === g.name));
  const regionItems = regionRows;

  const tile = (name: string, count: number, href: string, isRegion = false) => (
    <Link
      key={name}
      href={href}
      className={`group relative overflow-hidden rounded-xl border border-ink-700/60 bg-gradient-to-br ${
        GENRE_TILES[name] ?? "from-ink-700 via-ink-800 to-ink-900"
      } p-5 transition-all duration-300 hover:-translate-y-1 hover:border-gold-500/40 hover:shadow-xl hover:shadow-black/50`}
    >
      <div
        className="pointer-events-none absolute -right-6 -top-6 h-28 w-28 rounded-full bg-gold-500/10 blur-2xl transition-all group-hover:bg-gold-500/20"
        aria-hidden
      />
      <span className="font-display text-3xl tracking-wide text-cream">{name}</span>
      <p className="mt-1 text-xs font-semibold text-mist">
        {count} title{count === 1 ? "" : "s"}
      </p>
      <span className="mt-4 inline-flex items-center gap-1 text-xs font-bold uppercase tracking-wider text-gold-400 opacity-0 transition-all duration-300 group-hover:opacity-100">
        {isRegion ? "Browse region" : "Browse genre"}
        <IconChevronRight className="h-3.5 w-3.5" />
      </span>
    </Link>
  );

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-8">
        <p className="text-[11px] font-black uppercase tracking-[0.2em] text-gold-400">
          Categories
        </p>
        <h1 className="mt-1 font-display text-4xl tracking-wide sm:text-5xl">
          Browse by Genre
        </h1>
        <p className="mt-2 max-w-xl text-sm text-mist">
          Twelve curated categories across genres and regions. Pick a lane and
          we'll line up the best titles in it.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {genreItems.map((g) =>
          tile(g.name, Number(g.count), `/movies?genre=${encodeURIComponent(g.name)}`)
        )}
      </div>

      <h2 className="mb-4 mt-12 font-display text-3xl tracking-wide">By Region</h2>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        {regionItems.map((r) =>
          tile(r.region, r.count, `/movies?region=${encodeURIComponent(r.region)}`, true)
        )}
      </div>
    </div>
  );
}
