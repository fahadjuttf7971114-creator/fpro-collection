import { db } from "@/db";
import { seasons, episodes, genres } from "@/db/schema";
import { sql, desc, eq } from "drizzle-orm";
import HeroBanner from "@/components/HeroBanner";
import TitleRow from "@/components/TitleRow";
import CategoryStrip from "@/components/CategoryStrip";
import { getSessionUser } from "@/lib/auth";
import {
  listTitles,
  getFeatured,
  getHistory,
  regionCounts,
  type TitleData,
} from "@/lib/queries";

export const dynamic = "force-dynamic";

type SeasonMeta = Record<number, { seasons: number; episodes: number }>;

async function buildSeasonMeta(): Promise<SeasonMeta> {
  const [sAgg, eAgg] = await Promise.all([
    db
      .select({ titleId: seasons.titleId, n: sql<number>`count(*)` })
      .from(seasons)
      .groupBy(seasons.titleId),
    db
      .select({ titleId: episodes.titleId, n: sql<number>`count(*)` })
      .from(episodes)
      .groupBy(episodes.titleId),
  ]);
  const meta: SeasonMeta = {};
  for (const r of sAgg) meta[r.titleId] = { seasons: Number(r.n), episodes: 0 };
  for (const r of eAgg) {
    meta[r.titleId] = meta[r.titleId] || { seasons: 0, episodes: 0 };
    meta[r.titleId].episodes = Number(r.n);
  }
  return meta;
}

async function genreCounts() {
  const rows = await db
    .select({
      name: genres.name,
      count: sql<number>`(select count(*) from titles t where exists (
        select 1 from unnest(t.genres) g where g = ${genres.name}
      ))`,
    })
    .from(genres)
    .where(eq(genres.active, true))
    .orderBy(desc(sql`(select count(*) from titles t where exists (
      select 1 from unnest(t.genres) g where g = ${genres.name}
    ))`), genres.name);
  return rows.map((r) => ({ name: r.name, count: Number(r.count) }));
}

export default async function HomePage() {
  const [
    featured,
    latest,
    popular,
    trending,
    seriesLatest,
    action,
    scifi,
    drama,
    horror,
    comedy,
    bollywood,
    pakistani,
    seasonMeta,
    genreList,
    regionList,
    user,
  ] = await Promise.all([
    getFeatured(5),
    listTitles({ type: "movie", sort: "latest", limit: 12 }),
    listTitles({ type: "movie", sort: "popular", limit: 12 }),
    listTitles({ type: "movie", sort: "trending", limit: 12 }),
    listTitles({ type: "series", sort: "latest", limit: 12 }),
    listTitles({ genre: "Action", sort: "rating", limit: 12 }),
    listTitles({ genre: "Sci-Fi", sort: "rating", limit: 12 }),
    listTitles({ genre: "Drama", sort: "rating", limit: 12 }),
    listTitles({ genre: "Horror", sort: "rating", limit: 12 }),
    listTitles({ genre: "Comedy", sort: "rating", limit: 12 }),
    listTitles({ region: "Bollywood", sort: "rating", limit: 12 }),
    listTitles({ region: "Pakistani", sort: "rating", limit: 12 }),
    buildSeasonMeta(),
    genreCounts(),
    regionCounts().then((r) => r.map((x) => ({ name: x.region, count: x.count }))),
    getSessionUser(),
  ]);

  const continueWatching = user ? await getHistory(user.id, 12) : [];

  const rows: { title: string; href: string; items: TitleData[] }[] = [
    ...(continueWatching.length > 0
      ? [
          {
            title: `Continue Watching, ${user!.name.split(" ")[0]}`,
            href: "/account",
            items: continueWatching,
          },
        ]
      : []),
    { title: "Latest Movies", href: "/movies?sort=latest", items: latest },
    { title: "Popular Movies", href: "/movies?sort=popular", items: popular },
    { title: "Trending Now", href: "/movies?sort=trending", items: trending },
    { title: "Latest TV Series", href: "/series?sort=latest", items: seriesLatest },
    { title: "Action & Adrenaline", href: "/movies?genre=Action", items: action },
    { title: "Sci-Fi Worlds", href: "/movies?genre=Sci-Fi", items: scifi },
    { title: "Award-Worthy Drama", href: "/movies?genre=Drama", items: drama },
    { title: "Horror Night", href: "/movies?genre=Horror", items: horror },
    { title: "Comedy Corner", href: "/movies?genre=Comedy", items: comedy },
    { title: "Bollywood Spotlight", href: "/movies?region=Bollywood", items: bollywood },
    { title: "Pakistani Cinema", href: "/movies?region=Pakistani", items: pakistani },
  ];

  return (
    <div>
      <HeroBanner items={featured} seasonMeta={seasonMeta} />
      <div className="relative z-10 -mt-8 space-y-12 pb-4">
        <div className="px-4 sm:px-6 lg:px-8">
          <CategoryStrip genres={genreList} regions={regionList} />
        </div>
        {rows.map((r) => (
          <TitleRow
            key={r.title}
            title={r.title}
            href={r.href}
            items={r.items}
            seasonMeta={seasonMeta}
          />
        ))}
      </div>
    </div>
  );
}
