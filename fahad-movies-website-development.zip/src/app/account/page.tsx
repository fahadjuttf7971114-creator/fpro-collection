import type { Metadata } from "next";
import { redirect } from "next/navigation";
import Link from "next/link";
import { getSessionUser } from "@/lib/auth";
import { db } from "@/db";
import { favorites, watchHistory } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { getHistory } from "@/lib/queries";
import NameEditor from "@/components/NameEditor";
import TitleGrid from "@/components/TitleGrid";
import LogoutButton from "@/components/LogoutButton";
import { IconHeart, IconLayers, IconLogout, IconPlay } from "@/components/icons";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "My Account",
  description: "Your Fahad Movies profile, favorites and watch history.",
};

export default async function AccountPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login?next=/account");

  const [recent, favCount, histCount] = await Promise.all([
    getHistory(user.id, 12),
    db
      .select({ n: sql<number>`count(*)` })
      .from(favorites)
      .where(eq(favorites.userId, user.id)),
    db
      .select({ n: sql<number>`count(*)` })
      .from(watchHistory)
      .where(eq(watchHistory.userId, user.id)),
  ]);

  const memberSince = new Date(user.createdAt).toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  });

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-8">
        <p className="text-[11px] font-black uppercase tracking-[0.2em] text-gold-400">
          Profile
        </p>
        <h1 className="mt-1 font-display text-4xl tracking-wide sm:text-5xl">My Account</h1>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* profile card */}
        <div className="rounded-xl border border-ink-700 bg-ink-900/60 p-5">
          <div className="flex items-center gap-4">
            <span className="grid h-14 w-14 place-items-center rounded-full bg-gold-500/15 font-display text-3xl text-gold-400">
              {user.name[0]?.toUpperCase()}
            </span>
            <div className="min-w-0">
              <NameEditor name={user.name} email={user.email} />
            </div>
          </div>

          <div className="mt-5 flex items-center justify-between border-t border-ink-700/50 pt-4 text-xs text-faint">
            <span>Member since {memberSince}</span>
            {user.isAdmin && (
              <Link
                href="/admin"
                className="rounded bg-gold-500/15 px-2 py-0.5 text-[11px] font-black uppercase tracking-wider text-gold-400"
              >
                Admin
              </Link>
            )}
          </div>

          <div className="mt-5 grid grid-cols-2 gap-3">
            <div className="rounded-lg border border-ink-700 bg-ink-800/60 p-3 text-center">
              <IconHeart className="mx-auto h-5 w-5 text-live" />
              <p className="mt-1.5 font-display text-2xl text-cream">{favCount[0].n}</p>
              <p className="text-[11px] font-bold uppercase tracking-wider text-faint">Favorites</p>
            </div>
            <div className="rounded-lg border border-ink-700 bg-ink-800/60 p-3 text-center">
              <IconLayers className="mx-auto h-5 w-5 text-gold-400" />
              <p className="mt-1.5 font-display text-2xl text-cream">{histCount[0].n}</p>
              <p className="text-[11px] font-bold uppercase tracking-wider text-faint">Watched</p>
            </div>
          </div>

          <div className="mt-5 grid gap-2">
            <Link
              href="/favorites"
              className="inline-flex items-center justify-center gap-2 rounded-md bg-gold-500 px-4 py-2.5 text-sm font-bold text-ink-950 hover:bg-gold-400"
            >
              <IconPlay className="h-4 w-4" /> Open Watchlist
            </Link>
            <LogoutButton />
          </div>
        </div>

        {/* history */}
        <div className="lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-display text-3xl tracking-wide">Recently Viewed</h2>
            <Link href="/favorites" className="text-xs font-bold uppercase tracking-wider text-mist hover:text-gold-400">
              Manage list
            </Link>
          </div>
          {recent.length > 0 ? (
            <TitleGrid items={recent} cols="grid-cols-2 sm:grid-cols-3 md:grid-cols-4" />
          ) : (
            <div className="flex flex-col items-center rounded-xl border border-dashed border-ink-600 bg-ink-900/40 px-6 py-16 text-center">
              <IconPlay className="h-8 w-8 text-faint" />
              <p className="mt-4 font-semibold text-mist">You haven't watched anything yet.</p>
              <p className="mt-1 text-sm text-faint">
                Your recent movies and episodes will appear here.
              </p>
              <Link
                href="/movies"
                className="mt-5 rounded-md bg-gold-500 px-5 py-2.5 text-sm font-bold text-ink-950 hover:bg-gold-400"
              >
                Find something to watch
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
