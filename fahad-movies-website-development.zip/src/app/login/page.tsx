import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { Suspense } from "react";
import { getSessionUser } from "@/lib/auth";
import AuthForm from "@/components/AuthForm";

export const metadata: Metadata = {
  title: "Login",
  description: "Log in to your Fahad Movies account.",
};

export default async function LoginPage() {
  const user = await getSessionUser();
  if (user) redirect("/account");

  return (
    <div className="mx-auto flex max-w-md flex-col px-4 py-14">
      <div className="text-center">
        <p className="text-[11px] font-black uppercase tracking-[0.25em] text-gold-400">
          Welcome back
        </p>
        <h1 className="mt-1 font-display text-5xl tracking-wide">Log In</h1>
        <p className="mt-2 text-sm text-mist">
          Your watchlist, history and favorites — wherever you sit down.
        </p>
      </div>

      <div className="mt-8 rounded-xl border border-ink-700/60 bg-ink-900/60 p-6">
        <Suspense>
          <AuthForm mode="login" />
        </Suspense>
      </div>

      <div className="mt-4 rounded-xl border border-gold-500/20 bg-gold-500/5 p-4 text-xs leading-relaxed text-mist">
        <p className="font-bold uppercase tracking-wider text-gold-400">Demo accounts</p>
        <p className="mt-1.5">
          Viewer — <span className="font-mono text-cream">demo@fahadmovies.com</span> /{" "}
          <span className="font-mono text-cream">demo123</span>
        </p>
        <p>
          Admin — <span className="font-mono text-cream">admin@fahadmovies.com</span> /{" "}
          <span className="font-mono text-cream">admin123</span>
        </p>
      </div>
    </div>
  );
}
