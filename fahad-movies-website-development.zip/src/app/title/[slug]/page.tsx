import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { getSessionUser } from "@/lib/auth";
import { hasFavorite, getSimilar, getTitleBySlug } from "@/lib/queries";
import PosterImg from "@/components/PosterImg";
import TrailerModal from "@/components/TrailerModal";
import FavoriteButton from "@/components/FavoriteButton";
import SeriesEpisodes from "@/components/SeriesEpisodes";
import TitleGrid from "@/components/TitleGrid";
import TrailerButton from "@/components/TrailerButton";
import {
  IconCalendar,
  IconClock,
  IconEye,
  IconFilm,
  IconPlay,
  IconStar,
  IconTv,
} from "@/components/icons";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const data = await getTitleBySlug(slug);
  if (!data) return { title: "Not found" };
  return {
    title: data.title.title,
    description: data.title.description.slice(0, 160),
    openGraph: {
      title: data.title.title,
      description: data.title.description.slice(0, 160),
      images: [{ url: data.title.poster || data.title.backdrop }],
    },
  };
}

export default async function TitlePage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const data = await getTitleBySlug(slug);
  if (!data) notFound();
  const { title, seasons } = data;

  const user = await getSessionUser();
  const [similar, fav] = await Promise.all([
    getSimilar(slug, 10),
    user ? hasFavorite(user.id, title.id) : Promise.resolve(false),
  ]);

  const episodeCount = seasons.reduce((n, s) => n + s.episodes.length, 0);

  const jsonLd =
    title.type === "movie"
      ? {
          "@context": "https://schema.org",
          "@type": "Movie",
          name: title.title,
          dateCreated: String(title.year),
          description: title.description,
          image: title.poster || title.backdrop || undefined,
          genre: title.genres,
          actor: title.cast.map((n) => ({ "@type": "Person", name: n })),
          duration: title.duration > 0 ? `PT${title.duration}M` : undefined,
          aggregateRating: {
            "@type": "AggregateRating",
            ratingValue: Number(title.rating),
            bestRating: 10,
            worstRating: 0,
            ratingCount: title.views,
          },
        }
      : {
          "@context": "https://schema.org",
          "@type": "TVSeries",
          name: title.title,
          dateCreated: String(title.year),
          description: title.description,
          image: title.poster || title.backdrop || undefined,
          genre: title.genres,
          numberOfSeasons: seasons.length,
          numberOfEpisodes: episodeCount,
          aggregateRating: {
            "@type": "AggregateRating",
            ratingValue: Number(title.rating),
            bestRating: 10,
            worstRating: 0,
            ratingCount: title.views,
          },
        };

  return (
    <div>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      {/* banner */}
      <div className="relative overflow-hidden border-b border-ink-700/50">
        <div className="absolute inset-0">
          <img
            src={title.backdrop || title.poster}
            alt=""
            className="h-full w-full object-cover opacity-50"
            loading="eager"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/60 to-ink-950/30" />
          <div className="absolute inset-0 bg-gradient-to-r from-ink-950/80 to-transparent" />
        </div>

        <div className="relative mx-auto flex max-w-7xl gap-6 px-4 pb-8 pt-12 sm:px-6 sm:pt-16 lg:flex-row lg:gap-10 lg:px-8">
          <div className="mx-auto w-44 shrink-0 sm:w-56 lg:mx-0 lg:w-64">
            <div className="overflow-hidden rounded-xl border border-ink-600/60 shadow-2xl shadow-black/70">
              <PosterImg src={title.poster} alt={title.title} className="aspect-[2/3] w-full" eager />
            </div>
          </div>

          <div className="flex-1 self-end anim-fade-up">
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 rounded bg-gold-500 px-2 py-0.5 text-[11px] font-black uppercase tracking-widest text-ink-950">
                {title.type === "series" ? <IconTv className="h-3 w-3" /> : <IconFilm className="h-3 w-3" />}
                {title.type === "series" ? "TV Series" : "Movie"}
              </span>
              <span className="rounded border border-ink-600 bg-ink-900/70 px-2 py-0.5 text-[11px] font-bold text-mist">
                {title.region}
              </span>
              {title.isTrending && (
                <span className="rounded bg-live/90 px-2 py-0.5 text-[11px] font-black uppercase tracking-widest text-white/95">
                  Trending
                </span>
              )}
            </div>

            <h1 className="hero-title-shadow mt-3 font-display text-5xl leading-none tracking-wide sm:text-6xl">
              {title.title}
            </h1>

            <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 text-sm">
              <span className="inline-flex items-center gap-1.5 font-bold text-gold-400">
                <IconStar className="h-4 w-4" /> {Number(title.rating).toFixed(1)}
                <span className="font-semibold text-mist">/ 10</span>
              </span>
              <span className="inline-flex items-center gap-1.5 text-mist">
                <IconCalendar className="h-4 w-4" /> {title.year}
              </span>
              {title.type === "movie" ? (
                <span className="inline-flex items-center gap-1.5 text-mist">
                  <IconClock className="h-4 w-4" /> {title.duration} min
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 text-mist">
                  <IconTv className="h-4 w-4" />
                  {seasons.length} Season{seasons.length === 1 ? "" : "s"} · {episodeCount} Episodes
                </span>
              )}
              <span className="inline-flex items-center gap-1.5 text-faint">
                <IconEye className="h-4 w-4" /> {title.views.toLocaleString()} views
              </span>
            </div>

            <div className="mt-3 flex flex-wrap gap-1.5">
              {title.genres.map((g) => (
                <Link
                  key={g}
                  href={`${title.type === "series" ? "/series" : "/movies"}?genre=${encodeURIComponent(g)}`}
                  className="rounded-full border border-ink-600 bg-ink-900/70 px-3 py-1 text-xs font-semibold text-mist transition-colors hover:border-gold-500/50 hover:text-gold-300"
                >
                  {g}
                </Link>
              ))}
            </div>

            <div className="mt-6 flex flex-wrap gap-3">
              <Link
                href={`/watch/${title.slug}`}
                className="inline-flex items-center gap-2 rounded-md bg-gold-500 px-6 py-3 text-sm font-black uppercase tracking-wider text-ink-950 shadow-xl shadow-gold-500/25 transition-all hover:bg-gold-400 active:scale-95"
              >
                <IconPlay className="h-4 w-4" />
                {title.type === "series" ? "Watch S1 E1" : "Watch Movie"}
              </Link>
              <TrailerButton trailer={title.trailer} title={title.title} />
              <FavoriteButton titleId={title.id} active={fav} />
            </div>
          </div>
        </div>
      </div>

      {/* body */}
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-5">
          <div className="lg:col-span-3">
            <h2 className="font-display text-3xl tracking-wide">Storyline</h2>
            <p className="mt-3 whitespace-pre-line leading-relaxed text-cream/85">
              {title.description}
            </p>

            {title.cast.length > 0 && (
              <>
                <h2 className="mt-10 font-display text-3xl tracking-wide">Cast</h2>
                <div className="mt-4 flex flex-wrap gap-2">
                  {title.cast.map((c) => (
                    <Link
                      key={c}
                      href={`/search?actor=${encodeURIComponent(c)}`}
                      className="rounded-full border border-ink-600 bg-ink-900 px-4 py-1.5 text-sm font-semibold text-mist transition-colors hover:border-gold-500/50 hover:text-gold-300"
                    >
                      {c}
                    </Link>
                  ))}
                </div>
              </>
            )}

            {title.type === "series" && (
              <>
                <h2 className="mt-10 font-display text-3xl tracking-wide">Episodes</h2>
                <div className="mt-4">
                  <SeriesEpisodes slug={title.slug} seasons={seasons} />
                </div>
              </>
            )}
          </div>

          <div className="lg:col-span-2">
            <div className="rounded-xl border border-ink-700 bg-ink-900/60 p-5">
              <h3 className="font-display text-2xl tracking-wide">Details</h3>
              <dl className="mt-4 space-y-3 text-sm">
                {[
                  ["Title", title.title],
                  ["Type", title.type === "series" ? "TV Series" : "Movie"],
                  ["Release year", String(title.year)],
                  ["Region", title.region],
                  ["Genres", title.genres.join(", ")],
                  [
                    title.type === "series" ? "Episodes" : "Duration",
                    title.type === "series"
                      ? `${seasons.length} seasons · ${episodeCount} episodes`
                      : `${title.duration} minutes`,
                  ],
                  ["Rating", `${Number(title.rating).toFixed(1)} / 10`],
                  ["Views", title.views.toLocaleString()],
                ].map(([k, v]) => (
                  <div key={k} className="flex justify-between gap-4 border-b border-ink-700/40 pb-2.5 last:border-0">
                    <dt className="shrink-0 text-faint">{k}</dt>
                    <dd className="text-right font-semibold text-cream/90">{v}</dd>
                  </div>
                ))}
              </dl>
              <Link
                href={`/watch/${title.slug}`}
                className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-md bg-gold-500 px-5 py-3 text-sm font-black uppercase tracking-wider text-ink-950 transition-all hover:bg-gold-400"
              >
                <IconPlay className="h-4 w-4" /> Play now
              </Link>
            </div>
          </div>
        </div>

        {similar.length > 0 && (
          <div className="mt-14">
            <h2 className="mb-5 font-display text-3xl tracking-wide">Similar Titles</h2>
            <TitleGrid items={similar} />
          </div>
        )}
      </div>
    </div>
  );
}
