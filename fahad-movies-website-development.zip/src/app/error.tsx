"use client";

import { useEffect } from "react";
import Link from "next/link";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    // eslint-disable-next-line no-console
    console.error(error);
  }, [error]);

  return (
    <div className="flex min-h-[50vh] flex-col items-center justify-center px-4 text-center">
      <span className="grid h-16 w-16 place-items-center rounded-full border border-bad/30 bg-bad/10 text-2xl font-black text-bad">
        !
      </span>
      <h1 className="mt-5 font-display text-4xl tracking-wide text-cream">
        Something went wrong
      </h1>
      <p className="mt-2 max-w-sm text-sm text-mist">
        An unexpected error interrupted playback. Try reloading — if it
        keeps happening, head back home.
      </p>
      <div className="mt-6 flex gap-3">
        <button
          onClick={reset}
          className="rounded-md bg-gold-500 px-5 py-2.5 text-sm font-bold text-ink-950 hover:bg-gold-400"
        >
          Try again
        </button>
        <Link
          href="/"
          className="rounded-md border border-ink-600 px-5 py-2.5 text-sm font-bold text-cream hover:border-gold-500/50"
        >
          Go home
        </Link>
      </div>
    </div>
  );
}
