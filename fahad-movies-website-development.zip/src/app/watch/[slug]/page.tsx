import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import { getTitleBySlug, getSimilar } from "@/lib/queries";
import VideoPlayer from "@/components/VideoPlayer";
import SeriesEpisodes from "@/components/SeriesEpisodes";
import TitleGrid from "@/components/TitleGrid";
import WatchTracker from "@/components/WatchTracker";
import { IconStar } from "@/components/icons";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const data = await getTitleBySlug(slug);
  if (!data) return { title: "Not found" };
  return { title: `Watch ${data.title.title}` };
}

export default async function WatchPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const { slug } = await params;
  const sp = await searchParams;
  const seasonNum = sp.season ? Number(sp.season) : NaN;
  const epNum = sp.ep ? Number(sp.ep) : NaN;

  const data = await getTitleBySlug(slug);
  if (!data) notFound();
  const { title, seasons } = data;

  const flat = seasons.flatMap((s) =>
    s.episodes.map((e) => ({ ...e, seasonNumber: s.seasonNumber }))
  );

  let current;
  if (title.type === "series" && flat.length > 0) {
    current =
      flat.find((e) => e.seasonNumber === seasonNum && e.number === epNum) ?? flat[0];
  }
  const src = current ? current.video || title.video : title.video;

  const idx = current ? flat.findIndex((e) => e.id === current.id) : -1;
  const prevEp = idx > 0 ? flat[idx - 1] : undefined;
  const nextEp = idx >= 0 && idx < flat.length - 1 ? flat[idx + 1] : undefined;

  const similar = await getSimilar(slug, 6);

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
      <nav className="mb-4 flex items-center gap-2 text-xs text-faint" aria-label="Breadcrumb">
        <Link href="/" className="hover:text-gold-400">Home</Link>
        <span>/</span>
        <Link
          href={title.type === "series" ? "/series" : "/movies"}
          className="hover:text-gold-400"
        >
          {title.type === "series" ? "TV Series" : "Movies"}
        </Link>
        <span>/</span>
        <Link href={`/title/${title.slug}`} className="text-mist hover:text-gold-400">
          {title.title}
        </Link>
      </nav>

      <WatchTracker titleId={title.id} />

      <VideoPlayer
        key={current ? `${current.id}` : title.slug}
        src={src}
        title={current ? `${title.title} — ${current.name || `Episode ${current.number}`}` : title.title}
        poster={title.backdrop || title.poster}
        autoPlay
        prev={
          prevEp
            ? {
                href: `/watch/${title.slug}?season=${prevEp.seasonNumber}&ep=${prevEp.number}`,
                label: "Previous",
              }
            : undefined
        }
        next={
          nextEp
            ? {
                href: `/watch/${title.slug}?season=${nextEp.seasonNumber}&ep=${nextEp.number}`,
                label: "Next",
              }
            : undefined
        }
      />

      <div className="mt-6 flex flex-wrap items-start justify-between gap-6">
        <div className="max-w-2xl">
          <h1 className="font-display text-4xl tracking-wide">
            {title.title}
            {current && (
              <span className="text-mist">
                {" "}· S{current.seasonNumber} E{current.number}
              </span>
            )}
          </h1>
          <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-mist">
            <span className="inline-flex items-center gap-1 font-bold text-gold-400">
              <IconStar className="h-4 w-4" /> {Number(title.rating).toFixed(1)}
            </span>
            <span>{title.year}</span>
            <span>{title.genres.slice(0, 3).join(" · ")}</span>
            <Link href={`/title/${title.slug}`} className="font-bold text-mist underline-offset-2 hover:text-gold-400 hover:underline">
              Full details
            </Link>
          </div>
          <p className="mt-3 line-clamp-3 text-sm leading-relaxed text-mist">
            {current?.description || title.description}
          </p>
        </div>
      </div>

      {title.type === "series" && (
        <div className="mt-8 rounded-xl border border-ink-700/60 bg-ink-900/40 p-4 sm:p-5">
          <h2 className="mb-4 font-display text-2xl tracking-wide">Episodes</h2>
          <SeriesEpisodes slug={title.slug} seasons={seasons} compact />
        </div>
      )}

      {similar.length > 0 && (
        <div className="mt-12">
          <h2 className="mb-5 font-display text-3xl tracking-wide">You might also like</h2>
          <TitleGrid items={similar} cols="grid-cols-2 sm:grid-cols-3 lg:grid-cols-6" />
        </div>
      )}
    </div>
  );
}
