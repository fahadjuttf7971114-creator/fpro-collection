import type { Metadata } from "next";
import InfoPage from "@/components/InfoPage";

export const metadata: Metadata = {
  title: "About Us",
  description: "The story behind Fahad Movies.",
};

export default function AboutPage() {
  return (
    <InfoPage kicker="About us" title="Fahad Movies">
      <p>
        <strong>Fahad Movies</strong> started with a simple idea: a place where
        discovering what to watch feels as good as the first ten minutes of a
        great film. No clutter, no noise — just a dark, cinematic room where the
        catalog is the star.
      </p>
      <h2>What we do</h2>
      <p>
        We curate movies and TV series across Hollywood, Bollywood and
        Pakistani cinema, organized into twelve browsable categories. Every
        title carries a full details page — cast, ratings, seasons, episodes —
        and a fast, keyboard-friendly player.
      </p>
      <h2>Our promise</h2>
      <p>
        We only stream and embed content that our platform is legally
        authorized to host. No pirated sources, no shady downloads. When we add
        a title, it's because we're allowed to show it.
      </p>
      <h2>Built for everyone</h2>
      <p>
        From a phone on the commute to a living-room TV, Fahad Movies is
        designed mobile-first and stays fast on any connection. Create a free
        account to keep your favorites and pick up right where you left off.
      </p>
    </InfoPage>
  );
}
