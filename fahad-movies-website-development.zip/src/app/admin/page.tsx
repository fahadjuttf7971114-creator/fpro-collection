import type { Metadata } from "next";
import { redirect } from "next/navigation";
import Link from "next/link";
import { getSessionUser } from "@/lib/auth";
import { adminStats, allTitlesWithSeasons, genresWithCounts } from "@/lib/queries";
import AdminPanel from "@/components/AdminPanel";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "Admin Dashboard",
  robots: { index: false },
};

export default async function AdminPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login?next=/admin");
  if (!user.isAdmin) redirect("/");

  const [stats, titles, genres] = await Promise.all([
    adminStats(),
    allTitlesWithSeasons(300),
    genresWithCounts(),
  ]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-[11px] font-black uppercase tracking-[0.25em] text-gold-400">
            Control room
          </p>
          <h1 className="mt-1 font-display text-4xl tracking-wide sm:text-5xl">
            Admin Dashboard
          </h1>
          <p className="mt-2 text-sm text-mist">
            Managing the catalog as{" "}
            <span className="font-semibold text-cream">{user.name}</span>
          </p>
        </div>
        <Link
          href="/"
          className="rounded-md border border-ink-600 px-4 py-2 text-xs font-bold uppercase tracking-wider text-mist hover:border-gold-500/50 hover:text-gold-300"
        >
          View site
        </Link>
      </div>

      <AdminPanel
        stats={stats}
        titles={titles}
        genres={genres.map((g) => ({ ...g, count: Number(g.count) }))}
      />
    </div>
  );
}
