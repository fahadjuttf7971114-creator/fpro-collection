import type { Metadata } from "next";
import { Suspense } from "react";
import { db } from "@/db";
import { genres } from "@/db/schema";
import { eq } from "drizzle-orm";
import BrowseFilters from "@/components/BrowseFilters";
import TitleGrid from "@/components/TitleGrid";
import NoResults from "@/components/NoResults";
import { countTitles, distinctYears, listTitles } from "@/lib/queries";

export const dynamic = "force-dynamic";
export const metadata: Metadata = {
  title: "TV Series",
  description:
    "Stream TV series on Fahad Movies. Filter by genre and year, and dive into full season and episode line-ups.",
};

export default async function SeriesPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const params = await searchParams;
  const genre = typeof params.genre === "string" ? params.genre : undefined;
  const year = typeof params.year === "string" ? params.year : undefined;
  const sort = typeof params.sort === "string" ? params.sort : undefined;

  const [genreRows, years, total, items] = await Promise.all([
    db
      .select({ name: genres.name })
      .from(genres)
      .where(eq(genres.active, true))
      .orderBy(genres.name),
    distinctYears(),
    countTitles({
      type: "series",
      genre,
      year: year ? Number(year) : null,
      sort: sort as "latest" | "popular" | "rating" | undefined,
    }),
    listTitles({
      type: "series",
      genre,
      year: year ? Number(year) : null,
      sort: sort as "latest" | "popular" | "rating" | undefined,
      limit: 60,
    }),
  ]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-6">
        <p className="text-[11px] font-black uppercase tracking-[0.2em] text-gold-400">
          Series
        </p>
        <h1 className="mt-1 font-display text-4xl tracking-wide sm:text-5xl">
          {genre ? `${genre} Series` : "All TV Series"}
        </h1>
        <p className="mt-2 text-sm text-mist">
          {total} series with complete season and episode lists.
        </p>
      </div>

      <Suspense>
        <BrowseFilters
          params={{ genre, year, sort }}
          genres={genreRows.map((g) => g.name)}
          regions={[]}
          years={years}
          withSort
        />
      </Suspense>

      {items.length > 0 ? (
        <TitleGrid items={items} cols="grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5" />
      ) : (
        <NoResults
          message="No series found"
          hint="We couldn't find any series matching those filters."
          basePath="/series"
        />
      )}
    </div>
  );
}
