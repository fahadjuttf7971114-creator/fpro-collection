export type TitleInputFull = {
  title: string;
  type: "movie" | "series";
  year: number;
  rating: number;
  duration: number;
  description: string;
  poster: string;
  backdrop: string;
  trailer: string;
  video: string;
  region: string;
  cast: string[];
  genres: string[];
  isFeatured: boolean;
  isTrending: boolean;
  isPopular: boolean;
};

export type TitleInput = Partial<TitleInputFull> & { slug?: string };

const REGIONS = ["Hollywood", "Bollywood", "Pakistani"];

function asString(v: unknown, max: number): string | undefined {
  if (v === undefined || v === null) return undefined;
  const s = String(v).trim();
  return s.slice(0, max);
}

function asList(v: unknown): string[] | undefined {
  if (v === undefined || v === null) return undefined;
  if (Array.isArray(v))
    return v.map((x) => String(x).trim()).filter(Boolean).slice(0, 12);
  return String(v)
    .split(",")
    .map((x) => x.trim())
    .filter(Boolean)
    .slice(0, 12);
}

function asBool(v: unknown): boolean | undefined {
  if (v === undefined || v === null) return undefined;
  if (typeof v === "boolean") return v;
  return ["1", "true", "yes", "on"].includes(String(v).toLowerCase());
}

/** Returns { errors, value }. value is only present when there are no errors. */
export function parseTitleInput(
  body: Record<string, unknown>,
  partial = false
): { errors: string[]; value: TitleInput } {
  const errors: string[] = [];
  const value: TitleInput = {};

  if (body.title !== undefined || !partial) {
    const t = asString(body.title, 120);
    if (!t || t.length < 2) errors.push("Title is required (min 2 characters).");
    else value.title = t;
  }

  if (body.type !== undefined) {
    if (body.type !== "movie" && body.type !== "series")
      errors.push("Type must be 'movie' or 'series'.");
    else value.type = body.type;
  }

  if (body.year !== undefined) {
    const y = Number(body.year);
    if (!Number.isInteger(y) || y < 1900 || y > 2100)
      errors.push("Year must be between 1900 and 2100.");
    else value.year = y;
  } else if (!partial) value.year = new Date().getFullYear();

  if (body.rating !== undefined) {
    const r = Number(body.rating);
    if (Number.isNaN(r) || r < 0 || r > 10) errors.push("Rating must be 0–10.");
    else value.rating = Math.round(r * 10) / 10;
  } else if (!partial) value.rating = 0;

  if (body.duration !== undefined) {
    const d = Number(body.duration);
    if (!Number.isInteger(d) || d < 0 || d > 900) errors.push("Duration must be 0–900 minutes.");
    else value.duration = d;
  } else if (!partial) value.duration = 0;

  for (const key of [
    "description",
    "poster",
    "backdrop",
    "trailer",
    "video",
  ] as const) {
    if (body[key] !== undefined) {
      value[key] = asString(body[key], key === "description" ? 6000 : 2000) ?? "";
    } else if (!partial) {
      value[key] = "";
    }
  }

  if (body.region !== undefined) {
    const r = asString(body.region, 40);
    if (!r || !REGIONS.includes(r)) errors.push("Region must be Hollywood, Bollywood or Pakistani.");
    else value.region = r;
  } else if (!partial) value.region = "Hollywood";

  if (body.cast !== undefined) {
    value.cast = asList(body.cast) ?? [];
  } else if (!partial) value.cast = [];

  if (body.genres !== undefined) {
    value.genres = asList(body.genres) ?? [];
  } else if (!partial) value.genres = [];

  if (body.isFeatured !== undefined) value.isFeatured = asBool(body.isFeatured) ?? false;
  if (body.isTrending !== undefined) value.isTrending = asBool(body.isTrending) ?? false;
  if (body.isPopular !== undefined) value.isPopular = asBool(body.isPopular) ?? false;

  if (errors.length) return { errors, value: {} };
  return { errors: [], value };
}
