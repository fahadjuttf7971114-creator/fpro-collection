import { db } from "@/db";
import {
  titles,
  seasons,
  episodes,
  genres,
  favorites,
  watchHistory,
  users,
} from "@/db/schema";
import { and, desc, eq, inArray, sql } from "drizzle-orm";

export type TitleData = typeof titles.$inferSelect;
export type SeasonData = typeof seasons.$inferSelect;
export type EpisodeData = typeof episodes.$inferSelect;

export type SeasonWithEpisodes = SeasonData & { episodes: EpisodeData[] };

export type ListFilters = {
  type?: "movie" | "series";
  genre?: string;
  region?: string;
  year?: number | null;
  q?: string;
  actor?: string;
  sort?: "latest" | "popular" | "trending" | "rating";
  limit?: number;
  offset?: number;
};

function clean(v: string) {
  return v.replace(/[%_\\]/g, " ").trim();
}

function where(f: ListFilters) {
  const conds: ReturnType<typeof sql>[] = [];
  if (f.type) conds.push(sql`${titles.type} = ${f.type}`);
  if (f.genre)
    conds.push(
      sql`exists (select 1 from unnest(${titles.genres}) as g where g = ${f.genre})`
    );
  if (f.region) conds.push(sql`${titles.region} = ${f.region}`);
  if (f.year) conds.push(sql`${titles.year} = ${f.year}`);
  if (f.q) conds.push(sql`${titles.title} ilike ${"%" + clean(f.q) + "%"}`);
  if (f.actor)
    conds.push(
      sql`exists (select 1 from unnest(${titles.cast}) as c where c ilike ${
        "%" + clean(f.actor) + "%"
      })`
    );
  return conds.length ? and(...conds) : undefined;
}

function orderByCols(f: ListFilters): any[] {
  switch (f.sort) {
    case "popular":
      return [desc(titles.views)];
    case "trending":
      return [desc(titles.isTrending), desc(titles.views)];
    case "rating":
      return [desc(titles.rating), desc(titles.views)];
    default:
      return [desc(titles.createdAt)];
  }
}

export async function listTitles(f: ListFilters = {}): Promise<TitleData[]> {
  const order = orderByCols(f);
  return db
    .select()
    .from(titles)
    .where(where(f))
    .orderBy(...order, desc(titles.id))
    .limit(f.limit ?? 100)
    .offset(f.offset ?? 0);
}

export async function countTitles(f: ListFilters = {}): Promise<number> {
  const rows = await db
    .select({ n: sql<number>`count(*)` })
    .from(titles)
    .where(where(f));
  return Number(rows[0]?.n ?? 0);
}

export async function getFeatured(limit = 6): Promise<TitleData[]> {
  return db
    .select()
    .from(titles)
    .where(eq(titles.isFeatured, true))
    .orderBy(desc(titles.year))
    .limit(limit);
}

export async function getTitleBySlug(slug: string) {
  const rows = await db.select().from(titles).where(eq(titles.slug, slug)).limit(1);
  const title = rows[0];
  if (!title) return null;
  let seasonsWithEpisodes: SeasonWithEpisodes[] = [];
  if (title.type === "series") {
    const s = await db
      .select()
      .from(seasons)
      .where(eq(seasons.titleId, title.id))
      .orderBy(seasons.seasonNumber);
    if (s.length) {
      const eps = await db
        .select()
        .from(episodes)
        .where(inArray(episodes.seasonId, s.map((x) => x.id)))
        .orderBy(episodes.number);
      seasonsWithEpisodes = s.map((sn) => ({
        ...sn,
        episodes: eps.filter((e) => e.seasonId === sn.id),
      }));
    }
  }
  return { title, seasons: seasonsWithEpisodes };
}

export async function getSimilar(slug: string, limit = 8): Promise<TitleData[]> {
  const base = await db
    .select({ genres: titles.genres, type: titles.type, id: titles.id })
    .from(titles)
    .where(eq(titles.slug, slug))
    .limit(1);
  if (!base[0]) return [];
  const gens = base[0].genres;
  const arrSql = sql`(${titles.genres} && ARRAY[${sql.join(
    gens.map((g) => sql`${g}`),
    sql`, `
  )}]::text[])`;
  return db
    .select()
    .from(titles)
    .where(
      and(
        sql`${titles.id} != ${base[0].id}`,
        arrSql
      )
    )
    .orderBy(desc(titles.rating), desc(titles.views))
    .limit(limit);
}

export async function genresWithCounts() {
  return db
    .select({
      id: genres.id,
      name: genres.name,
      slug: genres.slug,
      active: genres.active,
      count: sql<number>`(select count(*) from titles t where exists (
        select 1 from unnest(t.genres) g where g = ${genres.name}
      ))`,
    })
    .from(genres)
    .orderBy(desc(sql`(select count(*) from titles t where exists (
      select 1 from unnest(t.genres) g where g = ${genres.name}
    ))`), genres.name);
}

export async function regionCounts() {
  const regions = ["Hollywood", "Bollywood", "Pakistani"];
  const out: { region: string; count: number }[] = [];
  for (const r of regions) {
    const rows = await db
      .select({ n: sql<number>`count(*)` })
      .from(titles)
      .where(sql`${titles.region} = ${r}`);
    out.push({ region: r, count: Number(rows[0]?.n ?? 0) });
  }
  return out;
}

export async function distinctYears() {
  const rows = await db
    .select({ year: titles.year })
    .from(titles)
    .groupBy(titles.year)
    .orderBy(desc(titles.year));
  return rows.map((r) => r.year);
}

export async function adminStats() {
  const [all, movies, series, gens, usersCount, views, favs] = await Promise.all([
    db.select({ n: sql<number>`count(*)` }).from(titles),
    db.select({ n: sql<number>`count(*)` }).from(titles).where(sql`${titles.type} = 'movie'`),
    db.select({ n: sql<number>`count(*)` }).from(titles).where(sql`${titles.type} = 'series'`),
    db.select({ n: sql<number>`count(*)` }).from(genres),
    db.select({ n: sql<number>`count(*)` }).from(users),
    db.select({ n: sql<number>`coalesce(sum(${titles.views}),0)` }).from(titles),
    db.select({ n: sql<number>`count(*)` }).from(favorites),
  ]);
  const top = await db
    .select({ id: titles.id, slug: titles.slug, title: titles.title, views: titles.views, type: titles.type })
    .from(titles)
    .orderBy(desc(titles.views))
    .limit(6);
  const recentUsers = await db
    .select({ name: users.name, email: users.email, createdAt: users.createdAt })
    .from(users)
    .orderBy(desc(users.createdAt))
    .limit(5);
  const featured = await db
    .select({ n: sql<number>`count(*)` })
    .from(titles)
    .where(eq(titles.isFeatured, true));
  return {
    totals: {
      titles: Number(all[0].n),
      movies: Number(movies[0].n),
      series: Number(series[0].n),
      genres: Number(gens[0].n),
      users: Number(usersCount[0].n),
      views: Number(views[0].n),
      favorites: Number(favs[0].n),
      featured: Number(featured[0].n),
    },
    top,
    recentUsers,
  };
}

export async function getFavorites(userId: number) {
  const rows = await db
    .select({ t: titles, at: favorites.createdAt })
    .from(favorites)
    .innerJoin(titles, eq(favorites.titleId, titles.id))
    .where(eq(favorites.userId, userId))
    .orderBy(desc(favorites.createdAt))
    .limit(100);
  return rows.map((r) => r.t);
}

export async function hasFavorite(userId: number, titleId: number) {
  const rows = await db
    .select({ n: sql<number>`1` })
    .from(favorites)
    .where(and(eq(favorites.userId, userId), eq(favorites.titleId, titleId)))
    .limit(1);
  return rows.length > 0;
}

export async function recordView(userId: number | null, titleId: number) {
  await db
    .update(titles)
    .set({ views: sql`${titles.views} + 1` })
    .where(eq(titles.id, titleId))
    .catch(() => undefined);
  if (userId) {
    await db
      .delete(watchHistory)
      .where(and(eq(watchHistory.userId, userId), eq(watchHistory.titleId, titleId)))
      .catch(() => undefined);
    await db
      .insert(watchHistory)
      .values({ userId, titleId })
      .catch(() => undefined);
  }
}

export async function getHistory(userId: number, limit = 12) {
  const rows = await db
    .select({ t: titles, at: watchHistory.watchedAt })
    .from(watchHistory)
    .innerJoin(titles, eq(watchHistory.titleId, titles.id))
    .where(eq(watchHistory.userId, userId))
    .orderBy(desc(watchHistory.watchedAt))
    .limit(limit);
  return rows.map((r) => r.t);
}

export async function allTitlesWithSeasons(limit = 300) {
  const items = await listTitles({ limit });
  const series = items.filter((t) => t.type === "series");
  const map = new Map<number, SeasonWithEpisodes[]>();
  if (series.length > 0) {
    const s = await db
      .select()
      .from(seasons)
      .where(inArray(seasons.titleId, series.map((t) => t.id)))
      .orderBy(seasons.seasonNumber);
    const e = s.length
      ? await db
          .select()
          .from(episodes)
          .where(inArray(episodes.seasonId, s.map((x) => x.id)))
          .orderBy(episodes.number)
      : [];
    for (const t of series) {
      const own = s.filter((sn) => sn.titleId === t.id);
      map.set(
        t.id,
        own.map((sn) => ({
          ...sn,
          episodes: e.filter((ep) => ep.seasonId === sn.id),
        }))
      );
    }
  }
  return items.map((t) => ({
    ...t,
    seasons: map.get(t.id) ?? [],
  })) as (TitleData & { seasons: SeasonWithEpisodes[] })[];
}

export function slugify(v: string): string {
  return (
    v
      .toLowerCase()
      .trim()
      .replace(/['’]/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 80) || "title"
  );
}
