import {
  pgTable,
  serial,
  text,
  integer,
  real,
  boolean,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  isAdmin: boolean("is_admin").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const sessions = pgTable("sessions", {
  token: text("token").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
});

export const titles = pgTable("titles", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  type: text("type").$type<"movie" | "series">().notNull().default("movie"),
  title: text("title").notNull(),
  year: integer("year").notNull().default(2024),
  rating: real("rating").notNull().default(0),
  duration: integer("duration").notNull().default(0),
  description: text("description").notNull().default(""),
  poster: text("poster").notNull().default(""),
  backdrop: text("backdrop").notNull().default(""),
  trailer: text("trailer").notNull().default(""),
  video: text("video").notNull().default(""),
  region: text("region").notNull().default("Hollywood"),
  cast: text("cast").array().notNull().default([]),
  genres: text("genres").array().notNull().default([]),
  isFeatured: boolean("is_featured").notNull().default(false),
  isTrending: boolean("is_trending").notNull().default(false),
  isPopular: boolean("is_popular").notNull().default(false),
  views: integer("views").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const seasons = pgTable("seasons", {
  id: serial("id").primaryKey(),
  titleId: integer("title_id")
    .notNull()
    .references(() => titles.id, { onDelete: "cascade" }),
  seasonNumber: integer("season_number").notNull().default(1),
  name: text("name").notNull().default(""),
});

export const episodes = pgTable("episodes", {
  id: serial("id").primaryKey(),
  seasonId: integer("season_id")
    .notNull()
    .references(() => seasons.id, { onDelete: "cascade" }),
  titleId: integer("title_id")
    .notNull()
    .references(() => titles.id, { onDelete: "cascade" }),
  number: integer("number").notNull().default(1),
  name: text("name").notNull().default(""),
  description: text("description").notNull().default(""),
  video: text("video").notNull().default(""),
  duration: integer("duration").notNull().default(0),
});

export const genres = pgTable("genres", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  slug: text("slug").notNull().unique(),
  active: boolean("active").notNull().default(true),
});

export const favorites = pgTable(
  "favorites",
  {
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    titleId: integer("title_id")
      .notNull()
      .references(() => titles.id, { onDelete: "cascade" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("fav_user_title").on(t.userId, t.titleId)]
);

export const watchHistory = pgTable("watch_history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  titleId: integer("title_id")
    .notNull()
    .references(() => titles.id, { onDelete: "cascade" }),
  watchedAt: timestamp("watched_at", { withTimezone: true }).notNull().defaultNow(),
});
